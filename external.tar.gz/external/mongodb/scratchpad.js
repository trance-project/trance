C, O, LI (custom join) = 2393s

C, O, LI = 1447s

O, LI = 1000s

----

Mongo 4.2.9

C, O, LI (hash index) = 1942s

C, O, LI (range unique index) =1791s



SF=1

Depth 2 (range unique index), custom join = 317s
Depth 2 (range unique index) = 165s





O join LI + writing = 155s, 140s 
Sharded O join LI + writing = 144s, 137s

MR O join LI = 498s
MR O join Sharded LI = 451s
MR Sharded O join Sharded LI = 343 (108 + 235)
MR Sharded LI join Sharded O = 318 (149 + 169)


MR O join Sharded LI => sharded output = 310 (170 + 139)
MR Sharded O join Sharded LI => sharded output = 273 (123 + 149)

Sharded O join LI + sharded output = 178s


d = new Date; 
db.OrdersSharded.aggregate([
    { $project: { O_ORDERKEY: 1, O_ORDERDATE: 1 } },
    { $lookup: {
        from: "Lineitem",
        localField: "O_ORDERKEY",
        foreignField: "L_ORDERKEY",
        as: "oparts"
    }},
    { $project: { 
        C_NAME: 1, 
        O_ORDERDATE: 1,
        "oparts.L_PARTKEY": 1,
        "oparts.L_QUANTITY": 1
    }},
    { $merge: { into: "joined2", on: "_id", whenMatched: "replace",  whenNotMatched: "insert" } }
  ],
  { allowDiskUse: true }
)
print(new Date - d + 'ms');


db.Part.createIndex( { P_PARTKEY: 1 }, { unique: true } );
sh.shardCollection("tpch.joined3", { _id: 1 } );

d = new Date;
db.joined2.aggregate([
    { $unwind: {
        path: "$oparts",
        preserveNullAndEmptyArrays: true
    }},
    { $lookup: {
        from: "Part",
        localField: "oparts.L_PARTKEY",
        foreignField: "P_PARTKEY",
        as: "oparts2"
    }},
    { $project: {
        "O_ORDERDATE": 1,
        "oparts2.P_NAME": 1,
        "oparts2.P_RETAILPRICE": 1,
        "oparts.L_QUANTITY": 1
    }},
    
    { $merge: { into: "joined3", on: "_id", whenMatched: "replace",  whenNotMatched: "insert" } }
])
print(new Date - d + 'ms');
   


var mapFnOrder = function() {
    emit(this.O_ORDERKEY, { odate: this.O_ORDERDATE } );
};
var mapFnLineitem = function() {
    emit(this.L_ORDERKEY, { pkey: this.L_PARTKEY, qty: this.L_QUANTITY } );
}
var reduceFnOrderLineitem = function(key, values) {    
    var result = { };
    var items = [ ];
    values.forEach(function(value) {
        var item = { };
        if (value.pkey !== undefined && value.qty !== undefined) {
            item["pkey"] = value.pkey;
            item["qty"] = value.qty;
            items.push(item);
        }
        if (value.odate !== undefined) {
            result["odate"] = value.odate;
        }
        if (value.oparts !== undefined) {
            result["oparts"] = value.oparts;
        }
    });
    if (Object.keys(items).length > 0) result["oparts"] = items;
    return result;
}

db.joined.drop()
sh.shardCollection("tpch.joined", { _id: 1 } );

d = new Date; 
db.LineitemSharded.mapReduce(mapFnLineitem, reduceFnOrderLineitem, { out: { reduce: "joined", sharded: true } });
db.OrdersSharded.mapReduce(mapFnOrder, reduceFnOrderLineitem, { out: { reduce: "joined", sharded: true } });
print(new Date - d + 'ms');

