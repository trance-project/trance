#!/bin/bash

# Assuming you're located in the tpch folder

# MongoDB expects tab separated files, so convert if necessary
for i in `ls *.tbl`; do 
    if [ ! -f ${i/tbl/tsv} ]; then 
        echo Converting $i... 
        sed 's/|$//' $i | sed 's/|/\t/g' > ${i/tbl/tsv}; 
    fi
done;

mongoimport --port 29101 --numInsertionWorkers=20 --type tsv -d tpch -c Region --columnsHaveTypes --fields="R_REGIONKEY.int64(),R_NAME.string(),R_COMMENT.string()" --drop region.tsv
mongoimport --port 29101 --numInsertionWorkers=20 --type tsv -d tpch -c Nation --columnsHaveTypes --fields="N_NATIONKEY.int64(),N_NAME.string(),N_REGIONKEY.int64(),N_COMMENT.string()" --drop nation.tsv
mongoimport --port 29101 --numInsertionWorkers=20 --type tsv -d tpch -c Part --columnsHaveTypes --fields="P_PARTKEY.int64(),P_NAME.string(),P_MFGR.string(),P_BRAND.string(),P_TYPE.string(),P_SIZE.int64(),P_CONTAINER.string(),P_RETAILPRICE.decimal(),P_COMMENT.string()" --drop part.tsv
mongoimport --port 29101 --numInsertionWorkers=20 --type tsv -d tpch -c Supplier --columnsHaveTypes --fields="S_SUPPKEY.int64(),S_NAME.string(),S_ADDRESS.string(),S_NATIONKEY.int64(),S_PHONE.string(),S_ACCTBAL.decimal(),S_COMMENT.string()" --drop supplier.tsv
mongoimport --port 29101 --numInsertionWorkers=20 --type tsv -d tpch -c Partsupp --columnsHaveTypes --fields="PS_PARTKEY.int64(),PS_SUPPKEY.int64(),PS_AVAILQTY.int64(),PS_SUPPLYCOST.decimal(),PS_COMMENT.string()" --drop partsupp.tsv
mongoimport --port 29101 --numInsertionWorkers=20 --type tsv -d tpch -c Customer --columnsHaveTypes --fields="C_CUSTKEY.int64(),C_NAME.string(),C_ADDRESS.string(),C_NATIONKEY.int64(),C_PHONE.string(),C_ACCTBAL.decimal(),C_MKTSEGMENT.string(),C_COMMENT.string()" --drop customer.tsv
mongoimport --port 29101 --numInsertionWorkers=20 --type tsv -d tpch -c Orders --columnsHaveTypes --fields="O_ORDERKEY.int64(),O_CUSTKEY.int64(),O_ORDERSTATUS.string(),O_TOTALPRICE.decimal(),O_ORDERDATE.date(2006-01-02),O_ORDERPRIORITY.string(),O_CLERK.string(),O_SHIPPRIORITY.int64(),O_COMMENT.string()" --drop orders.tsv
mongoimport --port 29101 --numInsertionWorkers=20 --type tsv -d tpch -c Lineitem --columnsHaveTypes --fields="L_ORDERKEY.int64(),L_PARTKEY.int64(),L_SUPPKEY.int64(),L_LINENUMBER.int64(),L_QUANTITY.decimal(),L_EXTENDEDPRICE.decimal(),L_DISCOUNT.decimal(),L_TAX.decimal(),L_RETURNFLAG.string(),L_LINESTATUS.string(),L_SHIPDATE.date(2006-01-02),L_COMMITDATE.date(2006-01-02),L_RECEIPTDATE.date(2006-01-02),L_SHIPINSTRUCT.string(),L_SHIPMODE.string(),L_COMMENT.string()" --drop lineitem.tsv

mongoimport --port 29101 --numInsertionWorkers=20 --type tsv -d tpch -c CustomerSharded --columnsHaveTypes --fields="C_CUSTKEY.int64(),C_NAME.string(),C_ADDRESS.string(),C_NATIONKEY.int64(),C_PHONE.string(),C_ACCTBAL.decimal(),C_MKTSEGMENT.string(),C_COMMENT.string()"  customer.tsv
mongoimport --port 29101 --numInsertionWorkers=20 --type tsv -d tpch -c OrdersSharded --columnsHaveTypes --fields="O_ORDERKEY.int64(),O_CUSTKEY.int64(),O_ORDERSTATUS.string(),O_TOTALPRICE.decimal(),O_ORDERDATE.date(2006-01-02),O_ORDERPRIORITY.string(),O_CLERK.string(),O_SHIPPRIORITY.int64(),O_COMMENT.string()"  orders.tsv
mongoimport --port 29101 --numInsertionWorkers=20 --type tsv -d tpch -c LineitemSharded --columnsHaveTypes --fields="L_ORDERKEY.int64(),L_PARTKEY.int64(),L_SUPPKEY.int64(),L_LINENUMBER.int64(),L_QUANTITY.decimal(),L_EXTENDEDPRICE.decimal(),L_DISCOUNT.decimal(),L_TAX.decimal(),L_RETURNFLAG.string(),L_LINESTATUS.string(),L_SHIPDATE.date(2006-01-02),L_COMMITDATE.date(2006-01-02),L_RECEIPTDATE.date(2006-01-02),L_SHIPINSTRUCT.string(),L_SHIPMODE.string(),L_COMMENT.string()"  lineitem.tsv
