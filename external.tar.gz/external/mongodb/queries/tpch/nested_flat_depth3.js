use tpch;

// Local output

db.Part.createIndex( { P_PARTKEY: 1 }, { unique: true } );

d = new Date; 
db.TPCH_Flat_Nested_Depth3_Result.aggregate([
    { $unwind: {
        path: "$ncusts",
        preserveNullAndEmptyArrays: true
    }},
    { $unwind: {
        path: "$ncusts.corders",
        preserveNullAndEmptyArrays: true
    }},
    { $unwind: {
        path: "$ncusts.corders.oparts",
        preserveNullAndEmptyArrays: true
    }},
    { $lookup: {
        from: "Part",
        localField: "ncusts.corders.oparts.L_PARTKEY",
        foreignField: "P_PARTKEY",
        as: "oparts2"
    }},
    { $project: {
        "nname": 1,
        "ncusts.corders.oparts.L_QUANTITY": 1,
        "oparts2.P_RETAILPRICE": 1
    }},
    { $unwind: {
        path: "$oparts2",
        preserveNullAndEmptyArrays: true
    }},
    { $group : {
        _id: "$nname",
        total: { $sum: { $multiply: [ "$ncusts.corders.oparts.L_QUANTITY", "$oparts2.P_RETAILPRICE" ] } }        
    }},
    { $out: "TPCH_Nested_Flat_Depth3_Result" }
  ],
  { allowDiskUse: true }
)
print(new Date - d + 'ms');

// Slower alternative

// d = new Date; 
// db.TPCH_Flat_Nested_Depth3_Result.aggregate([
//     { $unwind: {
//         path: "$ncusts",
//         preserveNullAndEmptyArrays: true
//     }},
//     { $unwind: {
//         path: "$ncusts.corders",
//         preserveNullAndEmptyArrays: true
//     }},
//     { $unwind: {
//         path: "$ncusts.corders.oparts",
//         preserveNullAndEmptyArrays: true
//     }},
//     { $lookup: {
//         from: "Part",
//         let: { partkey: "$ncusts.corders.oparts.L_PARTKEY", qty: "$ncusts.corders.oparts.L_QUANTITY" },
//         pipeline: [
//             { $match: { $expr: { $eq: [ "$P_PARTKEY", "$$partkey" ] } } },
//             { $project: { 
//                 _id: 0,
//                 P_NAME: 1, 
//                 total: { $multiply: [ "$$qty", "$P_RETAILPRICE" ] }
//             }}
//         ],
//         as: "ncusts.corders.oparts"
//     }},
//     { $unwind: {
//         path: "$ncusts.corders.oparts",
//         preserveNullAndEmptyArrays: true
//     }},
//     { $group : {
//         _id: "$nname",
//         total: { $sum: "$ncusts.corders.oparts.total" }
//     }},
//     { $out: "TPCH_Nested_Flat_Depth3_Result" }
//   ],
//   { allowDiskUse: true }
// )
// print(new Date - d + 'ms');

db.TPCH_Nested_Flat_Depth3_Result.drop()
