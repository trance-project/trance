use tpch;

// Local output

db.Part.createIndex( { P_PARTKEY: 1 }, { unique: true } );

d = new Date; 
db.TPCH_Flat_Nested_Depth3_Result.aggregate([
    { $unwind: {
        path: "$ncusts",
        includeArrayIndex: "ncusts._id",
        preserveNullAndEmptyArrays: true
    }},
    { $unwind: {
        path: "$ncusts.corders",
        includeArrayIndex: "ncusts.corders._id",
        preserveNullAndEmptyArrays: true
    }},
    { $unwind: {
        path: "$ncusts.corders.oparts",
        preserveNullAndEmptyArrays: true
    }},
    { $lookup: {
        from: "Part",
        localField: "ncusts.corders.oparts.L_PARTKEY",
        foreignField: "P_PARTKEY",
        as: "oparts2"
    }},
    { $project: {
        "nname": 1,
        "ncusts._id": 1,
        "ncusts.cname": 1,
        "ncusts.corders._id": 1,
        "ncusts.corders.odate": 1,
        "ncusts.corders.oparts.L_QUANTITY": 1,
        "oparts2.P_NAME": 1, 
        "oparts2.P_RETAILPRICE": 1
    }},
    { $unwind: {
        path: "$oparts2",
        preserveNullAndEmptyArrays: true
    }},
    { $group : {
        _id: {
            id0: "$_id",
            id1: "$ncusts._id",
            id2: "$ncusts.corders._id",
            pname: "$oparts2.P_NAME"
        },
        nname: { $first: "$nname" },
        cname: { $first: "$ncusts.cname" },
        odate: { $first: "$ncusts.corders.odate" },
        total: { $sum: { $multiply: [ "$ncusts.corders.oparts.L_QUANTITY", "$oparts2.P_RETAILPRICE" ] } }
    }},
    { $group : {
        _id: {
            id0: "$_id.id0",
            id1: "$_id.id1",
            id2: "$_id.id2",
        },
        nname: { $first: "$nname" },
        cname: { $first: "$cname" },
        odate: { $first: "$odate" },
        oparts: { $push: {
            $cond: [
                { $ne: ["$_id.pname", null] },
                { pname: "$_id.pname", total: "$total" },
                "$$REMOVE"
            ]
        }}
    }},
    { $group : {
        _id: {
            id0: "$_id.id0",
            id1: "$_id.id1",
        },
        nname: { $first: "$nname" },
        cname: { $first: "$cname" },
        corders: { $push: {
            $cond: [
                { $ne: ["$odate", null] },
                { odate: "$odate", oparts: "$oparts" },
                "$$REMOVE"
            ]
        }}
    }},
    { $group : {
        _id: "$_id.id0",
        nname: { $first: "$nname" },
        ncusts: { $push: {
            $cond: [
                { $ne: ["$cname", null] },
                { cname: "$cname", corders: "$corders" },
                "$$REMOVE"
            ]
        }}
    }},
    { $out: "TPCH_Nested_Nested_Depth3_Result" }
  ],
  { allowDiskUse: true }
)
print(new Date - d + 'ms');

// Slower alternative

// d = new Date; 
// db.TPCH_Flat_Nested_Depth3_Result.aggregate([
//     { $unwind: {
//         path: "$ncusts",
//         includeArrayIndex: "ncusts._id",
//         preserveNullAndEmptyArrays: true
//     }},
//     { $unwind: {
//         path: "$ncusts.corders",
//         includeArrayIndex: "ncusts.corders._id",
//         preserveNullAndEmptyArrays: true
//     }},
//     { $unwind: {
//         path: "$ncusts.corders.oparts",
//         preserveNullAndEmptyArrays: true
//     }},
//     { $lookup: {
//         from: "Part",
//         let: { partkey: "$ncusts.corders.oparts.L_PARTKEY", qty: "$ncusts.corders.oparts.L_QUANTITY" },
//         pipeline: [
//             { $match: { $expr: { $eq: [ "$P_PARTKEY", "$$partkey" ] } } },
//             { $project: { 
//                 _id: 0,
//                 P_NAME: 1, 
//                 total: { $multiply: [ "$$qty", "$P_RETAILPRICE" ] }
//             }}
//         ],
//         as: "ncusts.corders.oparts"
//     }},
//     { $unwind: {
//         path: "$ncusts.corders.oparts",
//         preserveNullAndEmptyArrays: true
//     }},
//     { $group : {
//         _id: {
//             id0: "$_id",
//             id1: "$ncusts._id",
//             id2: "$ncusts.corders._id",
//             pname: "$ncusts.corders.oparts.P_NAME"
//         },
//         nname: { $first: "$nname" },
//         cname: { $first: "$ncusts.cname" },
//         odate: { $first: "$ncusts.corders.odate" },
//         total: { $sum: "$ncusts.corders.oparts.total" }
//     }},
//     { $group : {
//         _id: {
//             id0: "$_id.id0",
//             id1: "$_id.id1",
//             id2: "$_id.id2",
//         },
//         nname: { $first: "$nname" },
//         cname: { $first: "$cname" },
//         odate: { $first: "$odate" },
//         oparts: { $push: {
//             $cond: [
//                 { $ne: ["$_id.pname", null] },
//                 { pname: "$_id.pname", total: "$total" },
//                 "$$REMOVE"
//             ]
//         }}
//     }},
//     { $group : {
//         _id: {
//             id0: "$_id.id0",
//             id1: "$_id.id1",
//         },
//         nname: { $first: "$nname" },
//         cname: { $first: "$cname" },
//         corders: { $push: {
//             $cond: [
//                 { $ne: ["$odate", null] },
//                 { odate: "$odate", oparts: "$oparts" },
//                 "$$REMOVE"
//             ]
//         }}
//     }},
//     { $group : {
//         _id: "$_id.id0",
//         nname: { $first: "$nname" },
//         ncusts: { $push: {
//             $cond: [
//                 { $ne: ["$cname", null] },
//                 { cname: "$cname", corders: "$corders" },
//                 "$$REMOVE"
//             ]
//         }}
//     }},
//     { $out: "TPCH_Nested_Nested_Depth3_Result" }
//   ],
//   { allowDiskUse: true }
// )
// print(new Date - d + 'ms');

db.TPCH_Nested_Nested_Depth3_Result.drop()
