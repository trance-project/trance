use tpch;

// Local output

db.Part.createIndex( { P_PARTKEY: 1 }, { unique: true } );

d = new Date; 
db.TPCH_Flat_Nested_Depth1_Result.aggregate([
    { $unwind: {
        path: "$oparts",
        preserveNullAndEmptyArrays: true
    }},
    { $lookup: {
        from: "Part",
        localField: "oparts.L_PARTKEY",
        foreignField: "P_PARTKEY",
        as: "oparts2"
    }},
    { $project: {
        "O_ORDERDATE": 1,
        "oparts.L_QUANTITY": 1,
        "oparts2.P_RETAILPRICE": 1
    }},
    { $unwind: {
        path: "$oparts2",
        preserveNullAndEmptyArrays: true
    }},
    { $group : {
        _id: "$O_ORDERDATE",
        total: { $sum: { $multiply: [ "$oparts.L_QUANTITY", "$oparts2.P_RETAILPRICE" ] } }
    }},
    { $out: "TPCH_Nested_Flat_Depth1_Result" }
  ],
  { allowDiskUse: true }
)
print(new Date - d + 'ms');


// Slower alternative 

// d = new Date; 
// db.TPCH_Flat_Nested_Depth1_Result.aggregate([
//     { $unwind: {
//         path: "$oparts",
//         preserveNullAndEmptyArrays: true
//     }},
//     { $lookup: {
//         from: "Part",
//         let: { partkey: "$oparts.L_PARTKEY", qty: "$oparts.L_QUANTITY" },
//         pipeline: [
//             { $match: { $expr: { $eq: [ "$P_PARTKEY", "$$partkey" ] } } },
//             { $project: { 
//                 _id: 0,
//                 P_NAME: 1, 
//                 total: { $multiply: [ "$$qty", "$P_RETAILPRICE" ] }
//             }}
//         ],
//         as: "oparts"
//     }},
//     { $unwind: {
//         path: "$oparts",
//         preserveNullAndEmptyArrays: true
//     }},
//     { $group : {
//         _id: "$O_ORDERDATE",
//         total: { $sum: "$oparts.total" }
//     }},
//     { $out: "TPCH_Nested_Flat_Depth1_Result" }
//   ],
//   { allowDiskUse: true }
// )
// print(new Date - d + 'ms');

db.TPCH_Nested_Flat_Depth1_Result.drop()
