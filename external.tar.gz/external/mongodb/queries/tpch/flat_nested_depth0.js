use tpch;

// Local input and output

d = new Date; 
db.Lineitem.aggregate([
    { $project: { L_PARTKEY: 1, L_QUANTITY: 1 } },
    { $out: "TPCH_Flat_Nested_Depth0_Result" }
])
print(new Date - d + 'ms');
