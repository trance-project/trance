use tpch;

// Local input and output

db.Nation.createIndex( { N_REGIONKEY: 1 } );
db.Customer.createIndex( { C_NATIONKEY: 1 } );
db.Orders.createIndex( { O_CUSTKEY: 1 } );
db.Lineitem.createIndex( { L_ORDERKEY: 1 } );

d = new Date; 
db.Region.aggregate([
    { $project: { R_REGIONKEY: 1, R_NAME: 1 } },
    { $lookup: {
        from: "Nation",
        localField: "R_REGIONKEY",
        foreignField: "N_REGIONKEY",
        as: "rnations"
    }},
    { $project: { 
        R_NAME: 1, 
        "rnations._id": 1,
        "rnations.N_NAME": 1,
        "rnations.N_NATIONKEY": 1
    }},
    { $unwind: {
        path: "$rnations",
        preserveNullAndEmptyArrays: true
    }},
    { $lookup: {
        from: "Customer",
        localField: "rnations.N_NATIONKEY",
        foreignField: "C_NATIONKEY",
        as: "rnations.ncusts"
    }},
    { $project: { 
        R_NAME: 1, 
        "rnations._id": 1,
        "rnations.N_NAME": 1,
        "rnations.ncusts._id": 1,
        "rnations.ncusts.C_NAME": 1,
        "rnations.ncusts.C_CUSTKEY": 1        
    }},
    { $unwind: {
        path: "$rnations.ncusts",
        preserveNullAndEmptyArrays: true
    }},
    { $lookup: {
        from: "Orders",
        localField: "rnations.ncusts.C_CUSTKEY",
        foreignField: "O_CUSTKEY",
        as: "rnations.ncusts.corders"
    }},
    { $project: { 
        R_NAME: 1,
        "rnations._id": 1,
        "rnations.N_NAME": 1,
        "rnations.ncusts._id": 1,
        "rnations.ncusts.C_NAME": 1,
        "rnations.ncusts.corders.O_ORDERDATE": 1,
        "rnations.ncusts.corders.O_ORDERKEY": 1        
    }},
    { $unwind: {
        path: "$rnations.ncusts.corders",
        preserveNullAndEmptyArrays: true
    }},
    { $lookup: {
        from: "Lineitem",
        localField: "rnations.ncusts.corders.O_ORDERKEY",
        foreignField: "L_ORDERKEY",
        as: "rnations.ncusts.corders.oparts"
    }},
    { $project: {
        R_NAME: 1,
        "rnations._id": 1,
        "rnations.N_NAME": 1,
        "rnations.ncusts._id": 1,
        "rnations.ncusts.C_NAME": 1,
        "rnations.ncusts.corders.O_ORDERDATE": 1,
        "rnations.ncusts.corders.oparts.L_PARTKEY": 1,
        "rnations.ncusts.corders.oparts.L_QUANTITY": 1
    }},
    { $group : {
        _id: {
            "id0": "$_id",
            "id1": "$rnations._id",
            "id2": "$rnations.ncusts._id",
        },
        rname: { $first: "$R_NAME" },
        nname: { $first: "$rnations.N_NAME" },
        cname: { $first: "$rnations.ncusts.C_NAME" },
        corders: { $push: {
            $cond: [
                { $and: [
                    { $ne: ["$rnations.ncusts.corders.O_ORDERDATE", undefined] },
                    { $ne: ["$rnations.ncusts.corders.O_ORDERDATE", null] }
                ]},
                {  odate: "$rnations.ncusts.corders.O_ORDERDATE", oparts: "$rnations.ncusts.corders.oparts" },
                "$$REMOVE"
            ]
        }}
    }},
    { $group : {
        _id: {
            "id0": "$_id.id0",
            "id1": "$_id.id1"
        },
        rname: { $first: "$rname" },
        nname: { $first: "$nname" },
        ncusts: { $push: {
            $cond: [
                { $and: [
                    { $ne: ["$cname", undefined] },
                    { $ne: ["$cname", null] }
                ]},
                {  cname: "$cname", corders: "$corders" },
                "$$REMOVE"
            ]
        }}
    }},    
    { $group : {
        _id: "$_id.id0",
        rname: { $first: "$rname" },
        rnations: { $push: {
            $cond: [
                { $and: [
                    { $ne: ["$nname", undefined] },
                    { $ne: ["$nname", null] }
                ]},
                { nname: "$nname", ncusts: "$ncusts" },
                "$$REMOVE"
            ]
        }}
    }},
    { $out: "TPCH_Flat_Nested_Depth4_Result" }
  ],
  { allowDiskUse: true }
)
print(new Date - d + 'ms');


// Slower alternative

// d = new Date; 
// db.Region.aggregate([
//     { $project: { R_REGIONKEY: 1, R_NAME: 1 } },
//     { $lookup: {
//         from: "Nation",
//         let: { regionkey: "$R_REGIONKEY" },
//         pipeline: [
//             { $match: { $expr: { $eq: [ "$N_REGIONKEY", "$$regionkey" ] } } },
//             { $project: { N_NATIONKEY: 1, N_NAME: 1 } },
//             { $lookup: {
//                 from: "Customer",
//                 let: { nationkey: "$N_NATIONKEY" },
//                 pipeline: [
//                     { $match: { $expr: { $eq: [ "$C_NATIONKEY", "$$nationkey" ] } } },
//                     { $project: { C_CUSTKEY: 1, C_NAME: 1 } },
//                     { $lookup: {
//                         from: "Orders",
//                         let: { custkey: "$C_CUSTKEY" },
//                         pipeline: [
//                             { $match: { $expr: { $eq: [ "$O_CUSTKEY", "$$custkey" ] } } },
//                             { $project: { O_ORDERKEY: 1, O_ORDERDATE: 1 } },
//                             { $lookup: {
//                                 from: "Lineitem",
//                                 let: { orderkey: "$O_ORDERKEY" },
//                                 pipeline: [
//                                     { $match: { $expr: { $eq: [ "$L_ORDERKEY", "$$orderkey" ] } } },
//                                     { $project: { L_PARTKEY: 1, L_QUANTITY: 1, _id: 0 } }
//                                 ],
//                                 as: "oparts"
//                             }},
//                             { $project: { O_ORDERKEY: 0, _id: 0 } }
//                         ],
//                         as: "corders"
//                     }},
//                     { $project: { C_CUSTKEY: 0, _id: 0 } }
//                 ],
//                 as: "ncusts"
//             }},
//             { $project: { N_NATIONKEY: 0, _id: 0 } }
//         ],
//         as: "rnations"
//     }},
//     { $project: { R_REGIONKEY: 0 } },
//     { $out: "TPCH_Flat_Nested_Depth4_Result" }
// ])
// print(new Date - d + 'ms');
