use tpch;

// Local input and sharded output

db.TPCH_Flat_Nested_Depth3_Result.drop();
sh.shardCollection("tpch.TPCH_Flat_Nested_Depth3_Result", { _id: "hashed" } );

db.Customer.createIndex( { C_NATIONKEY: 1 } );
db.Orders.createIndex( { O_CUSTKEY: 1 } );
db.Lineitem.createIndex( { L_ORDERKEY: 1 } );

d = new Date; 
db.Nation.aggregate([
    { $project: { N_NATIONKEY: 1, N_NAME: 1 } },
    { $lookup: {
        from: "Customer",
        localField: "N_NATIONKEY",
        foreignField: "C_NATIONKEY",
        as: "ncusts"
    }},
    { $project: { 
        N_NAME: 1, 
        "ncusts._id": 1,
        "ncusts.C_NAME": 1,
        "ncusts.C_CUSTKEY": 1
    }},
    { $unwind: {
        path: "$ncusts",
        preserveNullAndEmptyArrays: true
    }},
    { $lookup: {
        from: "Orders",
        localField: "ncusts.C_CUSTKEY",
        foreignField: "O_CUSTKEY",
        as: "ncusts.corders"
    }},
    { $project: { 
        N_NAME: 1, 
        "ncusts._id": 1,
        "ncusts.C_NAME": 1,
        "ncusts.corders.O_ORDERDATE": 1,
        "ncusts.corders.O_ORDERKEY": 1
    }},
    { $unwind: {
        path: "$ncusts.corders",
        preserveNullAndEmptyArrays: true
    }},
    { $lookup: {
        from: "Lineitem",
        localField: "ncusts.corders.O_ORDERKEY",
        foreignField: "L_ORDERKEY",
        as: "ncusts.corders.oparts"
    }},
    { $project: {
        N_NAME: 1, 
        "ncusts._id": 1,
        "ncusts.C_NAME": 1,
        "ncusts.corders.O_ORDERDATE": 1,
        "ncusts.corders.oparts.L_PARTKEY": 1,
        "ncusts.corders.oparts.L_QUANTITY": 1
    }},
    { $group : {
        _id: {
            "id0": "$_id",
            "id1": "$ncusts._id"
        },
        nname: { $first: "$N_NAME" },
        cname: { $first: "$ncusts.C_NAME" },
        corders: { $push: {
            $cond: [
                { $and: [
                    { $ne: ["$ncusts.corders.O_ORDERDATE", undefined] },
                    { $ne: ["$ncusts.corders.O_ORDERDATE", null] }
                ]},
                {  odate: "$ncusts.corders.O_ORDERDATE", oparts: "$ncusts.corders.oparts" },
                "$$REMOVE"
            ]
        }}
    }},
    { $group : {
        _id: "$_id.id0",
        nname: { $first: "$nname" },
        ncusts: { $push: {
            $cond: [
                { $and: [
                    { $ne: ["$cname", undefined] },
                    { $ne: ["$cname", null] }
                ]},
                { cname: "$cname", corders: "$corders" },
                "$$REMOVE"
            ]
        }}
    }},
    { $merge: { into: "TPCH_Flat_Nested_Depth3_Result", on: "_id", whenMatched: "replace",  whenNotMatched: "insert" } }
  ],
  { allowDiskUse: true }
)
print(new Date - d + 'ms');

