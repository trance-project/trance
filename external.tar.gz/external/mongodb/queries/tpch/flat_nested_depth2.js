use tpch;

// Local input and output

db.Orders.createIndex( { O_CUSTKEY: 1 } );
db.Lineitem.createIndex( { L_ORDERKEY: 1 } );

d = new Date; 
db.Customer.aggregate([
    { $project: { C_CUSTKEY: 1, C_NAME: 1 } },
    { $lookup: {
        from: "Orders",
        localField: "C_CUSTKEY",
        foreignField: "O_CUSTKEY",
        as: "corders"
    }},
    { $project: { 
        C_NAME: 1, 
        "corders.O_ORDERKEY": 1,
        "corders.O_ORDERDATE": 1 
    }},
    { $unwind: {
        path: "$corders",
        preserveNullAndEmptyArrays: true
    }},
    { $lookup: {
        from: "Lineitem",
        localField: "corders.O_ORDERKEY",
        foreignField: "L_ORDERKEY",
        as: "corders.oparts"
    }},
    { $project: {
        C_NAME: 1, 
        "corders.O_ORDERDATE": 1,
        "corders.oparts.L_PARTKEY": 1,
        "corders.oparts.L_QUANTITY": 1
    }},
    { $group : {
        _id: "$_id",
        cname: { $first: "$C_NAME" },
        corders: { $push: {
            $cond: [
                { $and: [
                    { $ne: ["$corders.O_ORDERDATE", undefined] },
                    { $ne: ["$corders.O_ORDERDATE", null] }
                ]},
                { odate: "$corders.O_ORDERDATE", oparts: "$corders.oparts" },
                "$$REMOVE"
            ]
        }}
    }},
    { $out: "TPCH_Flat_Nested_Depth2_Result" }
  ],
  { allowDiskUse: true }
)
print(new Date - d + 'ms');

// Slower alternative

// d = new Date; 
// db.Customer.aggregate([
//     { $project: { C_CUSTKEY: 1, C_NAME: 1 } },
//     { $lookup: {
//         from: "Orders",
//         let: { custkey: "$C_CUSTKEY" },
//         pipeline: [
//             { $match: { $expr: { $eq: [ "$O_CUSTKEY", "$$custkey" ] } } },
//             { $project: { O_ORDERKEY: 1, O_ORDERDATE: 1 } },
//             { $lookup: {
//                 from: "Lineitem",
//                 let: { orderkey: "$O_ORDERKEY" },
//                 pipeline: [
//                     { $match: { $expr: { $eq: [ "$L_ORDERKEY", "$$orderkey" ] } } },
//                     { $project: { L_PARTKEY: 1, L_QUANTITY: 1, _id: 0 } }
//                 ],
//                 as: "oparts"
//             }},
//             { $project: { O_ORDERKEY: 0, _id: 0 } }
//         ],
//         as: "corders"
//     }},
//     { $project: { C_CUSTKEY: 0 } },
//     { $out: "TPCH_Flat_Nested_Depth2_Result" }
// ])
// print(new Date - d + 'ms');
