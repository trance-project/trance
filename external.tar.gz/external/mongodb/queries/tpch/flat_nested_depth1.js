use tpch;

// Local input and output

db.Lineitem.createIndex( { L_ORDERKEY: 1 } );

d = new Date; 
db.Orders.aggregate([
    { $project: { O_ORDERKEY: 1, O_ORDERDATE: 1 } },
    { $lookup: {
        from: "Lineitem",
        localField: "O_ORDERKEY",
        foreignField: "L_ORDERKEY",
        as: "oparts"
    }},
    { $project: { 
         O_ORDERDATE: 1,
        "oparts.L_PARTKEY": 1,
        "oparts.L_QUANTITY": 1
    }},
    { $out: "TPCH_Flat_Nested_Depth1_Result" }
  ],
  { allowDiskUse: true }
)
print(new Date - d + 'ms');

// Slower alternative

// d = new Date; 
// db.Orders.aggregate([
//     { $project: { O_ORDERKEY: 1, O_ORDERDATE: 1 } },
//     { $lookup: {
//         from: "Lineitem",
//         let: { orderkey: "$O_ORDERKEY" },
//         pipeline: [
//             { $match: { $expr: { $eq: [ "$L_ORDERKEY", "$$orderkey" ] } } },
//             { $project: { L_PARTKEY: 1, L_QUANTITY: 1, _id: 0 } }
//         ],
//         as: "oparts"
//     }},
//     { $project: { O_ORDERKEY: 0 } },
//     { $out: "TPCH_Flat_Nested_Depth1_Result" }
// ])
// print(new Date - d + 'ms');
