use tpch;

// Local output

db.Part.createIndex( { P_PARTKEY: 1 }, { unique: true } );

d = new Date; 
db.TPCH_Flat_Nested_Depth0_Result.aggregate([
    { $lookup: {
        from: "Part",
        localField: "L_PARTKEY",
        foreignField: "P_PARTKEY",
        as: "oparts"
    }},
    { $project: {
        L_QUANTITY: 1,
        "oparts.P_NAME": 1, 
        "oparts.P_RETAILPRICE": 1
    }},
    { $unwind: {
        path: "$oparts",
        preserveNullAndEmptyArrays: true
    }},
    { $group : {
        _id: "$oparts.P_NAME",
        total: { $sum: { $multiply: [ "$L_QUANTITY", "$oparts.P_RETAILPRICE" ] } }
    }},
    { $out: "TPCH_Nested_Flat_Depth0_Result" }
  ],
  { allowDiskUse: true }
)
print(new Date - d + 'ms');


// Slower alternative

// d = new Date; 
// db.TPCH_Flat_Nested_Depth0_Result.aggregate([
//     { $lookup: {
//         from: "Part",
//         let: { partkey: "$L_PARTKEY", qty: "$L_QUANTITY" },
//         pipeline: [
//             { $match: { $expr: { $eq: [ "$P_PARTKEY", "$$partkey" ] } } },
//             { $project: { 
//                 _id: 0,
//                 P_NAME: 1, 
//                 total: { $multiply: [ "$$qty", "$P_RETAILPRICE" ] }
//             }}
//         ],
//         as: "oparts"
//     }},
//     { $unwind: {
//         path: "$oparts",
//         preserveNullAndEmptyArrays: true
//     }},
//     { $group : {
//         _id: "$oparts.P_NAME",
//         total: { $sum: "$oparts.total" }
//     }},
//     { $out: "TPCH_Nested_Flat_Depth0_Result" }
//   ],
//   { allowDiskUse: true }
// )
// print(new Date - d + 'ms');

db.TPCH_Nested_Flat_Depth0_Result.drop()
