use tpch;

// Sharded input and output

db.TPCH_Flat_Nested_Depth1_Result.drop();
sh.shardCollection("tpch.TPCH_Flat_Nested_Depth1_Result", { _id: "hashed" } );

db.Lineitem.createIndex( { L_ORDERKEY: 1 } );

d = new Date; 
db.OrdersSharded.aggregate([
    { $project: { O_ORDERKEY: 1, O_ORDERDATE: 1 } },
    { $lookup: {
        from: "Lineitem",
        localField: "O_ORDERKEY",
        foreignField: "L_ORDERKEY",
        as: "oparts"
    }},
    { $project: { 
        O_ORDERDATE: 1,
        "oparts.L_PARTKEY": 1,
        "oparts.L_QUANTITY": 1
    }},
    { $merge: { into: "TPCH_Flat_Nested_Depth1_Result", on: "_id", whenMatched: "replace",  whenNotMatched: "insert" } }
  ],
  { allowDiskUse: true }
)
print(new Date - d + 'ms');
