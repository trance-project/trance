use tpch;

// Local output

db.Part.createIndex( { P_PARTKEY: 1 }, { unique: true } );

d = new Date; 
db.TPCH_Flat_Nested_Depth2_Result.aggregate([
    { $unwind: {
        path: "$corders",
        includeArrayIndex: "corders._id",
        preserveNullAndEmptyArrays: true
    }},
    { $unwind: {
        path: "$corders.oparts",
        preserveNullAndEmptyArrays: true
    }},
    { $lookup: {
        from: "Part",
        localField: "corders.oparts.L_PARTKEY",
        foreignField: "P_PARTKEY",
        as: "oparts2"
    }},
    { $project: {
        "cname": 1,
        "corders._id": 1,
        "corders.odate": 1,
        "corders.oparts.L_QUANTITY": 1,
        "oparts2.P_NAME": 1, 
        "oparts2.P_RETAILPRICE": 1
    }},
    { $unwind: {
        path: "$oparts2",
        preserveNullAndEmptyArrays: true
    }},
    { $group : {
        _id: {
            id0: "$_id",
            id1: "$corders._id",
            pname: "$oparts2.P_NAME"
        },
        cname: { $first: "$cname" },
        odate: { $first: "$corders.odate" },
        total: { $sum: { $multiply: [ "$corders.oparts.L_QUANTITY", "$oparts2.P_RETAILPRICE" ] } }
    }},
    { $group : {
        _id: {
            id0: "$_id.id0",
            id1: "$_id.id1"
        },
        cname: { $first: "$cname" },
        odate: { $first: "$odate" },
        oparts: { $push: {
            $cond: [
                { $ne: ["$_id.pname", null] },
                { pname: "$_id.pname", total: "$total" },
                "$$REMOVE"
            ]
        }}
    }},
    { $group : {
        _id: "$_id.id0",
        cname: { $first: "$cname" },
        corders: { $push: {
            $cond: [
                { $ne: ["$odate", null] },
                { odate: "$odate", oparts: "$oparts" },
                "$$REMOVE"
            ]
        }}
    }},
    { $out: "TPCH_Nested_Nested_Depth2_Result" }
  ],
  { allowDiskUse: true }
)
print(new Date - d + 'ms');

// Slower alternative

// d = new Date; 
// db.TPCH_Flat_Nested_Depth2_Result.aggregate([
//     { $unwind: {
//         path: "$corders",
//         includeArrayIndex: "corders._id",
//         preserveNullAndEmptyArrays: true
//     }},
//     { $unwind: {
//         path: "$corders.oparts",
//         preserveNullAndEmptyArrays: true
//     }},
//     { $lookup: {
//         from: "Part",
//         let: { partkey: "$corders.oparts.L_PARTKEY", qty: "$corders.oparts.L_QUANTITY" },
//         pipeline: [
//             { $match: { $expr: { $eq: [ "$P_PARTKEY", "$$partkey" ] } } },
//             { $project: { 
//                 _id: 0,
//                 P_NAME: 1, 
//                 total: { $multiply: [ "$$qty", "$P_RETAILPRICE" ] }
//             }}
//         ],
//         as: "corders.oparts"
//     }},
//     { $unwind: {
//         path: "$corders.oparts",
//         preserveNullAndEmptyArrays: true
//     }},
//     { $group : {
//         _id: {
//             id0: "$_id",
//             id1: "$corders._id",
//             pname: "$corders.oparts.P_NAME"
//         },
//         cname: { $first: "$cname" },
//         odate: { $first: "$corders.odate" },
//         total: { $sum: "$corders.oparts.total" }
//     }},
//     { $group : {
//         _id: {
//             id0: "$_id.id0",
//             id1: "$_id.id1"
//         },
//         cname: { $first: "$cname" },
//         odate: { $first: "$odate" },
//         oparts: { $push: {
//             $cond: [
//                 { $ne: ["$_id.pname", null] },
//                 { pname: "$_id.pname", total: "$total" },
//                 "$$REMOVE"
//             ]
//         }}
//     }},
//     { $group : {
//         _id: "$_id.id0",
//         cname: { $first: "$cname" },
//         corders: { $push: {
//             $cond: [
//                 { $ne: ["$odate", null] },
//                 { odate: "$odate", oparts: "$oparts" },
//                 "$$REMOVE"
//             ]
//         }}
//     }},
//     { $out: "TPCH_Nested_Nested_Depth2_Result" }
//   ],
//   { allowDiskUse: true }
// )
// print(new Date - d + 'ms');

db.TPCH_Nested_Nested_Depth2_Result.drop()
