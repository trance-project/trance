use tpch;

// Local input and sharded output

db.TPCH_Flat_Nested_Depth4_Result.drop();
sh.shardCollection("tpch.TPCH_Flat_Nested_Depth4_Result", { _id: "hashed" } );

db.Nation.createIndex( { N_REGIONKEY: 1 } );
db.Customer.createIndex( { C_NATIONKEY: 1 } );
db.Orders.createIndex( { O_CUSTKEY: 1 } );
db.Lineitem.createIndex( { L_ORDERKEY: 1 } );

d = new Date; 
db.Region.aggregate([
    { $project: { R_REGIONKEY: 1, R_NAME: 1 } },
    { $lookup: {
        from: "Nation",
        localField: "R_REGIONKEY",
        foreignField: "N_REGIONKEY",
        as: "rnations"
    }},
    { $project: { 
        R_NAME: 1, 
        "rnations._id": 1,
        "rnations.N_NAME": 1,
        "rnations.N_NATIONKEY": 1
    }},
    { $unwind: {
        path: "$rnations",
        preserveNullAndEmptyArrays: true
    }},
    { $lookup: {
        from: "Customer",
        localField: "rnations.N_NATIONKEY",
        foreignField: "C_NATIONKEY",
        as: "rnations.ncusts"
    }},
    { $project: { 
        R_NAME: 1, 
        "rnations._id": 1,
        "rnations.N_NAME": 1,
        "rnations.ncusts._id": 1,
        "rnations.ncusts.C_NAME": 1,
        "rnations.ncusts.C_CUSTKEY": 1        
    }},
    { $unwind: {
        path: "$rnations.ncusts",
        preserveNullAndEmptyArrays: true
    }},
    { $lookup: {
        from: "Orders",
        localField: "rnations.ncusts.C_CUSTKEY",
        foreignField: "O_CUSTKEY",
        as: "rnations.ncusts.corders"
    }},
    { $project: { 
        R_NAME: 1,
        "rnations._id": 1,
        "rnations.N_NAME": 1,
        "rnations.ncusts._id": 1,
        "rnations.ncusts.C_NAME": 1,
        "rnations.ncusts.corders.O_ORDERDATE": 1,
        "rnations.ncusts.corders.O_ORDERKEY": 1        
    }},
    { $unwind: {
        path: "$rnations.ncusts.corders",
        preserveNullAndEmptyArrays: true
    }},
    { $lookup: {
        from: "Lineitem",
        localField: "rnations.ncusts.corders.O_ORDERKEY",
        foreignField: "L_ORDERKEY",
        as: "rnations.ncusts.corders.oparts"
    }},
    { $project: {
        R_NAME: 1,
        "rnations._id": 1,
        "rnations.N_NAME": 1,
        "rnations.ncusts._id": 1,
        "rnations.ncusts.C_NAME": 1,
        "rnations.ncusts.corders.O_ORDERDATE": 1,
        "rnations.ncusts.corders.oparts.L_PARTKEY": 1,
        "rnations.ncusts.corders.oparts.L_QUANTITY": 1
    }},
    { $group : {
        _id: {
            "id0": "$_id",
            "id1": "$rnations._id",
            "id2": "$rnations.ncusts._id",
        },
        rname: { $first: "$R_NAME" },
        nname: { $first: "$rnations.N_NAME" },
        cname: { $first: "$rnations.ncusts.C_NAME" },
        corders: { $push: {
            $cond: [
                { $and: [
                    { $ne: ["$rnations.ncusts.corders.O_ORDERDATE", undefined] },
                    { $ne: ["$rnations.ncusts.corders.O_ORDERDATE", null] }
                ]},
                {  odate: "$rnations.ncusts.corders.O_ORDERDATE", oparts: "$rnations.ncusts.corders.oparts" },
                "$$REMOVE"
            ]
        }}
    }},
    { $group : {
        _id: {
            "id0": "$_id.id0",
            "id1": "$_id.id1"
        },
        rname: { $first: "$rname" },
        nname: { $first: "$nname" },
        ncusts: { $push: {
            $cond: [
                { $and: [
                    { $ne: ["$cname", undefined] },
                    { $ne: ["$cname", null] }
                ]},
                {  cname: "$cname", corders: "$corders" },
                "$$REMOVE"
            ]
        }}
    }},    
    { $group : {
        _id: "$_id.id0",
        rname: { $first: "$rname" },
        rnations: { $push: {
            $cond: [
                { $and: [
                    { $ne: ["$nname", undefined] },
                    { $ne: ["$nname", null] }
                ]},
                { nname: "$nname", ncusts: "$ncusts" },
                "$$REMOVE"
            ]
        }}
    }},
    { $merge: { into: "TPCH_Flat_Nested_Depth4_Result", on: "_id", whenMatched: "replace",  whenNotMatched: "insert" } }
  ],
  { allowDiskUse: true }
)
print(new Date - d + 'ms');
