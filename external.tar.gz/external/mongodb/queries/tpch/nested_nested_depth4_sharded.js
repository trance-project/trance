use tpch;

// Sharded output

db.TPCH_Nested_Nested_Depth4_Result.drop();
sh.shardCollection("tpch.TPCH_Nested_Nested_Depth4_Result", { _id: "hashed" } );

db.Part.createIndex( { P_PARTKEY: 1 }, { unique: true } );

d = new Date; 
db.TPCH_Flat_Nested_Depth4_Result.aggregate([
    { $unwind: {
        path: "$rnations",
        includeArrayIndex: "rnations._id",
        preserveNullAndEmptyArrays: true
    }},
    { $unwind: {
        path: "$rnations.ncusts",
        includeArrayIndex: "rnations.ncusts._id",
        preserveNullAndEmptyArrays: true
    }},
    { $unwind: {
        path: "$rnations.ncusts.corders",
        includeArrayIndex: "rnations.ncusts.corders._id",
        preserveNullAndEmptyArrays: true
    }},
    { $unwind: {
        path: "$rnations.ncusts.corders.oparts",
        preserveNullAndEmptyArrays: true
    }},
    { $lookup: {
        from: "Part",
        localField: "rnations.ncusts.corders.oparts.L_PARTKEY",
        foreignField: "P_PARTKEY",
        as: "oparts2"
    }},
    { $project: {
        "rname": 1,
        "rnations._id": 1,
        "rnations.nname": 1,
        "rnations.ncusts._id": 1,
        "rnations.ncusts.cname": 1,
        "rnations.ncusts.corders._id": 1,
        "rnations.ncusts.corders.odate": 1,
        "rnations.ncusts.corders.oparts.L_QUANTITY": 1,
        "oparts2.P_NAME": 1, 
        "oparts2.P_RETAILPRICE": 1
    }},
    { $unwind: {
        path: "$oparts2",
        preserveNullAndEmptyArrays: true
    }},
    { $group : {
        _id: {
            id0: "$_id", 
            id1: "$rnations._id",
            id2: "$rnations.ncusts._id",
            id3: "$rnations.ncusts.corders._id",
            pname: "$oparts2.P_NAME"
        },
        rname: { $first: "$rname" },
        nname: { $first: "$rnations.nname" },
        cname: { $first: "$rnations.ncusts.cname" },
        odate: { $first: "$rnations.ncusts.corders.odate" },
        total: { $sum: { $multiply: [ "$rnations.ncusts.corders.oparts.L_QUANTITY", "$oparts2.P_RETAILPRICE" ] } }
    }},
    { $group : {
        _id: {
            id0: "$_id.id0",
            id1: "$_id.id1",
            id2: "$_id.id2",
            id3: "$_id.id3"
        },
        rname: { $first: "$rname" },
        nname: { $first: "$nname" },
        cname: { $first: "$cname" },
        odate: { $first: "$odate" },
        oparts: { $push: {
            $cond: [
                { $ne: ["$_id.pname", null] },
                { pname: "$_id.pname", total: "$total" },
                "$$REMOVE"
            ]
        }}
    }},
    { $group : {
        _id: {
            id0: "$_id.id0",
            id1: "$_id.id1",
            id2: "$_id.id2",
        },
        rname: { $first: "$rname" },
        nname: { $first: "$nname" },
        cname: { $first: "$cname" },
        corders: { $push: {
            $cond: [
                { $ne: ["$odate", null] },
                { odate: "$odate", oparts: "$oparts" },
                "$$REMOVE"
            ]
        }}
    }},
    { $group : {
        _id: {
            id0: "$_id.id0",
            id1: "$_id.id1"
        },
        rname: { $first: "$rname" },
        nname: { $first: "$nname" },
        ncusts: { $push: {
            $cond: [
                { $ne: ["$cname", null] },
                { cname: "$cname", corders: "$corders" },
                "$$REMOVE"
            ]
        }}
    }},
    { $group : {
        _id: "$_id.id0",
        rname: { $first: "$rname" },
        rnations: { $push: {
            $cond: [
                { $ne: ["$nname", null] },
                { nname: "$nname", ncusts: "$ncusts" },
                "$$REMOVE"
            ]
        }}
    }},
    { $merge: { into: "TPCH_Nested_Nested_Depth4_Result", on: "_id", whenMatched: "replace",  whenNotMatched: "insert" } }
  ],
  { allowDiskUse: true }
)
print(new Date - d + 'ms');

db.TPCH_Nested_Nested_Depth4_Result.drop()
