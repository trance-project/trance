use tpch;

// Local output

db.Part.createIndex( { P_PARTKEY: 1 }, { unique: true } );

d = new Date; 
db.TPCH_Flat_Nested_Depth4_Result.aggregate([
    { $unwind: {
        path: "$rnations",
        preserveNullAndEmptyArrays: true
    }},
    { $unwind: {
        path: "$rnations.ncusts",
        preserveNullAndEmptyArrays: true
    }},
    { $unwind: {
        path: "$rnations.ncusts.corders",
        preserveNullAndEmptyArrays: true
    }},
    { $unwind: {
        path: "$rnations.ncusts.corders.oparts",
        preserveNullAndEmptyArrays: true
    }},
    { $lookup: {
        from: "Part",
        localField: "rnations.ncusts.corders.oparts.L_PARTKEY",
        foreignField: "P_PARTKEY",
        as: "oparts2"
    }},
    { $project: {
        "rname": 1,
        "rnations.ncusts.corders.oparts.L_QUANTITY": 1,
        "oparts2.P_RETAILPRICE": 1
    }},
    { $unwind: {
        path: "$oparts2",
        preserveNullAndEmptyArrays: true
    }},
    { $group : {
        _id: "$rname",
        total: { $sum: { $multiply: [ "$rnations.ncusts.corders.oparts.L_QUANTITY", "$oparts2.P_RETAILPRICE" ] } }
    }},
    { $out: "TPCH_Nested_Flat_Depth4_Result" }
  ],   
  { allowDiskUse: true }
)
print(new Date - d + 'ms');

// Slower alternative

// d = new Date; 
// db.TPCH_Flat_Nested_Depth4_Result.aggregate([
//     { $unwind: {
//         path: "$rnations",
//         preserveNullAndEmptyArrays: true
//     }},
//     { $unwind: {
//         path: "$rnations.ncusts",
//         preserveNullAndEmptyArrays: true
//     }},
//     { $unwind: {
//         path: "$rnations.ncusts.corders",
//         preserveNullAndEmptyArrays: true
//     }},
//     { $unwind: {
//         path: "$rnations.ncusts.corders.oparts",
//         preserveNullAndEmptyArrays: true
//     }},
//     { $lookup: {
//         from: "Part",
//         let: { partkey: "$rnations.ncusts.corders.oparts.L_PARTKEY", qty: "$rnations.ncusts.corders.oparts.L_QUANTITY" },
//         pipeline: [
//             { $match: { $expr: { $eq: [ "$P_PARTKEY", "$$partkey" ] } } },
//             { $project: { 
//                 _id: 0,
//                 P_NAME: 1, 
//                 total: { $multiply: [ "$$qty", "$P_RETAILPRICE" ] }
//             }}
//         ],
//         as: "rnations.ncusts.corders.oparts"
//     }},
//     { $unwind: {
//         path: "$rnations.ncusts.corders.oparts",
//         preserveNullAndEmptyArrays: true
//     }},
//     { $group : {
//         _id: "$rname",
//         total: { $sum: "$rnations.ncusts.corders.oparts.total" }
//     }},
//     { $out: "TPCH_Nested_Flat_Depth4_Result" }
//   ],   
//   { allowDiskUse: true }
// )
// print(new Date - d + 'ms');

db.TPCH_Nested_Flat_Depth4_Result.drop()
