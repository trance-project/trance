use tpch;

// Sharded input and output

db.TPCH_Flat_Nested_Depth0_Result.drop();
sh.shardCollection("tpch.TPCH_Flat_Nested_Depth0_Result", { _id: "hashed" } );

d = new Date; 
db.LineitemSharded.aggregate([
    { $project: { L_PARTKEY: 1, L_QUANTITY: 1 } },
    { $merge: { into: "TPCH_Flat_Nested_Depth0_Result", on: "_id", whenMatched: "replace",  whenNotMatched: "insert" } }
])
print(new Date - d + 'ms');
