use tpch;

// Sharded output

db.TPCH_Nested_Nested_Depth0_Result.drop();
sh.shardCollection("tpch.TPCH_Nested_Nested_Depth0_Result", { _id: "hashed" } );

db.Part.createIndex( { P_PARTKEY: 1 }, { unique: true } );

d = new Date; 
db.TPCH_Flat_Nested_Depth0_Result.aggregate([
    { $lookup: {
        from: "Part",
        localField: "L_PARTKEY",
        foreignField: "P_PARTKEY",
        as: "oparts"
    }},
    { $project: {
        L_QUANTITY: 1,
        "oparts.P_NAME": 1, 
        "oparts.P_RETAILPRICE": 1
    }},
    { $unwind: {
        path: "$oparts",
        preserveNullAndEmptyArrays: true
    }},
    { $group : {
        _id: "$oparts.P_NAME",
        total: { $sum: { $multiply: [ "$L_QUANTITY", "$oparts.P_RETAILPRICE" ] } }
    }},
    { $merge: { into: "TPCH_Nested_Nested_Depth0_Result", on: "_id", whenMatched: "replace",  whenNotMatched: "insert" } }
  ],
  { allowDiskUse: true }
)
print(new Date - d + 'ms');

db.TPCH_Nested_Nested_Depth0_Result.drop()
