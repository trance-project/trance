use tpch;

// Sharded output

db.TPCH_Nested_Nested_Depth1_Result.drop();
sh.shardCollection("tpch.TPCH_Nested_Nested_Depth1_Result", { _id: "hashed" } );

db.Part.createIndex( { P_PARTKEY: 1 }, { unique: true } );

d = new Date; 
db.TPCH_Flat_Nested_Depth1_Result.aggregate([
    { $unwind: {
        path: "$oparts",
        preserveNullAndEmptyArrays: true
    }},
    { $lookup: {
        from: "Part",
        localField: "oparts.L_PARTKEY",
        foreignField: "P_PARTKEY",
        as: "oparts2"
    }},
    { $project: {
        O_ORDERDATE: 1,
        "oparts.L_QUANTITY": 1,
        "oparts2.P_NAME": 1, 
        "oparts2.P_RETAILPRICE": 1
    }},
    { $unwind: {
        path: "$oparts2",
        preserveNullAndEmptyArrays: true
    }},
    { $group : {
        _id: {
            id0: "$_id",
            pname: "$oparts2.P_NAME"
        },
        odate: { $first: "$O_ORDERDATE" },
        total: { $sum: { $multiply: [ "$oparts.L_QUANTITY", "$oparts2.P_RETAILPRICE" ] } }
    }},
    { $group : {
        _id: "$_id.id0",
        odate: { $first: "$odate" },
        oparts: { $push: {
            $cond: [
                { $ne: ["$_id.pname", null] },
                { pname: "$_id.pname", total: "$total" },
                "$$REMOVE"
            ]
        }}
    }},
    { $merge: { into: "TPCH_Nested_Nested_Depth1_Result", on: "_id", whenMatched: "replace",  whenNotMatched: "insert" } }
  ],
  { allowDiskUse: true }
)
print(new Date - d + 'ms');

db.TPCH_Nested_Nested_Depth1_Result.drop()
