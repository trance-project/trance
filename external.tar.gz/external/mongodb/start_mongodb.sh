#!/bin/bash

export PATH="/Users/milllic/repo/papers/shredding/experiments/mongodb/mongodb-macos-x86_64-4.2.8/bin:$PATH"

mongod --dbpath mongodb/data/db