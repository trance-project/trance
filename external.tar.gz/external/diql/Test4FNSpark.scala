import edu.uta.diql._
import org.apache.spark._
import org.apache.spark.sql.SparkSession
import org.apache.spark.rdd._
import org.apache.log4j._

object Test {
  case class Region(r_regionkey: Int, r_name: String, r_comment: String)
  case class Nation(n_nationkey: Int, n_name: String, n_regionkey: Int, n_comment: String)
  case class Customer(c_custkey: Int, c_name: String, c_address: String, c_nationkey: Int, c_phone: String, c_acctbal: Double, c_mktsegment: String, c_comment: String)

  case class Order(o_orderkey: Int, o_custkey: Int, o_orderstatus: String, o_totalprice: Double, o_orderdate: String, o_orderpriority: String, o_clerk: String, o_shippriority: Int, o_comment: String)

  case class Lineitem(l_orderkey: Int, l_partkey: Int, l_suppkey: Int, l_linenumber: Int, l_quantity: Double, l_extendedprice: Double, l_discount: Double, l_tax: Double, l_returnflag: String, l_linestatus: String, l_shipdate: String, l_commitdate: String, l_receiptdate: String, l_shipinstruct: String, l_shipmode: String, l_comment: String)
  
  case class L(lqty: Double, lpk: Int)
  case class L0(lok: Int, ls: Traversable[L])
  case class O(orderdate: String, oparts: Traversable[L])
  case class O0(oid: (Int, String), oparts: Traversable[L])
  case class C0(cid: (Int, String), corders: Traversable[O])
  case class N0(nid: (Int, String), ncusts: Traversable[C])
  case class N(nname: String, ncusts: Traversable[C])
  case class R(rname: String, rnations: Traversable[N])
  case class TestMe(cname: String, cadd: String)
  case class C(cname: String, corders: Traversable[O])


  def main ( args: Array[String] ) {
    
    val basepath = "/nfs_qc4/tpch/sfs100ns/"
    val RF = s"$basepath/region.tbl"
    val NF = s"$basepath/nation.tbl"
    val CF = s"$basepath/customer.tbl"
    val OF = s"$basepath/order.tbl"
    val LF = s"$basepath/lineitem.tbl"
    val conf = new SparkConf().setAppName("DIQLTest4FN")
    val spark = SparkSession.builder().config(conf).getOrCreate()
    val sc = spark.sparkContext

    val regions = sc.textFile(RF).map{ line => line.split("\\|")
                          match { case Array(a1,a2,a3) => Region(a1.toInt,a2,a3)} }
    regions.cache
    regions.count

    val nations = sc.textFile(NF).map{ line => line.split("\\|")
                          match { case Array(a1,a2,a3,a4) => 
			    Nation(a1.toInt,a2,a3.toInt,a4.toString)} }
    nations.cache
    nations.count

    val customers = sc.textFile(CF).map{ line => line.split("\\|")
                          match { case Array(a1,a2,a3,a4,a5,a6,a7,a8) => 
						  	Customer(a1.toInt,a2,a3,a4.toInt,a5,a6.toDouble,a7,a8) } }
    customers.cache
    customers.count

	val orders = sc.textFile(OF).map{ line => line.split("\\|")
                          match { case Array(a1,a2,a3,a4,a5,a6,a7,a8,a9) => 
	  					  	Order(a1.toInt,a2.toInt,a3,a4.toDouble,a5,a6,a7,a8.toInt,a9)}}
    orders.cache
    orders.count
          
	val lineitem = sc.textFile(LF).map{ line => line.split("\\|")
                          match { case Array(a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15,a16) => 
						  	Lineitem(a1.toInt,a2.toInt,a3.toInt,a4.toInt,a5.toDouble,a6.toDouble,a7.toDouble,a8.toDouble,a9,a10,a11,a12,a13,a14,a15,a16) }}
    lineitem.cache
    lineitem.count

    val t: Long = System.currentTimeMillis()

    q("""
        let step1 = select O0(o1, orderParts._2)
                      from orderParts <- (select (key, opart)
                        from o <- orders, key = (o.o_custkey, o.o_orderdate) group by k1: o.o_orderkey
                        from l <- lineitem, opart = L(l.l_quantity, l.l_partkey) group by k2: l.l_orderkey),
                      o1 <- orderParts._1
        in 
        let step2 = select C0(c1, custOrders._2)
                      from custOrders <- (select (key2, corder)
                                  from c <- customers, key2 = (c.c_nationkey, c.c_name) group by k3: c.c_custkey
                                  from s <- step1, corder = O(s.oid._2, s.oparts) group by k4: s.oid._1),
                     c1 <- custOrders._1 
        in 
        let step3 = select N0(n1, nationCusts._2)
            from nationCusts <- (select (key3, ncust)
                                  from n <- nations, key3 = (n.n_regionkey, n.n_name) group by k5: n.n_nationkey
                                  from s2 <- step2, ncust = C(s2.cid._2, s2.corders) group by k6: s2.cid._1),
                n1 <- nationCusts._1
        in select R(r1, regionNats._2)
            from regionNats <- (select (rname, rnat)
                                from r <- regions, rname = r.r_name group by k7: r.r_regionkey
                                from s3 <- step3, rnat = N(s3.nid._2, s3.ncusts) group by k8: s3.nid._1),
                r1 <- regionNats._1
      """).count 

    sc.stop()

    println("**** DIQL Spark run time Test4FN: "+(System.currentTimeMillis()-t)/1000.0+" secs")
  }
}
