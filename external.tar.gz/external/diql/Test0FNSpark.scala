import edu.uta.diql._
import org.apache.spark._
import org.apache.spark.sql.SparkSession
import org.apache.spark.rdd._
import org.apache.log4j._

object Test {

  case class Customer(c_custkey: Int, c_name: String, c_address: String, c_nationkey: Int, c_phone: String, c_acctbal: Double, c_mktsegment: String, c_comment: String)

  case class Order(o_orderkey: Int, o_custkey: Int, o_orderstatus: String, o_totalprice: Double, o_orderdate: String, o_orderpriority: String, o_clerk: String, o_shippriority: Int, o_comment: String)

  case class Lineitem(l_orderkey: Int, l_partkey: Int, l_suppkey: Int, l_linenumber: Int, l_quantity: Double, l_extendedprice: Double, l_discount: Double, l_tax: Double, l_returnflag: String, l_linestatus: String, l_shipdate: String, l_commitdate: String, l_receiptdate: String, l_shipinstruct: String, l_shipmode: String, l_comment: String)
  
  case class L(lqty: Double, lpk: Int)
  case class L0(lok: Int, ls: Traversable[L])
  case class O(orderdate: String, oparts: Traversable[L])
  case class O0(oid: (Int, String), oparts: Traversable[L])
  case class C0(cid: Int, cs: Traversable[TestMe])
  case class TestMe(cname: String, cadd: String)
  case class C(cname: String, corders: Traversable[O])


  def main ( args: Array[String] ) {
    
    val basepath = "/nfs_qc4/tpch/sfs100ns/"
    val LF = s"$basepath/lineitem.tbl"
    val conf = new SparkConf().setAppName("DIQLTest0FN")
    val spark = SparkSession.builder().config(conf).getOrCreate()
    val sc = spark.sparkContext

    val lineitem = sc.textFile(LF).map{ line => line.split("\\|")
                          match { case Array(a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15,a16) => 
						  	Lineitem(a1.toInt,a2.toInt,a3.toInt,a4.toInt,a5.toDouble,a6.toDouble,a7.toDouble,a8.toDouble,a9,a10,a11,a12,a13,a14,a15,a16) }}.repartition(1000)

    lineitem.cache
    lineitem.count

    val t: Long = System.currentTimeMillis()

    q("""
        select L(l.l_quantity, l.l_partkey) from l <- lineitem
      """).count

    sc.stop()

    println("**** DIQL Spark run time Test2FN: "+(System.currentTimeMillis()-t)/1000.0+" secs")
  }
}
