/*
cd shredder/executor/spark
spark-shell --master "spark://192.168.11.235:7077" \
  --executor-cores 4 \
  --num-executors 10 \
  --executor-memory 20G \
  --driver-memory 16G \
  --jars target/scala-2.12/sparkutils_2.12-0.1.jar
spark-shell --master "spark://192.168.11.235:7077" --executor-cores 4 --num-executors 5 --executor-memory 40G --driver-memory 30G --jars target/scala-2.12/sparkutils_2.12-0.1.jar
*/

import org.apache.spark.sql.SparkSession
import org.apache.spark.SparkConf

// For implicit conversions like converting RDDs to DataFrames
import spark.implicits._

import sparkutils.loader._
import sparkutils._

val conf = new SparkConf()
    .setMaster(Config.master)
    .setAppName("BioShellSpark")
    .set("spark.sql.shuffle.partitions", "1000")

val spark = SparkSession.builder().config(conf).getOrCreate()

val basepath = "/mnt/app_hdd/scratch/biodata/"

val biospecLoader = new BiospecLoader(spark)
val biospec = biospecLoader.load(s"$basepath/nationwidechildrens.org_biospecimen_aliquot_brca.txt")
biospec.cache
biospec.count
biospec.createOrReplaceTempView("BioSpec")

val consequenceLoader = new ConsequenceLoader(spark)
val consequences = consequenceLoader.loadSequential(s"$basepath/calc_variant_conseq.txt")
consequences.cache
consequences.count
consequences.createOrReplaceTempView("Consequences")

val occurrences = spark.read.json(s"file:///$basepath/datasetBrca/").as[OccurrenceMid]
occurrences.cache
occurrences.count
occurrences.createOrReplaceTempView("Occurrences")

val cnLoader = new CopyNumberLoader(spark)
val copynumber = cnLoader.load(s"$basepath/copyNumber/", true)
                                .withColumn("cn_gene_id", substring(col("cn_gene_id"), 1,15)).as[CopyNumber]
copynumber.cache
copynumber.count
copynumber.createOrReplaceTempView("CopyNumber")

val stringLoader = new NetworkLoader(spark)
val network = stringLoader.load(s"$basepath/9606.protein.links.full.v11.0.csv")
network.cache
network.count
network.createOrReplaceTempView("Network")

val bmartLoader = new BiomartLoader(spark)
val biomart = bmartLoader.load(s"$basepath/mart_export.txt")
biomart.cache
biomart.count
biomart.createOrReplaceTempView("Biomart")

val geLoader = new GeneExpressionLoader(spark)
val expression = geLoader.load(s"$basepath/expression/", true, aliquotFile = s"$basepath/fpkm_uq_case_aliquot_brca.txt")
       .withColumn("ge_gene_id", substring(col("ge_gene_id"), 1,15)).as[GeneExpression]
expression.cache
expression.count
expression.createOrReplaceTempView("Expression")

// Query 1 Hybrid Matrix: cnvCases will just join the sample to aliquot mapping table.

val hybridBySampleMid2 = 
  spark.sql("""
    SELECT B.bcr_patient_uuid AS hybrid_sample,
           B.bcr_aliquot_uuid AS hybrid_aliquot,
           B.center_id AS hybrid_center,
           (
              -- cast nulls to empty arrays
              SELECT coalesce(
                collect_list(struct(t2.hybrid_gene_id, t2.hybrid_score)),
                -- ugly hack to create an empty array of custom type in Spark 2.x 
                filter(array(cast(null as struct<hybrid_gene_id:string,hybrid_score:double>)), x -> isnotnull(x))
              )
              FROM (
                SELECT t1.gene_id AS hybrid_gene_id, 
                       SUM(
                         (C1.so_weight * 
                            CASE 
                              WHEN t1.impact = 'HIGH' THEN 0.8
                              WHEN t1.impact = 'MODERATE' THEN 0.5
                              WHEN t1.impact = 'LOW' THEN 0.3
                              WHEN t1.impact = 'MODIFIER' THEN 0.15
                              ELSE 0.01
                            END) *
                         (CASE 
                            WHEN t1.sift_score = 0.0 THEN 0.01
                            ELSE t1.sift_score
                          END) *
                         (CASE 
                            WHEN t1.polyphen_score = 0.0 THEN 0.01
                            ELSE t1.polyphen_score
                          END) *
                         (t1.cn_copy_number + 0.01)
                       ) AS hybrid_score
                FROM (
                  SELECT ct AS element,
                         FlatO.gene_id AS gene_id,
                         CnvCases.cn_copy_number AS cn_copy_number,
                         FlatO.impact AS impact,
                         FlatO.sift_score AS sift_score,
                         FlatO.polyphen_score AS polyphen_score
                  FROM (
                     SELECT am.case_id AS case_id, 
                            am.gene_id AS gene_id,
                            am.consequence_terms AS consequence_terms,
                            am.impact AS impact,
                            am.sift_score AS sift_score,
                            am.polyphen_score AS polyphen_score
                     FROM Occurrences O
                     LATERAL VIEW explode(O.transcript_consequences) AS am
                     WHERE O.donorId = B.bcr_patient_uuid
                  ) FlatO JOIN 
                  (
                    -- cnvCases
                    SELECT C.cn_end AS cn_end,
                           C.cn_chromosome AS cn_chromosome,
                           C.cn_start AS cn_start,
                           B2.bcr_patient_uuid AS cn_case_uuid,
                           C.cn_aliquot_uuid AS cn_aliquot_uuid,
                           C.cn_gene_name AS cn_gene_name,
                           C.cn_gene_id AS cn_gene_id,
                           C.min_copy_number AS min_copy_number,
                           C.max_copy_number AS max_copy_number,
                           C.cn_copy_number AS cn_copy_number
                      FROM CopyNumber C JOIN BioSpec B2 ON C.cn_aliquot_uuid = B2.bcr_aliquot_uuid
                  ) CnvCases
                  ON FlatO.case_id = CnvCases.cn_case_uuid AND 
                     FlatO.gene_id =  CnvCases.cn_gene_id
                  LATERAL VIEW explode(FlatO.consequence_terms) AS ct
                ) t1 
                JOIN Consequences C1 ON t1.element = C1.so_term
                GROUP BY t1.gene_id
              ) t2
           ) AS hybrid_genes
      FROM BioSpec B
  """)
hybridBySampleMid2.cache
spark.time(hybridBySampleMid2.show)
println("HybridBySampleMid2 done")
hybridBySampleMid2.createOrReplaceTempView("HybridBySampleMid2")

// Query 2 By Sample Network: flatNet flattens the network (which only has protein ids) 
// and joins with biomart (which is the map between protein id and gene id). 
// The standard pipeline never makes it past this point because the network join for 
// each sample shuffles a mass amount of data. 
//
// Spark SQL does not allow explode to be nested in the target of a SELECT clause,
// thus we need to first flatten HybridBySampleMid2 and then regroup.
//
val sampleNetworkNew = 
  spark.sql("""
    SELECT  t3.hybrid_sample AS network_sample,
            t3.hybrid_aliquot AS network_aliquot,
            t3.hybrid_center AS network_center,
            filter(
              collect_list(named_struct(
                "network_protein_id", t3.network_node,
                "distance", t3.distance 
              )),
              x -> isnotnull(x.network_protein_id)
            ) AS network_genes
    FROM (
      SELECT t2.hm_id AS hm_id,
             t2.hybrid_sample AS hybrid_sample,
             t2.hybrid_aliquot AS hybrid_aliquot,
             t2.hybrid_center AS hybrid_center,
             FN.network_node AS network_node,
             SUM(FN.network_combined * t2.hybrid_score) AS distance          
        FROM (
          SELECT HM.hm_id, HM.hybrid_sample, HM.hybrid_aliquot, HM.hybrid_center, 
                 hgene.hybrid_gene_id, hgene.hybrid_score
          FROM (
            SELECT monotonically_increasing_id() AS hm_id, *
            FROM HybridBySampleMid2 
          ) AS HM
          LATERAL VIEW OUTER explode(HM.hybrid_genes) AS hgene
        ) t2 
        LEFT OUTER JOIN (
          -- flatNet
          SELECT t1.node_protein AS network_node,
                 GP.gene_stable_id AS network_edge,
                 t1.combined_score AS network_combined
          FROM (
            SELECT N.node_protein AS node_protein, 
                   E.edge_protein AS edge_protein,
                   E.combined_score AS combined_score
              FROM Network N
              LATERAL VIEW explode(N.edges) AS E
          ) t1 
          JOIN Biomart GP ON t1.edge_protein = GP.protein_stable_id
        ) FN 
        ON t2.hybrid_gene_id = FN.network_edge
      GROUP BY t2.hm_id, t2.hybrid_sample, t2.hybrid_aliquot, t2.hybrid_center, FN.network_node
    ) t3
    GROUP BY t3.hm_id, t3.hybrid_sample, t3.hybrid_aliquot, t3.hybrid_center
  """)
sampleNetworkNew.cache
spark.time(sampleNetworkNew.show)
println("sampleNetworkNew done")
sampleNetworkNew.createOrReplaceTempView("SampleNetworkNew")

// Query 3 Effect Matrix
//
// Spark SQL does not allow explode to be nested in the target of a SELECT clause,
// thus we need to first flatten HybridBySampleMid2 and then regroup.

val effectBySampleNew =
  spark.sql("""
    SELECT t2.hybrid_sample AS effect_sample,
           t2.hybrid_aliquot AS effect_aliquot,
           t2.hybrid_center AS effect_center,
           filter(
            collect_list(named_struct(
              "effect_gene_id", t2.hybrid_gene_id, 
              "effect_protein_id", t3.fnetwork_protein_id,
              "effect", t2.hybrid_score * t3.fnetwork_distance
            )), 
            x -> isnotnull(x.effect_gene_id)
           ) AS effect_genes           
    FROM (
      SELECT HM.hm_id,
             HM.hybrid_sample,
             HM.hybrid_aliquot,
             HM.hybrid_center,
             hgene.hybrid_gene_id,
             hgene.hybrid_score
      FROM (
        SELECT monotonically_increasing_id() AS hm_id, *
        FROM HybridBySampleMid2 
      ) AS HM
      LATERAL VIEW OUTER explode(HM.hybrid_genes) AS hgene
    ) t2
    LEFT OUTER JOIN (
      -- flatSampNet
      SELECT t1.network_aliquot AS fnetwork_aliquot,
             t1.network_protein_id AS fnetwork_protein_id,
             GP.gene_stable_id AS fnetwork_gene_id,
             t1.distance AS fnetwork_distance
      FROM (
        SELECT SN.network_aliquot,
               NG.network_protein_id,
               NG.distance
        FROM SampleNetworkNew SN
        LATERAL VIEW explode(SN.network_genes) AS NG
      ) t1
      JOIN Biomart GP ON t1.network_protein_id = GP.protein_stable_id
    ) t3
    ON t2.hybrid_aliquot = t3.fnetwork_aliquot AND
       t2.hybrid_gene_id = t3.fnetwork_gene_id
    GROUP BY t2.hm_id, t2.hybrid_sample, t2.hybrid_aliquot, t2.hybrid_center
  """)
effectBySampleNew.cache
spark.time(effectBySampleNew.show)
println("effectBySampleNew done")
effectBySampleNew.createOrReplaceTempView("EffectBySampleNew")


// Query 4 Connection Matrix
//
// Spark SQL does not allow explode to be nested in the target of a SELECT clause,
// thus we need to first flatten EffectBySampleNew and then regroup.

val connectionBySampleNew =
  spark.sql("""
    SELECT t1.effect_sample AS connection_sample,
           t1.effect_aliquot AS connection_aliquot,
           t1.effect_center AS connection_center,
           filter(
              collect_list(named_struct(
                "connect_gene", t1.effect_gene_id,
                "connect_protein", t1.effect_protein_id,
                "gene_connectivity", t1.effect * FE.ge_fpkm
              )),
              x -> isnotnull(x.connect_gene)
           ) AS connect_genes
    FROM (
      SELECT EM.em_id,
             EM.effect_sample,
             EM.effect_aliquot,
             EM.effect_center,
             egene.effect_gene_id,
             egene.effect_protein_id,
             egene.effect
      FROM (
        SELECT monotonically_increasing_id() AS em_id, *
        FROM EffectBySampleNew 
      ) AS EM
      LATERAL VIEW OUTER explode(EM.effect_genes) AS egene
    ) t1
    LEFT OUTER JOIN Expression FE 
      ON t1.effect_gene_id = FE.ge_gene_id AND t1.effect_aliquot = FE.ge_aliquot
    GROUP BY t1.em_id, t1.effect_sample, t1.effect_aliquot, t1.effect_center
  """)
connectionBySampleNew.cache
spark.time(connectionBySampleNew.show)
println("connectionBySampleNew done")
connectionBySampleNew.createOrReplaceTempView("ConnectionBySampleNew")


// Query 5 Connectivity Scores

val geneConnectivityNew = 
  spark.sql("""
    SELECT cgene.connect_gene AS gene_id,
           SUM(cgene.gene_connectivity) AS connectivity
    FROM ConnectionBySampleNew EM
    LATERAL VIEW explode(EM.connect_genes) AS cgene
    GROUP BY cgene.connect_gene
  """)
geneConnectivityNew.cache
spark.time(geneConnectivityNew.show)
println("geneConnectivityNew done")
geneConnectivityNew.createOrReplaceTempView("GeneConnectivityNew")


// OccurGroupByCase := 
//   For b in biospec Union
//   {( o_case_id := b.bcr_patient_uuid,
//      o_mutations := For o in occurrences Union
//     If (o.donorId = b.bcr_patient_uuid) Then
//       {( vid := o.vid,
//          vend := o.vend,
//          Tumor_Seq_Allele1 := o.Tumor_Seq_Allele1,
//          allele_string := o.allele_string,
//          Reference_Allele := o.Reference_Allele,
//          oid := o.oid,
//          vstart := o.vstart,
//          aliquotId := b.bcr_aliquot_uuid,
//          o_trans_conseq := 
//             For a in o.transcript_consequences Union
//             {( protein_end := a.protein_end,
//                ts_strand := a.ts_strand,
//                o_conseq_terms := 
//                 For c in a.consequence_terms Union
//                   For cons in consequences Union
//                     If (cons.so_term = c.element) Then
//                       {( conseq_term := cons.so_term,
//                          conseq_weight := cons.so_weight )},
//                impact := a.impact,
//                gene_id := a.gene_id,
//                amino_acids := a.amino_acids,
//                cdna_start := a.cdna_start,
//                transcript_id := a.transcript_id,
//                cdna_end := a.cdna_end,
//                cds_end := a.cds_end,
//                cds_start := a.cds_start,
//                aliquot_id := a.aliquot_id,
//                protein_start := a.protein_start,
//                variant_allele := a.variant_allele,
//                codons := a.codons,
//                distance := a.distance )},
//          projectId := o.projectId,
//          donorId := o.donorId,
//          seq_region_name := o.seq_region_name,
//          chromosome := o.chromosome,
//          assembly_name := o.assembly_name,
//          end := o.end,
//          Tumor_Seq_Allele2 := o.Tumor_Seq_Allele2,
//          strand := o.strand,
//          start := o.start,
//          input := o.input,
//          most_severe_consequence := o.most_severe_consequence )} )}
// 

val occurGroupByCaseMid =
  spark.sql("""
    SELECT t4.bcr_patient_uuid AS o_case_id,
           filter(
             collect_list(named_struct(
                "vid", t4.vid,
                "vend", t4.vend,
                "Tumor_Seq_Allele1", t4.Tumor_Seq_Allele1,
                "allele_string", t4.allele_string,
                "Reference_Allele", t4.Reference_Allele,
                "oid", t4.oid,
                "vstart", t4.vstart,
                "o_trans_conseq", t4.o_trans_conseq,
                "projectId", t4.projectId,
                "donorId", t4.donorId,
                "seq_region_name", t4.seq_region_name,
                "chromosome", t4.chromosome,
                "assembly_name", t4.assembly_name,
                "end", t4.end,
                "Tumor_Seq_Allele2", t4.Tumor_Seq_Allele2,
                "strand", t4.strand,
                "start", t4.start,
                "input", t4.input,
                "most_severe_consequence", t4.most_severe_consequence
             )),
             x -> isnotnull(x.vid)
           ) AS o_mutations
    FROM (
        SELECT t3.b_id, t3.bcr_patient_uuid,
               t3.vid, t3.vend, t3.Tumor_Seq_Allele1, t3.allele_string, t3.Reference_Allele, t3.oid, t3.vstart, t3.projectId, t3.donorId, t3.seq_region_name, t3.chromosome, t3.assembly_name, t3.end, t3.Tumor_Seq_Allele2, t3.strand, t3.start, t3.input, t3.most_severe_consequence,
               filter(
                  collect_list(named_struct(
                    "polyphen_score", t3.polyphen_score,
                    "sift_prediction", t3.sift_prediction,
                    "polyphen_prediction", t3.polyphen_prediction,
                    "protein_end", t3.protein_end,
                    "ts_strand", t3.ts_strand,
                    "o_conseq_terms", t3.o_conseq_terms,
                    "impact", t3.impact,
                    "gene_id", t3.gene_id,
                    "amino_acids", t3.amino_acids,
                    "sift_score", t3.sift_score,
                    "cdna_start", t3.cdna_start,
                    "transcript_id", t3.transcript_id,
                    "cdna_end", t3.cdna_end,
                    "exon", t3.exon,
                    "cds_end", t3.cds_end,
                    "cds_start", t3.cds_start,
                    "intron", t3.intron,
                    "case_id", t3.case_id,
                    "protein_start", t3.protein_start,
                    "variant_allele", t3.variant_allele,
                    "codons", t3.codons,
                    "distance", t3.distance
                  )),
                  x -> isnotnull(x.polyphen_score)
                ) AS o_trans_conseq
        FROM (
          SELECT t2.b_id, t2.bcr_patient_uuid,
                 t2.o_id, t2.vid, t2.vend, t2.Tumor_Seq_Allele1, t2.allele_string, t2.Reference_Allele, t2.oid, t2.vstart, t2.projectId, t2.donorId, t2.seq_region_name, t2.chromosome, t2.assembly_name, t2.end, t2.Tumor_Seq_Allele2, t2.strand, t2.start, t2.input, t2.most_severe_consequence,
                 t2.polyphen_score, t2.sift_prediction, t2.polyphen_prediction, t2.protein_end, t2.ts_strand, t2.impact, t2.gene_id, t2.amino_acids, t2.sift_score, t2.cdna_start, t2.transcript_id, t2.cdna_end, t2.exon, t2.cds_end, t2.cds_start, t2.intron, t2.case_id, t2.protein_start, t2.variant_allele, t2.codons, t2.distance,
                 filter(
                    collect_list(named_struct(
                      "conseq_term", C.so_term,
                      "conseq_weight", C.so_weight
                    )),
                    x -> isnotnull(x.conseq_weight)
                  ) AS o_conseq_terms
          FROM (
            SELECT t1.b_id, t1.bcr_patient_uuid,
                   t1.o_id, t1.vid, t1.vend, t1.Tumor_Seq_Allele1, t1.allele_string, t1.Reference_Allele, t1.oid, t1.vstart, t1.projectId, t1.donorId, t1.seq_region_name, t1.chromosome, t1.assembly_name, t1.end, t1.Tumor_Seq_Allele2, t1.strand, t1.start, t1.input, t1.most_severe_consequence,
                   am_id, AM.polyphen_score, AM.sift_prediction, AM.polyphen_prediction, AM.protein_end, AM.ts_strand, AM.impact, AM.gene_id, AM.amino_acids, AM.sift_score, AM.cdna_start, AM.transcript_id, AM.cdna_end, AM.exon, AM.cds_end, AM.cds_start, AM.intron, AM.case_id, AM.protein_start, AM.variant_allele, AM.codons, AM.distance,
                   consequence_term
            FROM (
              SELECT B.b_id, B.bcr_patient_uuid, O.*
              FROM (
                SELECT monotonically_increasing_id() AS b_id, *
                FROM BioSpec
              ) B
              LEFT OUTER JOIN (
                SELECT monotonically_increasing_id() AS o_id, *
                FROM Occurrences 
              ) O
              ON O.donorId = B.bcr_patient_uuid
            ) t1
            LATERAL VIEW OUTER posexplode(t1.transcript_consequences) AS am_id, AM
            LATERAL VIEW OUTER explode(AM.consequence_terms) AS consequence_term
          ) t2
          LEFT OUTER JOIN Consequences C ON C.so_term = t2.consequence_term
          GROUP BY t2.b_id, t2.bcr_patient_uuid,
                   t2.o_id, t2.vid, t2.vend, t2.Tumor_Seq_Allele1, t2.allele_string, t2.Reference_Allele, t2.oid, t2.vstart, t2.projectId, t2.donorId, t2.seq_region_name, t2.chromosome, t2.assembly_name, t2.end, t2.Tumor_Seq_Allele2, t2.strand, t2.start, t2.input, t2.most_severe_consequence,
                   t2.am_id, t2.polyphen_score, t2.sift_prediction, t2.polyphen_prediction, t2.protein_end, t2.ts_strand, t2.impact, t2.gene_id, t2.amino_acids, t2.sift_score, t2.cdna_start, t2.transcript_id, t2.cdna_end, t2.exon, t2.cds_end, t2.cds_start, t2.intron, t2.case_id, t2.protein_start, t2.variant_allele, t2.codons, t2.distance
        ) t3
        GROUP BY t3.b_id, t3.bcr_patient_uuid,
                 t3.o_id, t3.vid, t3.vend, t3.Tumor_Seq_Allele1, t3.allele_string, t3.Reference_Allele, t3.oid, t3.vstart, t3.projectId, t3.donorId, t3.seq_region_name, t3.chromosome, t3.assembly_name, t3.end, t3.Tumor_Seq_Allele2, t3.strand, t3.start, t3.input, t3.most_severe_consequence
    ) t4
    GROUP BY t4.b_id, t4.bcr_patient_uuid
  """)
occurGroupByCaseMid.cache
spark.time(occurGroupByCaseMid.show)
println("occurGroupByCaseMid done")
occurGroupByCaseMid.createOrReplaceTempView("OccurGroupByCaseMid")


// cnvCases := For cn in copynumber Union
//   For b in biospec Union
//     If (cn.cn_aliquot_uuid = b.bcr_aliquot_uuid) Then
//       {( cn_end := cn.cn_end,
//          cn_chromosome := cn.cn_chromosome,
//          cn_start := cn.cn_start,
//          cn_case_uuid := b.bcr_patient_uuid,
//          cn_aliquot_uuid := cn.cn_aliquot_uuid,
//          cn_gene_name := cn.cn_gene_name,
//          cn_gene_id := cn.cn_gene_id,
//          min_copy_number := cn.min_copy_number,
//          max_copy_number := cn.max_copy_number,
//          cn_copy_number := cn.cn_copy_number )}
// OccurCNVGroupByCaseMid := For b in biospec Union
//   {( o_case_id := b.bcr_patient_uuid,
//      o_aliquot_id := b.bcr_aliquot_uuid,
//      o_center := b.center_id,
//      o_mutations := For om in occurrences Union
//     If (om.donorId = b.bcr_patient_uuid) Then
//       {( vid := om.vid,
//          vend := om.vend,
//          Tumor_Seq_Allele1 := om.Tumor_Seq_Allele1,
//          allele_string := om.allele_string,
//          Reference_Allele := om.Reference_Allele,
//          oid := om.oid,
//          vstart := om.vstart,
//          o_trans_conseq := For am in om.transcript_consequences Union
//         For cnv in cnvCases Union
//           If (cnv.cn_case_uuid = am.case_id AND am.gene_id = cnv.cn_gene_id) Then
//             {( o_min_copy := cnv.min_copy_number,
//                polyphen_score := am.polyphen_score,
//                sift_prediction := am.sift_prediction,
//                polyphen_prediction := am.polyphen_prediction,
//                protein_end := am.protein_end,
//                ts_strand := am.ts_strand,
//                o_conseq_terms := For c in am.consequence_terms Union
//               For cons in consequences Union
//                 If (cons.so_term = c.element) Then
//                   {( conseq_term := cons.so_term,
//                      conseq_weight := cons.so_weight )},
//                impact := am.impact,
//                gene_id := am.gene_id,
//                amino_acids := am.amino_acids,
//                sift_score := am.sift_score,
//                cdna_start := am.cdna_start,
//                transcript_id := am.transcript_id,
//                cdna_end := am.cdna_end,
//                o_max_copy := cnv.max_copy_number,
//                exon := am.exon,
//                o_cn_chr := cnv.cn_chromosome,
//                cds_end := am.cds_end,
//                cds_start := am.cds_start,
//                intron := am.intron,
//                case_id := am.case_id,
//                o_cn_end := cnv.cn_end,
//                o_copy_number := cnv.cn_copy_number,
//                o_cn_start := cnv.cn_start,
//                protein_start := am.protein_start,
//                variant_allele := am.variant_allele,
//                codons := am.codons,
//                distance := am.distance )},
//          projectId := om.projectId,
//          donorId := om.donorId,
//          seq_region_name := om.seq_region_name,
//          chromosome := om.chromosome,
//          assembly_name := om.assembly_name,
//          end := om.end,
//          Tumor_Seq_Allele2 := om.Tumor_Seq_Allele2,
//          strand := om.strand,
//          start := om.start,
//          input := om.input,
//          most_severe_consequence := om.most_severe_consequence )} )}


val occurCNVGroupByCaseMid =
  spark.sql("""
    SELECT t4.bcr_patient_uuid AS o_case_id,
           t4.bcr_aliquot_uuid AS o_aliquot_id,
           t4.center_id AS o_center,
           filter(
             collect_list(named_struct(
                "vid", t4.vid,
                "vend", t4.vend,
                "Tumor_Seq_Allele1", t4.Tumor_Seq_Allele1,
                "allele_string", t4.allele_string,
                "Reference_Allele", t4.Reference_Allele,
                "oid", t4.oid,
                "vstart", t4.vstart,
                "o_trans_conseq", t4.o_trans_conseq,
                "projectId", t4.projectId,
                "donorId", t4.donorId,
                "seq_region_name", t4.seq_region_name,
                "chromosome", t4.chromosome,
                "assembly_name", t4.assembly_name,
                "end", t4.end,
                "Tumor_Seq_Allele2", t4.Tumor_Seq_Allele2,
                "strand", t4.strand,
                "start", t4.start,
                "input", t4.input,
                "most_severe_consequence", t4.most_severe_consequence
             )),
             x -> isnotnull(x.vid)
           ) AS o_mutations
    FROM (
        SELECT t3.b_id, t3.bcr_patient_uuid, t3.bcr_aliquot_uuid, t3.center_id,
               t3.vid, t3.vend, t3.Tumor_Seq_Allele1, t3.allele_string, t3.Reference_Allele, t3.oid, t3.vstart, t3.projectId, t3.donorId, t3.seq_region_name, t3.chromosome, t3.assembly_name, t3.end, t3.Tumor_Seq_Allele2, t3.strand, t3.start, t3.input, t3.most_severe_consequence,
               filter(
                  collect_list(named_struct(
                    "o_min_copy", t3.min_copy_number,
                    "polyphen_score", t3.polyphen_score,
                    "sift_prediction", t3.sift_prediction,
                    "polyphen_prediction", t3.polyphen_prediction,
                    "protein_end", t3.protein_end,
                    "ts_strand", t3.ts_strand,
                    "o_conseq_terms", t3.o_conseq_terms,
                    "impact", t3.impact,
                    "gene_id", t3.gene_id,
                    "amino_acids", t3.amino_acids,
                    "sift_score", t3.sift_score,
                    "cdna_start", t3.cdna_start,
                    "transcript_id", t3.transcript_id,
                    "cdna_end", t3.cdna_end,
                    "o_max_copy", t3.max_copy_number,
                    "exon", t3.exon,
                    "o_cn_chr", t3.cn_chromosome,
                    "cds_end", t3.cds_end,
                    "cds_start", t3.cds_start,
                    "intron", t3.intron,
                    "case_id", t3.case_id,
                    "o_cn_end", t3.cn_end,
                    "o_copy_number", t3.cn_copy_number,
                    "o_cn_start", t3.cn_start,
                    "protein_start", t3.protein_start,
                    "variant_allele", t3.variant_allele,
                    "codons", t3.codons,
                    "distance", t3.distance
                  )),
                  x -> isnotnull(x.polyphen_score)
                ) AS o_trans_conseq
        FROM (
          SELECT t2.b_id, t2.bcr_patient_uuid, t2.bcr_aliquot_uuid, t2.center_id,
                 t2.o_id, t2.vid, t2.vend, t2.Tumor_Seq_Allele1, t2.allele_string, t2.Reference_Allele, t2.oid, t2.vstart, t2.projectId, t2.donorId, t2.seq_region_name, t2.chromosome, t2.assembly_name, t2.end, t2.Tumor_Seq_Allele2, t2.strand, t2.start, t2.input, t2.most_severe_consequence,
                 t2.polyphen_score, t2.sift_prediction, t2.polyphen_prediction, t2.protein_end, t2.ts_strand, t2.impact, t2.gene_id, t2.amino_acids, t2.sift_score, t2.cdna_start, t2.transcript_id, t2.cdna_end, t2.exon, t2.cds_end, t2.cds_start, t2.intron, t2.case_id, t2.protein_start, t2.variant_allele, t2.codons, t2.distance,
                 t2.min_copy_number, t2.max_copy_number, t2.cn_chromosome, t2.cn_end, t2.cn_copy_number, t2.cn_start,
                 filter(
                    collect_list(named_struct(
                      "conseq_term", C.so_term,
                      "conseq_weight", C.so_weight
                    )),
                    x -> isnotnull(x.conseq_weight)
                  ) AS o_conseq_terms
          FROM (
              SELECT t5.b_id, t5.bcr_patient_uuid, t5.bcr_aliquot_uuid, t5.center_id,
                     t5.o_id, t5.vid, t5.vend, t5.Tumor_Seq_Allele1, t5.allele_string, t5.Reference_Allele, t5.oid, t5.vstart, t5.projectId, t5.donorId, t5.seq_region_name, t5.chromosome, t5.assembly_name, t5.end, t5.Tumor_Seq_Allele2, t5.strand, t5.start, t5.input, t5.most_severe_consequence,
                     t5.am_id, t5.polyphen_score, t5.sift_prediction, t5.polyphen_prediction, t5.protein_end, t5.ts_strand, t5.impact, t5.gene_id, t5.amino_acids, t5.sift_score, t5.cdna_start, t5.transcript_id, t5.cdna_end, t5.exon, t5.cds_end, t5.cds_start, t5.intron, t5.case_id, t5.protein_start, t5.variant_allele, t5.codons, t5.distance,
                     CNV.min_copy_number, CNV.max_copy_number, CNV.cn_chromosome, CNV.cn_end, CNV.cn_copy_number, CNV.cn_start,
                     consequence_term              
              FROM (
                  SELECT t1.b_id, t1.bcr_patient_uuid, t1.bcr_aliquot_uuid, t1.center_id,
                         t1.o_id, t1.vid, t1.vend, t1.Tumor_Seq_Allele1, t1.allele_string, t1.Reference_Allele, t1.oid, t1.vstart, t1.projectId, t1.donorId, t1.seq_region_name, t1.chromosome, t1.assembly_name, t1.end, t1.Tumor_Seq_Allele2, t1.strand, t1.start, t1.input, t1.most_severe_consequence,                                        
                         am_id, AM.polyphen_score, AM.sift_prediction, AM.polyphen_prediction, AM.protein_end, AM.ts_strand, AM.impact, AM.gene_id, AM.amino_acids, AM.sift_score, AM.cdna_start, AM.transcript_id, AM.cdna_end, AM.exon, AM.cds_end, AM.cds_start, AM.intron, AM.case_id, AM.protein_start, AM.variant_allele, AM.codons, AM.distance,
                         AM.consequence_terms
                  FROM (
                    SELECT B.b_id, B.bcr_patient_uuid, B.bcr_aliquot_uuid, B.center_id, O.*
                    FROM (
                      SELECT monotonically_increasing_id() AS b_id, *
                      FROM BioSpec
                    ) B
                    LEFT OUTER JOIN (
                      SELECT monotonically_increasing_id() AS o_id, *
                      FROM Occurrences 
                    ) O
                    ON O.donorId = B.bcr_patient_uuid
                  ) t1
                  LATERAL VIEW OUTER posexplode(t1.transcript_consequences) AS am_id, AM
              ) t5
              LEFT OUTER JOIN (
                  -- cnvCases
                  SELECT CN2.cn_end AS cn_end,
                         CN2.cn_chromosome AS cn_chromosome,
                         CN2.cn_start AS cn_start,
                         B2.bcr_patient_uuid AS cn_case_uuid,
                         CN2.cn_aliquot_uuid AS cn_aliquot_uuid,
                         CN2.cn_gene_name AS cn_gene_name,
                         CN2.cn_gene_id AS cn_gene_id,
                         CN2.min_copy_number AS min_copy_number,
                         CN2.max_copy_number AS max_copy_number,
                         CN2.cn_copy_number AS cn_copy_number
                  FROM CopyNumber CN2 JOIN BioSpec B2 
                    ON CN2.cn_aliquot_uuid = B2.bcr_aliquot_uuid
              ) CNV
              ON CNV.cn_case_uuid = t5.case_id AND CNV.cn_gene_id = t5.gene_id
              LATERAL VIEW OUTER explode(t5.consequence_terms) AS consequence_term
          ) t2
          LEFT OUTER JOIN Consequences C ON C.so_term = t2.consequence_term
          GROUP BY t2.b_id, t2.bcr_patient_uuid, t2.bcr_aliquot_uuid, t2.center_id,
                   t2.o_id, t2.vid, t2.vend, t2.Tumor_Seq_Allele1, t2.allele_string, t2.Reference_Allele, t2.oid, t2.vstart, t2.projectId, t2.donorId, t2.seq_region_name, t2.chromosome, t2.assembly_name, t2.end, t2.Tumor_Seq_Allele2, t2.strand, t2.start, t2.input, t2.most_severe_consequence,
                   t2.am_id, t2.polyphen_score, t2.sift_prediction, t2.polyphen_prediction, t2.protein_end, t2.ts_strand, t2.impact, t2.gene_id, t2.amino_acids, t2.sift_score, t2.cdna_start, t2.transcript_id, t2.cdna_end, t2.exon, t2.cds_end, t2.cds_start, t2.intron, t2.case_id, t2.protein_start, t2.variant_allele, t2.codons, t2.distance,
                   t2.min_copy_number, t2.max_copy_number, t2.cn_chromosome, t2.cn_end, t2.cn_copy_number, t2.cn_start
        ) t3
        GROUP BY t3.b_id, t3.bcr_patient_uuid, t3.bcr_aliquot_uuid, t3.center_id,
                 t3.o_id, t3.vid, t3.vend, t3.Tumor_Seq_Allele1, t3.allele_string, t3.Reference_Allele, t3.oid, t3.vstart, t3.projectId, t3.donorId, t3.seq_region_name, t3.chromosome, t3.assembly_name, t3.end, t3.Tumor_Seq_Allele2, t3.strand, t3.start, t3.input, t3.most_severe_consequence
    ) t4
    GROUP BY t4.b_id, t4.bcr_patient_uuid, t4.bcr_aliquot_uuid, t4.center_id
  """)
occurCNVGroupByCaseMid.cache
spark.time(occurCNVGroupByCaseMid.show)
println("occurCNVGroupByCaseMid done")
occurCNVGroupByCaseMid.createOrReplaceTempView("OccurCNVGroupByCaseMid")


// cnvCases := For cn in copynumber Union
//   For b in biospec Union
//     If (cn.cn_aliquot_uuid = b.bcr_aliquot_uuid) Then
//       {( cn_end := cn.cn_end,
//          cn_chromosome := cn.cn_chromosome,
//          cn_start := cn.cn_start,
//          cn_case_uuid := b.bcr_patient_uuid,
//          cn_aliquot_uuid := cn.cn_aliquot_uuid,
//          cn_gene_name := cn.cn_gene_name,
//          cn_gene_id := cn.cn_gene_id,
//          min_copy_number := cn.min_copy_number,
//          max_copy_number := cn.max_copy_number,
//          cn_copy_number := cn.cn_copy_number )}

// OccurCNVAggGroupByCaseMid := 
//   For b in biospec Union
//   {( o_case_id := b.bcr_patient_uuid,
//      o_aliquot_id := b.bcr_aliquot_uuid,
//      o_center := b.center_id,
//      o_mutations := 
//       For om in occurrences Union
//       If (om.donorId = b.bcr_patient_uuid) Then
//       {( vid := om.vid,
//          vend := om.vend,
//          Tumor_Seq_Allele1 := om.Tumor_Seq_Allele1,
//          allele_string := om.allele_string,
//          Reference_Allele := om.Reference_Allele,
//          oid := om.oid,
//          vstart := om.vstart,
//          o_trans_conseq := 
//           ReduceByKey([o_gene_id], [hybrid_score],
//             For am in om.transcript_consequences Union
//               For cnv in cnvCases Union
//                 If (cnv.cn_case_uuid = am.case_id AND am.gene_id = cnv.cn_gene_id) Then
//                   For c in am.consequence_terms Union
//                     For cons in consequences Union
//                       If (cons.so_term = c.element) Then
//                         {( o_gene_id := am.gene_id,
//                            hybrid_score := ((cons.so_weight * ((((cnv.max_copy_number + cnv.min_copy_number) + cnv.cn_copy_number) + 0.01) / 3.0)) * If (am.impact = "HIGH") Then
//                           0.8
//                         Else
//                           If (am.impact = "MODERATE") Then
//                             0.5
//                           Else
//                             If (am.impact = "LOW") Then
//                               0.3
//                             Else
//                               If (am.impact = "MODIFIER") Then
//                                 0.15
//                               Else
//                                 0.01) )}
//           ),
//          projectId := om.projectId,
//          donorId := om.donorId,
//          seq_region_name := om.seq_region_name,
//          chromosome := om.chromosome,
//          assembly_name := om.assembly_name,
//          end := om.end,
//          Tumor_Seq_Allele2 := om.Tumor_Seq_Allele2,
//          strand := om.strand,
//          start := om.start,
//          input := om.input,
//          most_severe_consequence := om.most_severe_consequence )} )}

val occurCNVAggGroupByCaseMid =
  spark.sql("""
    SELECT t4.bcr_patient_uuid AS o_case_id,
           t4.bcr_aliquot_uuid AS o_aliquot_id,
           t4.center_id AS o_center,
           filter(
             collect_list(named_struct(
                "vid", t4.vid,
                "vend", t4.vend,
                "Tumor_Seq_Allele1", t4.Tumor_Seq_Allele1,
                "allele_string", t4.allele_string,
                "Reference_Allele", t4.Reference_Allele,
                "oid", t4.oid,
                "vstart", t4.vstart,
                "o_trans_conseq", t4.o_trans_conseq,
                "projectId", t4.projectId,
                "donorId", t4.donorId,
                "seq_region_name", t4.seq_region_name,
                "chromosome", t4.chromosome,
                "assembly_name", t4.assembly_name,
                "end", t4.end,
                "Tumor_Seq_Allele2", t4.Tumor_Seq_Allele2,
                "strand", t4.strand,
                "start", t4.start,
                "input", t4.input,
                "most_severe_consequence", t4.most_severe_consequence
             )),
             x -> isnotnull(x.vid)
           ) AS o_mutations
    FROM (
        SELECT t3.b_id, t3.bcr_patient_uuid, t3.bcr_aliquot_uuid, t3.center_id,
               t3.vid, t3.vend, t3.Tumor_Seq_Allele1, t3.allele_string, t3.Reference_Allele, t3.oid, t3.vstart, t3.projectId, t3.donorId, t3.seq_region_name, t3.chromosome, t3.assembly_name, t3.end, t3.Tumor_Seq_Allele2, t3.strand, t3.start, t3.input, t3.most_severe_consequence,
               filter(
                  collect_list(named_struct(
                    "o_gene_id", t3.gene_id,
                    "hybrid_score", t3.hybrid_score
                  )),
                  x -> isnotnull(x.o_gene_id)
                ) AS o_trans_conseq
        FROM (
          SELECT t2.b_id, t2.bcr_patient_uuid, t2.bcr_aliquot_uuid, t2.center_id,
                 t2.o_id, t2.vid, t2.vend, t2.Tumor_Seq_Allele1, t2.allele_string, t2.Reference_Allele, t2.oid, t2.vstart, t2.projectId, t2.donorId, t2.seq_region_name, t2.chromosome, t2.assembly_name, t2.end, t2.Tumor_Seq_Allele2, t2.strand, t2.start, t2.input, t2.most_severe_consequence,
                 t2.gene_id, 
                 SUM(
                    C.so_weight * 
                    (t2.max_copy_number + t2.min_copy_number + t2.cn_copy_number + 0.01) / 3.0 *
                    CASE 
                        WHEN t2.impact = 'HIGH' THEN 0.8
                        WHEN t2.impact = 'MODERATE' THEN 0.5
                        WHEN t2.impact = 'LOW' THEN 0.3
                        WHEN t2.impact = 'MODIFIER' THEN 0.15
                        ELSE 0.01
                    END
                 ) AS hybrid_score
          FROM (
              SELECT t5.b_id, t5.bcr_patient_uuid, t5.bcr_aliquot_uuid, t5.center_id,
                     t5.o_id, t5.vid, t5.vend, t5.Tumor_Seq_Allele1, t5.allele_string, t5.Reference_Allele, t5.oid, t5.vstart, t5.projectId, t5.donorId, t5.seq_region_name, t5.chromosome, t5.assembly_name, t5.end, t5.Tumor_Seq_Allele2, t5.strand, t5.start, t5.input, t5.most_severe_consequence,
                     t5.case_id, t5.gene_id, t5.impact, 
                     CNV.min_copy_number, CNV.max_copy_number, CNV.cn_copy_number,
                     consequence_term              
              FROM (
                  SELECT t1.b_id, t1.bcr_patient_uuid, t1.bcr_aliquot_uuid, t1.center_id,
                         t1.o_id, t1.vid, t1.vend, t1.Tumor_Seq_Allele1, t1.allele_string, t1.Reference_Allele, t1.oid, t1.vstart, t1.projectId, t1.donorId, t1.seq_region_name, t1.chromosome, t1.assembly_name, t1.end, t1.Tumor_Seq_Allele2, t1.strand, t1.start, t1.input, t1.most_severe_consequence,                                        
                         AM.case_id, AM.gene_id, AM.impact, AM.consequence_terms
                  FROM (
                    SELECT B.b_id, B.bcr_patient_uuid, B.bcr_aliquot_uuid, B.center_id, O.*
                    FROM (
                      SELECT monotonically_increasing_id() AS b_id, *
                      FROM BioSpec
                    ) B
                    LEFT OUTER JOIN (
                      SELECT monotonically_increasing_id() AS o_id, *
                      FROM Occurrences 
                    ) O
                    ON O.donorId = B.bcr_patient_uuid
                  ) t1
                  LATERAL VIEW OUTER explode(t1.transcript_consequences) AS AM
              ) t5
              LEFT OUTER JOIN (
                  -- cnvCases
                  SELECT CN2.cn_end AS cn_end,
                         CN2.cn_chromosome AS cn_chromosome,
                         CN2.cn_start AS cn_start,
                         B2.bcr_patient_uuid AS cn_case_uuid,
                         CN2.cn_aliquot_uuid AS cn_aliquot_uuid,
                         CN2.cn_gene_name AS cn_gene_name,
                         CN2.cn_gene_id AS cn_gene_id,
                         CN2.min_copy_number AS min_copy_number,
                         CN2.max_copy_number AS max_copy_number,
                         CN2.cn_copy_number AS cn_copy_number
                  FROM CopyNumber CN2 JOIN BioSpec B2 
                    ON CN2.cn_aliquot_uuid = B2.bcr_aliquot_uuid
              ) CNV
              ON CNV.cn_case_uuid = t5.case_id AND CNV.cn_gene_id = t5.gene_id
              LATERAL VIEW OUTER explode(t5.consequence_terms) AS consequence_term
          ) t2
          LEFT OUTER JOIN Consequences C ON C.so_term = t2.consequence_term
          GROUP BY t2.b_id, t2.bcr_patient_uuid, t2.bcr_aliquot_uuid, t2.center_id,
                   t2.o_id, t2.vid, t2.vend, t2.Tumor_Seq_Allele1, t2.allele_string, t2.Reference_Allele, t2.oid, t2.vstart, t2.projectId, t2.donorId, t2.seq_region_name, t2.chromosome, t2.assembly_name, t2.end, t2.Tumor_Seq_Allele2, t2.strand, t2.start, t2.input, t2.most_severe_consequence,
                   t2.gene_id                   
        ) t3
        GROUP BY t3.b_id, t3.bcr_patient_uuid, t3.bcr_aliquot_uuid, t3.center_id,
                 t3.o_id, t3.vid, t3.vend, t3.Tumor_Seq_Allele1, t3.allele_string, t3.Reference_Allele, t3.oid, t3.vstart, t3.projectId, t3.donorId, t3.seq_region_name, t3.chromosome, t3.assembly_name, t3.end, t3.Tumor_Seq_Allele2, t3.strand, t3.start, t3.input, t3.most_severe_consequence
    ) t4
    GROUP BY t4.b_id, t4.bcr_patient_uuid, t4.bcr_aliquot_uuid, t4.center_id
  """)
occurCNVAggGroupByCaseMid.cache
spark.time(occurCNVAggGroupByCaseMid.show)
println("occurCNVAggGroupByCaseMid done")
occurCNVAggGroupByCaseMid.createOrReplaceTempView("OccurCNVAggGroupByCaseMid")