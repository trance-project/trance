import org.apache.spark.sql.SparkSession
import org.apache.spark.SparkConf

// For implicit conversions like converting RDDs to DataFrames
import spark.implicits._

import sparkutils.loader._
import sparkutils._

val sf = Config.datapath.split("/").last
val conf = new SparkConf().setMaster(Config.master)
  .setAppName("tpchFlatNestedDepth1" + sf)
  .set("spark.sql.shuffle.partitions", Config.minPartitions.toString)
val spark = SparkSession.builder().config(conf).getOrCreate()

val tpch = TPCHLoader(spark)

val lineitem = tpch.loadLineitemDF()
lineitem.cache
lineitem.count
lineitem.createOrReplaceTempView("lineitem")

val orders = tpch.loadOrderDF()
orders.cache
orders.count
orders.createOrReplaceTempView("orders")

val tpchFlatNestedDepth1 = 
  spark.sql("""
    SELECT O.o_orderdate AS odate,
           coalesce(
              ( SELECT collect_list(named_struct(
                  "pid", L.l_partkey,
                  "qty", L.l_quantity )) 
                FROM Lineitem L
                WHERE L.l_orderkey = O.o_orderkey ),
              filter(array(cast(null AS struct<pid:int,qty:double>)), x -> isnotnull(x))
            ) AS oparts
    FROM Orders O
  """)
tpchFlatNestedDepth1.cache
spark.time(tpchFlatNestedDepth1.show)
println("tpchFlatNestedDepth1 done")
tpchFlatNestedDepth1.createOrReplaceTempView("tpchFlatNestedDepth1")
