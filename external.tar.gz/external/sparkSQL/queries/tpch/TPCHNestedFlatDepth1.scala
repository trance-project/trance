import org.apache.spark.sql.SparkSession
import org.apache.spark.SparkConf

// For implicit conversions like converting RDDs to DataFrames
import spark.implicits._

import sparkutils.loader._
import sparkutils._

val sf = Config.datapath.split("/").last
val conf = new SparkConf().setMaster(Config.master)
  .setAppName("tpchNestedFlatDepth1" + sf)
  .set("spark.sql.shuffle.partitions", Config.minPartitions.toString)
val spark = SparkSession.builder().config(conf).getOrCreate()

val tpch = TPCHLoader(spark)

val lineitem = tpch.loadLineitemDF()
lineitem.cache
lineitem.count
lineitem.createOrReplaceTempView("lineitem")

val orders = tpch.loadOrderDF()
orders.cache
orders.count
orders.createOrReplaceTempView("orders")

val part = tpch.loadPartDF()
part.cache
part.count
part.createOrReplaceTempView("part")

val tpchFlatNestedDepth1 = 
  spark.sql("""
    SELECT O.o_orderdate AS odate,
           coalesce(
              ( SELECT collect_list(named_struct(
                  "pid", L.l_partkey,
                  "qty", L.l_quantity )) 
                FROM Lineitem L
                WHERE L.l_orderkey = O.o_orderkey ),
              filter(array(cast(null AS struct<pid:int,qty:double>)), x -> isnotnull(x))
            ) AS oparts
    FROM Orders O
  """)
tpchFlatNestedDepth1.cache
spark.time(tpchFlatNestedDepth1.show)
println("tpchFlatNestedDepth1 done")
tpchFlatNestedDepth1.createOrReplaceTempView("tpchFlatNestedDepth1")

val tpchNestedFlatDepth1 =
  spark.sql("""
    SELECT t1.odate, SUM(t1.qty * P.p_retailprice) AS total
    FROM (
      SELECT OL.odate, L.pid, L.qty
      FROM tpchFlatNestedDepth1 AS OL 
      LATERAL VIEW OUTER explode(OL.oparts) AS L
    ) t1 LEFT OUTER JOIN Part P ON t1.pid = P.p_partkey
    GROUP BY t1.odate
  """)
tpchNestedFlatDepth1.cache
spark.time(tpchNestedFlatDepth1.show)
println("tpchNestedFlatDepth1 done")
tpchNestedFlatDepth1.createOrReplaceTempView("tpchNestedFlatDepth1")
