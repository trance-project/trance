import org.apache.spark.sql.SparkSession
import org.apache.spark.SparkConf

// For implicit conversions like converting RDDs to DataFrames
import spark.implicits._

import sparkutils.loader._
import sparkutils._

val sf = Config.datapath.split("/").last
val conf = new SparkConf().setMaster(Config.master)
  .setAppName("tpchNestedFlatDepth2Wide" + sf)
  .set("spark.sql.shuffle.partitions", Config.minPartitions.toString)
val spark = SparkSession.builder().config(conf).getOrCreate()

val tpch = TPCHLoader(spark)

val lineitem = tpch.loadLineitemDF()
lineitem.cache
lineitem.count
lineitem.createOrReplaceTempView("lineitem")

val orders = tpch.loadOrderDF()
orders.cache
orders.count
orders.createOrReplaceTempView("orders")

val customer = tpch.loadCustomerDF()
customer.cache
customer.count
customer.createOrReplaceTempView("customer")

val part = tpch.loadPartDF()
part.cache
part.count
part.createOrReplaceTempView("part")

val tpchFlatNestedDepth2Wide = 
  spark.sql("""
    SELECT  C.c_custkey,
            C.c_name,
            C.c_address,
            C.c_nationkey,
            C.c_phone,
            C.c_acctbal,
            C.c_mktsegment,
            C.c_comment,
            coalesce(
              ( SELECT collect_list(named_struct(
                  "o_orderkey", O.o_orderkey,
                  "o_custkey", O.o_custkey,
                  "o_orderstatus", O.o_orderstatus,
                  "o_totalprice", O.o_totalprice,
                  "o_orderdate", O.o_orderdate,
                  "o_orderpriority", O.o_orderpriority,
                  "o_clerk", O.o_clerk,
                  "o_shippriority", O.o_shippriority,
                  "o_comment", O.o_comment,
                  "oparts", coalesce(
                              ( SELECT collect_list(named_struct(
                                  "l_orderkey", L.l_orderkey, 
                                  "l_partkey", L.l_partkey, 
                                  "l_suppkey", L.l_suppkey, 
                                  "l_linenumber", L.l_linenumber, 
                                  "l_quantity", L.l_quantity, 
                                  "l_extendedprice", L.l_extendedprice, 
                                  "l_discount", L.l_discount, 
                                  "l_tax", L.l_tax, 
                                  "l_returnflag", L.l_returnflag, 
                                  "l_linestatus", L.l_linestatus, 
                                  "l_shipdate", L.l_shipdate, 
                                  "l_commitdate", L.l_commitdate, 
                                  "l_receiptdate", L.l_receiptdate, 
                                  "l_shipinstruct", L.l_shipinstruct, 
                                  "l_shipmode", L.l_shipmode, 
                                  "l_comment", L.l_comment 
                                )) 
                                FROM Lineitem L
                                WHERE L.l_orderkey = O.o_orderkey ),
                              filter(array(cast(null AS struct<l_orderkey:int,l_partkey:int,l_suppkey:int,l_linenumber:int,l_quantity:double,l_extendedprice:double,l_discount:double,l_tax:double,l_returnflag:string,l_linestatus:string,l_shipdate:string,l_commitdate:string,l_receiptdate:string,l_shipinstruct:string,l_shipmode:string,l_comment:string>)), x -> isnotnull(x))
                            ) 
                  ))
                FROM Orders O 
                WHERE O.o_custkey = C.c_custkey ),
             filter(array(cast(null AS struct<o_orderkey:int,o_custkey:int,o_orderstatus:string,o_totalprice:double,o_orderdate:string,o_orderpriority:string,o_clerk:string,o_shippriority:int,o_comment:string,oparts:array<struct<l_orderkey:int,l_partkey:int,l_suppkey:int,l_linenumber:int,l_quantity:double,l_extendedprice:double,l_discount:double,l_tax:double,l_returnflag:string,l_linestatus:string,l_shipdate:string,l_commitdate:string,l_receiptdate:string,l_shipinstruct:string,l_shipmode:string,l_comment:string>>>)), x -> isnotnull(x))
           ) AS corders
    FROM Customer C
  """)
tpchFlatNestedDepth2Wide.cache
spark.time(tpchFlatNestedDepth2Wide.show)
println("tpchFlatNestedDepth2Wide done")
tpchFlatNestedDepth2Wide.createOrReplaceTempView("tpchFlatNestedDepth2Wide")

val tpchNestedFlatDepth2Wide = 
  spark.sql("""
    SELECT  t1.c_custkey,
            t1.c_name,
            t1.c_address,
            t1.c_nationkey,
            t1.c_phone,
            t1.c_acctbal,
            t1.c_mktsegment,
            t1.c_comment,
            SUM(t1.l_quantity * P.p_retailprice) AS total
    FROM (
      SELECT  COL.c_custkey,
              COL.c_name,
              COL.c_address,
              COL.c_nationkey,
              COL.c_phone,
              COL.c_acctbal,
              COL.c_mktsegment,
              COL.c_comment,
              L.l_partkey, 
              L.l_quantity
      FROM tpchFlatNestedDepth2Wide AS COL 
      LATERAL VIEW OUTER posexplode(COL.corders) AS odateid, OL
      LATERAL VIEW OUTER explode(OL.oparts) AS L
    ) t1 LEFT OUTER JOIN Part P ON t1.l_partkey = P.p_partkey
    GROUP BY t1.c_custkey, t1.c_name, t1.c_address, t1.c_nationkey, t1.c_phone, t1.c_acctbal, t1.c_mktsegment, t1.c_comment
  """)
//tpchNestedFlatDepth2Wide.cache
spark.time(tpchNestedFlatDepth2Wide.show)
println("tpchNestedFlatDepth2Wide done")
//tpchNestedFlatDepth2Wide.createOrReplaceTempView("tpchNestedFlatDepth2Wide")
