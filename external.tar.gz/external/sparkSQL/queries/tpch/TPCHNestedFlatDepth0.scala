import org.apache.spark.sql.SparkSession
import org.apache.spark.SparkConf

// For implicit conversions like converting RDDs to DataFrames
import spark.implicits._

import sparkutils.loader._
import sparkutils._

val sf = Config.datapath.split("/").last
val conf = new SparkConf().setMaster(Config.master)
  .setAppName("tpchNestedFlatDepth0" + sf)
  .set("spark.sql.shuffle.partitions", Config.minPartitions.toString)
val spark = SparkSession.builder().config(conf).getOrCreate()

val tpch = TPCHLoader(spark)

val lineitem = tpch.loadLineitemDF()
lineitem.cache
lineitem.count
lineitem.createOrReplaceTempView("lineitem")

val part = tpch.loadPartDF()
part.cache
part.count
part.createOrReplaceTempView("part")

val tpchFlatNestedDepth0 = 
  spark.sql("""
    SELECT L.l_partkey AS partkey, L.l_quantity AS quantity
    FROM Lineitem l
  """)
tpchFlatNestedDepth0.cache
spark.time(tpchFlatNestedDepth0.show)
println("tpchFlatNestedDepth0 done")
tpchFlatNestedDepth0.createOrReplaceTempView("tpchFlatNestedDepth0")

val tpchNestedFlatDepth0 = 
  spark.sql("""
    SELECT P.p_name, SUM(t1.quantity * P.p_retailprice) AS total
    FROM tpchFlatNestedDepth0 t1 JOIN Part P ON t1.partkey = P.p_partkey
    GROUP BY P.p_name
  """)
tpchNestedFlatDepth0.cache
spark.time(tpchNestedFlatDepth0.show)
println("tpchNestedFlatDepth0 done")
tpchNestedFlatDepth0.createOrReplaceTempView("tpchNestedFlatDepth0")
