import org.apache.spark.sql.SparkSession
import org.apache.spark.SparkConf

// For implicit conversions like converting RDDs to DataFrames
import spark.implicits._

import sparkutils.loader._
import sparkutils._

val sf = Config.datapath.split("/").last
val conf = new SparkConf().setMaster(Config.master)
  .setAppName("tpchNestedFlatDepth0Wide" + sf)
  .set("spark.sql.shuffle.partitions", Config.minPartitions.toString)
val spark = SparkSession.builder().config(conf).getOrCreate()

val tpch = TPCHLoader(spark)

val lineitem = tpch.loadLineitemDF()
lineitem.cache
lineitem.count
lineitem.createOrReplaceTempView("lineitem")

val part = tpch.loadPartDF()
part.cache
part.count
part.createOrReplaceTempView("part")

val tpchFlatNestedDepth0Wide = 
  spark.sql("""
    SELECT  L.l_orderkey, 
            L.l_partkey, 
            L.l_suppkey, 
            L.l_linenumber, 
            L.l_quantity, 
            L.l_extendedprice, 
            L.l_discount, 
            L.l_tax, 
            L.l_returnflag, 
            L.l_linestatus, 
            L.l_shipdate, 
            L.l_commitdate, 
            L.l_receiptdate, 
            L.l_shipinstruct, 
            L.l_shipmode, 
            L.l_comment
    FROM Lineitem L
  """)
tpchFlatNestedDepth0Wide.cache
spark.time(tpchFlatNestedDepth0Wide.show)
println("tpchFlatNestedDepth0Wide done")
tpchFlatNestedDepth0Wide.createOrReplaceTempView("tpchFlatNestedDepth0Wide")

val tpchNestedFlatDepth0Wide = 
  spark.sql("""
    SELECT  P.p_partkey,
            P.p_name,
            P.p_mfgr,
            P.p_brand,
            P.p_type,
            P.p_size,
            P.p_container,
            P.p_retailprice,
            P.p_comment,
            SUM(t1.l_quantity * P.p_retailprice) AS total
    FROM tpchFlatNestedDepth0Wide t1 JOIN Part P ON t1.l_partkey = P.p_partkey
    GROUP BY P.p_partkey, P.p_name, P.p_mfgr, P.p_brand, P.p_type, P.p_size, P.p_container, P.p_retailprice, P.p_comment
  """)
//tpchNestedFlatDepth0Wide.cache
spark.time(tpchNestedFlatDepth0Wide.show)
println("tpchNestedFlatDepth0Wide done")
//tpchNestedFlatDepth0Wide.createOrReplaceTempView("tpchNestedFlatDepth0Wide")
