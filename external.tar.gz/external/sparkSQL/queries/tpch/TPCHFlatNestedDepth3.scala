import org.apache.spark.sql.SparkSession
import org.apache.spark.SparkConf

// For implicit conversions like converting RDDs to DataFrames
import spark.implicits._

import sparkutils.loader._
import sparkutils._

val sf = Config.datapath.split("/").last
val conf = new SparkConf().setMaster(Config.master)
  .setAppName("tpchFlatNestedDepth3" + sf)
  .set("spark.sql.shuffle.partitions", Config.minPartitions.toString)
val spark = SparkSession.builder().config(conf).getOrCreate()

val tpch = TPCHLoader(spark)

val lineitem = tpch.loadLineitemDF()
lineitem.cache
lineitem.count
lineitem.createOrReplaceTempView("lineitem")

val orders = tpch.loadOrderDF()
orders.cache
orders.count
orders.createOrReplaceTempView("orders")

val customer = tpch.loadCustomerDF()
customer.cache
customer.count
customer.createOrReplaceTempView("customer")

val nation = tpch.loadNationDF()
nation.cache
nation.count
nation.createOrReplaceTempView("nation")

val tpchFlatNestedDepth3 = 
  spark.sql("""
    SELECT  N.n_name AS nname,
            coalesce(
              ( SELECT collect_list(named_struct(
                  "cname", C.c_name,
                  "corders", coalesce(
                              ( SELECT collect_list(named_struct(
                                  "odate", O.o_orderdate,
                                  "oparts", coalesce(
                                              ( SELECT collect_list(named_struct(
                                                  "pid", L.l_partkey,
                                                  "qty", L.l_quantity )) 
                                                FROM Lineitem L
                                                WHERE L.l_orderkey = O.o_orderkey ),
                                              filter(array(cast(null AS struct<pid:int,qty:double>)), x -> isnotnull(x))
                                            ) ))
                                FROM Orders O 
                                WHERE O.o_custkey = C.c_custkey ),
                             filter(array(cast(null AS struct<odate:string,oparts:array<struct<pid:int,qty:double>>>)), x -> isnotnull(x))
                           )
                  ))
                FROM Customer C
                WHERE C.c_nationkey = N.n_nationkey ), 
              filter(array(cast(null AS struct<cname:string,corders:array<struct<odate:string,oparts:array<struct<pid:int,qty:double>>>>>)), x -> isnotnull(x))
            ) AS ncusts
    FROM Nation N
  """)
tpchFlatNestedDepth3.cache
spark.time(tpchFlatNestedDepth3.show)
println("tpchFlatNestedDepth3 done")
tpchFlatNestedDepth3.createOrReplaceTempView("tpchFlatNestedDepth3")
