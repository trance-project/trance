import org.apache.spark.sql.SparkSession
import org.apache.spark.SparkConf

// For implicit conversions like converting RDDs to DataFrames
import spark.implicits._

import sparkutils.loader._
import sparkutils._

val sf = Config.datapath.split("/").last
val conf = new SparkConf().setMaster(Config.master)
  .setAppName("tpchFlatNestedDepth0" + sf)
  .set("spark.sql.shuffle.partitions", Config.minPartitions.toString)
val spark = SparkSession.builder().config(conf).getOrCreate()

val tpch = TPCHLoader(spark)

val lineitem = tpch.loadLineitemDF()
lineitem.cache
lineitem.count
lineitem.createOrReplaceTempView("lineitem")

val tpchFlatNestedDepth0 = 
  spark.sql("""
    SELECT L.l_partkey AS partkey, L.l_quantity AS quantity
    FROM Lineitem l
  """)
tpchFlatNestedDepth0.cache
spark.time(tpchFlatNestedDepth0.show)
println("tpchFlatNestedDepth0 done")
tpchFlatNestedDepth0.createOrReplaceTempView("tpchFlatNestedDepth0")
