import org.apache.spark.sql.SparkSession
import org.apache.spark.SparkConf

// For implicit conversions like converting RDDs to DataFrames
import spark.implicits._

import sparkutils.loader._
import sparkutils._

val sf = Config.datapath.split("/").last
val conf = new SparkConf().setMaster(Config.master)
  .setAppName("tpchNestedNestedDepth2Wide" + sf)
  .set("spark.sql.shuffle.partitions", Config.minPartitions.toString)
val spark = SparkSession.builder().config(conf).getOrCreate()

val tpch = TPCHLoader(spark)

val lineitem = tpch.loadLineitemDF()
lineitem.cache
lineitem.count
lineitem.createOrReplaceTempView("lineitem")

val orders = tpch.loadOrderDF()
orders.cache
orders.count
orders.createOrReplaceTempView("orders")

val customer = tpch.loadCustomerDF()
customer.cache
customer.count
customer.createOrReplaceTempView("customer")

val part = tpch.loadPartDF()
part.cache
part.count
part.createOrReplaceTempView("part")

val tpchFlatNestedDepth2Wide = 
  spark.sql("""
    SELECT  C.c_custkey,
            C.c_name,
            C.c_address,
            C.c_nationkey,
            C.c_phone,
            C.c_acctbal,
            C.c_mktsegment,
            C.c_comment,
            coalesce(
              ( SELECT collect_list(named_struct(
                  "o_orderkey", O.o_orderkey,
                  "o_custkey", O.o_custkey,
                  "o_orderstatus", O.o_orderstatus,
                  "o_totalprice", O.o_totalprice,
                  "o_orderdate", O.o_orderdate,
                  "o_orderpriority", O.o_orderpriority,
                  "o_clerk", O.o_clerk,
                  "o_shippriority", O.o_shippriority,
                  "o_comment", O.o_comment,
                  "oparts", coalesce(
                              ( SELECT collect_list(named_struct(
                                  "l_orderkey", L.l_orderkey, 
                                  "l_partkey", L.l_partkey, 
                                  "l_suppkey", L.l_suppkey, 
                                  "l_linenumber", L.l_linenumber, 
                                  "l_quantity", L.l_quantity, 
                                  "l_extendedprice", L.l_extendedprice, 
                                  "l_discount", L.l_discount, 
                                  "l_tax", L.l_tax, 
                                  "l_returnflag", L.l_returnflag, 
                                  "l_linestatus", L.l_linestatus, 
                                  "l_shipdate", L.l_shipdate, 
                                  "l_commitdate", L.l_commitdate, 
                                  "l_receiptdate", L.l_receiptdate, 
                                  "l_shipinstruct", L.l_shipinstruct, 
                                  "l_shipmode", L.l_shipmode, 
                                  "l_comment", L.l_comment 
                                )) 
                                FROM Lineitem L
                                WHERE L.l_orderkey = O.o_orderkey ),
                              filter(array(cast(null AS struct<l_orderkey:int,l_partkey:int,l_suppkey:int,l_linenumber:int,l_quantity:double,l_extendedprice:double,l_discount:double,l_tax:double,l_returnflag:string,l_linestatus:string,l_shipdate:string,l_commitdate:string,l_receiptdate:string,l_shipinstruct:string,l_shipmode:string,l_comment:string>)), x -> isnotnull(x))
                            ) 
                  ))
                FROM Orders O 
                WHERE O.o_custkey = C.c_custkey ),
             filter(array(cast(null AS struct<o_orderkey:int,o_custkey:int,o_orderstatus:string,o_totalprice:double,o_orderdate:string,o_orderpriority:string,o_clerk:string,o_shippriority:int,o_comment:string,oparts:array<struct<l_orderkey:int,l_partkey:int,l_suppkey:int,l_linenumber:int,l_quantity:double,l_extendedprice:double,l_discount:double,l_tax:double,l_returnflag:string,l_linestatus:string,l_shipdate:string,l_commitdate:string,l_receiptdate:string,l_shipinstruct:string,l_shipmode:string,l_comment:string>>>)), x -> isnotnull(x))
           ) AS corders
    FROM Customer C
  """)
tpchFlatNestedDepth2Wide.cache
spark.time(tpchFlatNestedDepth2Wide.show)
println("tpchFlatNestedDepth2Wide done")
tpchFlatNestedDepth2Wide.createOrReplaceTempView("tpchFlatNestedDepth2Wide")

val tpchNestedNestedDepth2Wide = 
  spark.sql("""
    SELECT  t3.c_custkey,
            t3.c_name,
            t3.c_address,
            t3.c_nationkey,
            t3.c_phone,
            t3.c_acctbal,
            t3.c_mktsegment,
            t3.c_comment,
            filter(
              collect_list(named_struct(
                "o_orderkey", t3.o_orderkey,
                "o_custkey", t3.o_custkey,
                "o_orderstatus", t3.o_orderstatus,
                "o_totalprice", t3.o_totalprice,
                "o_orderdate", t3.o_orderdate,
                "o_orderpriority", t3.o_orderpriority,
                "o_clerk", t3.o_clerk,
                "o_shippriority", t3.o_shippriority,
                "o_comment", t3.o_comment,
                "oparts", t3.oparts 
              )),
              x -> isnotnull(x.o_orderdate)
            ) AS corders
    FROM (
      SELECT  t2.cnameid,
              t2.c_custkey,
              t2.c_name,
              t2.c_address,
              t2.c_nationkey,
              t2.c_phone,
              t2.c_acctbal,
              t2.c_mktsegment,
              t2.c_comment,
              t2.o_orderkey,
              t2.o_custkey,
              t2.o_orderstatus,
              t2.o_totalprice,
              t2.o_orderdate,
              t2.o_orderpriority,
              t2.o_clerk,
              t2.o_shippriority,
              t2.o_comment,
              filter(
                collect_list(named_struct(
                  "pname", t2.pname,
                  "total", t2.total
                )),
                x -> isnotnull(x.pname)
              ) AS oparts
      FROM (
        SELECT  t1.cnameid, 
                t1.c_custkey,
                t1.c_name,
                t1.c_address,
                t1.c_nationkey,
                t1.c_phone,
                t1.c_acctbal,
                t1.c_mktsegment,
                t1.c_comment,
                t1.odateid, 
                t1.o_orderkey,
                t1.o_custkey,
                t1.o_orderstatus,
                t1.o_totalprice,
                t1.o_orderdate,
                t1.o_orderpriority,
                t1.o_clerk,
                t1.o_shippriority,
                t1.o_comment,        
                P.p_name AS pname, 
                SUM(t1.l_quantity * P.p_retailprice) AS total
        FROM (
          SELECT COL.cnameid, COL.*, odateid, OL.*, L.l_partkey, L.l_quantity
          FROM (
            SELECT monotonically_increasing_id() AS cnameid, * 
            FROM tpchFlatNestedDepth2Wide 
          ) AS COL 
          LATERAL VIEW OUTER posexplode(COL.corders) AS odateid, OL
          LATERAL VIEW OUTER explode(OL.oparts) AS L
        ) t1 LEFT OUTER JOIN Part P ON t1.l_partkey = P.p_partkey
        GROUP BY t1.cnameid, t1.c_custkey, t1.c_name, t1.c_address, t1.c_nationkey, t1.c_phone, t1.c_acctbal, t1.c_mktsegment, t1.c_comment, 
                 t1.odateid,  t1.o_orderkey, t1.o_custkey, t1.o_orderstatus, t1.o_totalprice, t1.o_orderdate, t1.o_orderpriority, t1.o_clerk, t1.o_shippriority, t1.o_comment, 
                 P.p_name
      ) t2
      GROUP BY t2.cnameid, t2.c_custkey, t2.c_name, t2.c_address, t2.c_nationkey, t2.c_phone, t2.c_acctbal, t2.c_mktsegment, t2.c_comment, 
               t2.odateid,  t2.o_orderkey, t2.o_custkey, t2.o_orderstatus, t2.o_totalprice, t2.o_orderdate, t2.o_orderpriority, t2.o_clerk, t2.o_shippriority, t2.o_comment
    ) t3
    GROUP BY t3.cnameid, t3.c_custkey, t3.c_name, t3.c_address, t3.c_nationkey, t3.c_phone, t3.c_acctbal, t3.c_mktsegment, t3.c_comment
  """)
//tpchNestedNestedDepth2Wide.cache
spark.time(tpchNestedNestedDepth2Wide.show)
println("tpchNestedNestedDepth2Wide done")
//tpchNestedNestedDepth2Wide.createOrReplaceTempView("tpchNestedNestedDepth2Wide")
