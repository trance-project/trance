import org.apache.spark.sql.SparkSession
import org.apache.spark.SparkConf

// For implicit conversions like converting RDDs to DataFrames
import spark.implicits._

import sparkutils.loader._
import sparkutils._

val sf = Config.datapath.split("/").last
val conf = new SparkConf().setMaster(Config.master)
  .setAppName("tpchNestedNestedDepth2" + sf)
  .set("spark.sql.shuffle.partitions", Config.minPartitions.toString)
val spark = SparkSession.builder().config(conf).getOrCreate()

val tpch = TPCHLoader(spark)

val lineitem = tpch.loadLineitemDF()
lineitem.cache
lineitem.count
lineitem.createOrReplaceTempView("lineitem")

val orders = tpch.loadOrderDF()
orders.cache
orders.count
orders.createOrReplaceTempView("orders")

val customer = tpch.loadCustomerDF()
customer.cache
customer.count
customer.createOrReplaceTempView("customer")

val part = tpch.loadPartDF()
part.cache
part.count
part.createOrReplaceTempView("part")

val tpchFlatNestedDepth2Wide = 
  spark.sql("""
    SELECT  C.c_custkey,
            C.c_name,
            C.c_address,
            C.c_nationkey,
            C.c_phone,
            C.c_acctbal,
            C.c_mktsegment,
            C.c_comment,
            coalesce(
              ( SELECT collect_list(named_struct(
                  "o_orderkey", O.o_orderkey,
                  "o_custkey", O.o_custkey,
                  "o_orderstatus", O.o_orderstatus,
                  "o_totalprice", O.o_totalprice,
                  "o_orderdate", O.o_orderdate,
                  "o_orderpriority", O.o_orderpriority,
                  "o_clerk", O.o_clerk,
                  "o_shippriority", O.o_shippriority,
                  "o_comment", O.o_comment,
                  "oparts", coalesce(
                              ( SELECT collect_list(named_struct(
                                  "l_orderkey", L.l_orderkey, 
                                  "l_partkey", L.l_partkey, 
                                  "l_suppkey", L.l_suppkey, 
                                  "l_linenumber", L.l_linenumber, 
                                  "l_quantity", L.l_quantity, 
                                  "l_extendedprice", L.l_extendedprice, 
                                  "l_discount", L.l_discount, 
                                  "l_tax", L.l_tax, 
                                  "l_returnflag", L.l_returnflag, 
                                  "l_linestatus", L.l_linestatus, 
                                  "l_shipdate", L.l_shipdate, 
                                  "l_commitdate", L.l_commitdate, 
                                  "l_receiptdate", L.l_receiptdate, 
                                  "l_shipinstruct", L.l_shipinstruct, 
                                  "l_shipmode", L.l_shipmode, 
                                  "l_comment", L.l_comment 
                                )) 
                                FROM Lineitem L
                                WHERE L.l_orderkey = O.o_orderkey ),
                              filter(array(cast(null AS struct<l_orderkey:int,l_partkey:int,l_suppkey:int,l_linenumber:int,l_quantity:double,l_extendedprice:double,l_discount:double,l_tax:double,l_returnflag:string,l_linestatus:string,l_shipdate:string,l_commitdate:string,l_receiptdate:string,l_shipinstruct:string,l_shipmode:string,l_comment:string>)), x -> isnotnull(x))
                            ) 
                  ))
                FROM Orders O 
                WHERE O.o_custkey = C.c_custkey ),
             filter(array(cast(null AS struct<o_orderkey:int,o_custkey:int,o_orderstatus:string,o_totalprice:double,o_orderdate:string,o_orderpriority:string,o_clerk:string,o_shippriority:int,o_comment:string,oparts:array<struct<l_orderkey:int,l_partkey:int,l_suppkey:int,l_linenumber:int,l_quantity:double,l_extendedprice:double,l_discount:double,l_tax:double,l_returnflag:string,l_linestatus:string,l_shipdate:string,l_commitdate:string,l_receiptdate:string,l_shipinstruct:string,l_shipmode:string,l_comment:string>>>)), x -> isnotnull(x))
           ) AS corders
    FROM Customer C
  """)
tpchFlatNestedDepth2Wide.cache
spark.time(tpchFlatNestedDepth2Wide.show)
println("tpchFlatNestedDepth2Wide done")
tpchFlatNestedDepth2Wide.createOrReplaceTempView("tpchFlatNestedDepth2Wide")


val tpchNestedNestedDepth2 = 
  spark.sql("""
    SELECT  t3.cname, 
            filter(
              collect_list(named_struct(
                "odate", t3.odate,
                "oparts", t3.oparts 
              )),
              x -> isnotnull(x.odate)
            ) AS corders
    FROM (
      SELECT t2.cnameid, t2.cname, t2.odate,
             filter(
               collect_list(named_struct(
                 "pname", t2.pname,
                 "total", t2.total
               )),
               x -> isnotnull(x.pname)
             ) AS oparts
      FROM (
        SELECT t1.cnameid, t1.cname, t1.odateid, t1.odate, P.p_name AS pname, SUM(t1.qty * P.p_retailprice) AS total
        FROM (
          SELECT COL.cnameid, COL.cname, odateid, OL.odate, L.pid, L.qty
          FROM (
            SELECT monotonically_increasing_id() AS cnameid, * 
            FROM tpchFlatNestedDepth2 
          ) AS COL 
          LATERAL VIEW OUTER posexplode(COL.corders) AS odateid, OL
          LATERAL VIEW OUTER explode(OL.oparts) AS L
        ) t1 LEFT OUTER JOIN Part P ON t1.pid = P.p_partkey
        GROUP BY t1.cnameid, t1.cname, t1.odateid, t1.odate, P.p_name
      ) t2
      GROUP BY t2.cnameid, t2.cname, t2.odateid, t2.odate
    ) t3
    GROUP BY t3.cnameid, t3.cname
  """)
//tpchNestedNestedDepth2.cache
spark.time(tpchNestedNestedDepth2.show)
println("tpchNestedNestedDepth2 done")
//tpchNestedNestedDepth2.createOrReplaceTempView("tpchNestedNestedDepth2")
