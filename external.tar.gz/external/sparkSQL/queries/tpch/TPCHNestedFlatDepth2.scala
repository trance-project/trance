import org.apache.spark.sql.SparkSession
import org.apache.spark.SparkConf

// For implicit conversions like converting RDDs to DataFrames
import spark.implicits._

import sparkutils.loader._
import sparkutils._

val sf = Config.datapath.split("/").last
val conf = new SparkConf().setMaster(Config.master)
  .setAppName("tpchNestedFlatDepth2" + sf)
  .set("spark.sql.shuffle.partitions", Config.minPartitions.toString)
val spark = SparkSession.builder().config(conf).getOrCreate()

val tpch = TPCHLoader(spark)

val lineitem = tpch.loadLineitemDF()
lineitem.cache
lineitem.count
lineitem.createOrReplaceTempView("lineitem")

val orders = tpch.loadOrderDF()
orders.cache
orders.count
orders.createOrReplaceTempView("orders")

val customer = tpch.loadCustomerDF()
customer.cache
customer.count
customer.createOrReplaceTempView("customer")

val part = tpch.loadPartDF()
part.cache
part.count
part.createOrReplaceTempView("part")

val tpchFlatNestedDepth2 = 
  spark.sql("""
    SELECT  C.c_name AS cname,
            coalesce(
              ( SELECT collect_list(named_struct(
                  "odate", O.o_orderdate,
                  "oparts", coalesce(
                              ( SELECT collect_list(named_struct(
                                  "pid", L.l_partkey,
                                  "qty", L.l_quantity )) 
                                FROM Lineitem L
                                WHERE L.l_orderkey = O.o_orderkey ),
                              filter(array(cast(null AS struct<pid:int,qty:double>)), x -> isnotnull(x))
                            ) 
                  ))
                FROM Orders O 
                WHERE O.o_custkey = C.c_custkey ),
             filter(array(cast(null AS struct<odate:string,oparts:array<struct<pid:int,qty:double>>>)), x -> isnotnull(x))
           ) AS corders
    FROM Customer C
  """)
tpchFlatNestedDepth2.cache
spark.time(tpchFlatNestedDepth2.show)
println("tpchFlatNestedDepth2 done")
tpchFlatNestedDepth2.createOrReplaceTempView("tpchFlatNestedDepth2")

val tpchNestedFlatDepth2 = 
  spark.sql("""
    SELECT t1.cname, SUM(t1.qty * P.p_retailprice) AS total
    FROM (
      SELECT COL.cname, L.pid, L.qty
      FROM tpchFlatNestedDepth2 AS COL 
      LATERAL VIEW OUTER posexplode(COL.corders) AS odateid, OL
      LATERAL VIEW OUTER explode(OL.oparts) AS L
    ) t1 LEFT OUTER JOIN Part P ON t1.pid = P.p_partkey
    GROUP BY t1.cname
  """)
tpchNestedFlatDepth2.cache
spark.time(tpchNestedFlatDepth2.show)
println("tpchNestedFlatDepth2 done")
tpchNestedFlatDepth2.createOrReplaceTempView("tpchNestedFlatDepth2")

