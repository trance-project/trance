import org.apache.spark.sql.SparkSession
import org.apache.spark.SparkConf

// For implicit conversions like converting RDDs to DataFrames
import spark.implicits._

import sparkutils.loader._
import sparkutils._

val sf = Config.datapath.split("/").last
val conf = new SparkConf().setMaster(Config.master)
  .setAppName("tpchNestedNestedDepth4" + sf)
  .set("spark.sql.shuffle.partitions", Config.minPartitions.toString)
val spark = SparkSession.builder().config(conf).getOrCreate()

val tpch = TPCHLoader(spark)

val lineitem = tpch.loadLineitemDF()
lineitem.cache
lineitem.count
lineitem.createOrReplaceTempView("lineitem")

val orders = tpch.loadOrderDF()
orders.cache
orders.count
orders.createOrReplaceTempView("orders")

val customer = tpch.loadCustomerDF()
customer.cache
customer.count
customer.createOrReplaceTempView("customer")

val nation = tpch.loadNationDF()
nation.cache
nation.count
nation.createOrReplaceTempView("nation")

val region = tpch.loadRegionDF()
region.cache
region.count
region.createOrReplaceTempView("region")

val part = tpch.loadPartDF()
part.cache
part.count
part.createOrReplaceTempView("part")

val tpchFlatNestedDepth4Wide =
  spark.sql("""
    SELECT  R.r_regionkey,
            R.r_name,
            R.r_comment,
            coalesce(
              ( SELECT collect_list(named_struct(
                  "n_nationkey", N.n_nationkey,
                  "n_name", N.n_name,
                  "n_regionkey", N.n_regionkey,
                  "n_comment", N.n_comment,
                  "ncusts", coalesce(
                              ( SELECT collect_list(named_struct(
                                  "c_custkey", C.c_custkey,
                                  "c_name", C.c_name,
                                  "c_address", C.c_address,
                                  "c_nationkey", C.c_nationkey,
                                  "c_phone", C.c_phone,
                                  "c_acctbal", C.c_acctbal,
                                  "c_mktsegment", C.c_mktsegment,
                                  "c_comment", C.c_comment,
                                  "corders", coalesce(
                                              ( SELECT collect_list(named_struct(
                                                  "o_orderkey", O.o_orderkey,
                                                  "o_custkey", O.o_custkey,
                                                  "o_orderstatus", O.o_orderstatus,
                                                  "o_totalprice", O.o_totalprice,
                                                  "o_orderdate", O.o_orderdate,
                                                  "o_orderpriority", O.o_orderpriority,
                                                  "o_clerk", O.o_clerk,
                                                  "o_shippriority", O.o_shippriority,
                                                  "o_comment", O.o_comment,
                                                  "oparts", coalesce(
                                                              ( SELECT collect_list(named_struct(
                                                                  "l_orderkey", L.l_orderkey, 
                                                                  "l_partkey", L.l_partkey, 
                                                                  "l_suppkey", L.l_suppkey, 
                                                                  "l_linenumber", L.l_linenumber, 
                                                                  "l_quantity", L.l_quantity, 
                                                                  "l_extendedprice", L.l_extendedprice, 
                                                                  "l_discount", L.l_discount, 
                                                                  "l_tax", L.l_tax, 
                                                                  "l_returnflag", L.l_returnflag, 
                                                                  "l_linestatus", L.l_linestatus, 
                                                                  "l_shipdate", L.l_shipdate, 
                                                                  "l_commitdate", L.l_commitdate, 
                                                                  "l_receiptdate", L.l_receiptdate, 
                                                                  "l_shipinstruct", L.l_shipinstruct, 
                                                                  "l_shipmode", L.l_shipmode, 
                                                                  "l_comment", L.l_comment 
                                                                )) 
                                                                FROM Lineitem L
                                                                WHERE L.l_orderkey = O.o_orderkey ),
                                                              filter(array(cast(null AS struct<l_orderkey:int,l_partkey:int,l_suppkey:int,l_linenumber:int,l_quantity:double,l_extendedprice:double,l_discount:double,l_tax:double,l_returnflag:string,l_linestatus:string,l_shipdate:string,l_commitdate:string,l_receiptdate:string,l_shipinstruct:string,l_shipmode:string,l_comment:string>)), x -> isnotnull(x))
                                                            ) ))
                                                FROM Orders O 
                                                WHERE O.o_custkey = C.c_custkey ),
                                             filter(array(cast(null AS struct<o_orderkey:int,o_custkey:int,o_orderstatus:string,o_totalprice:double,o_orderdate:string,o_orderpriority:string,o_clerk:string,o_shippriority:int,o_comment:string,oparts:array<struct<l_orderkey:int,l_partkey:int,l_suppkey:int,l_linenumber:int,l_quantity:double,l_extendedprice:double,l_discount:double,l_tax:double,l_returnflag:string,l_linestatus:string,l_shipdate:string,l_commitdate:string,l_receiptdate:string,l_shipinstruct:string,l_shipmode:string,l_comment:string>>>)), x -> isnotnull(x))
                                           )
                                  ))
                                FROM Customer C
                                WHERE C.c_nationkey = N.n_nationkey ), 
                              filter(array(cast(null AS struct<c_custkey:int,c_name:string,c_address:string,c_nationkey:int,c_phone:string,c_acctbal:double,c_mktsegment:string,c_comment:string,corders:array<struct<o_orderkey:int,o_custkey:int,o_orderstatus:string,o_totalprice:double,o_orderdate:string,o_orderpriority:string,o_clerk:string,o_shippriority:int,o_comment:string,oparts:array<struct<l_orderkey:int,l_partkey:int,l_suppkey:int,l_linenumber:int,l_quantity:double,l_extendedprice:double,l_discount:double,l_tax:double,l_returnflag:string,l_linestatus:string,l_shipdate:string,l_commitdate:string,l_receiptdate:string,l_shipinstruct:string,l_shipmode:string,l_comment:string>>>>>)), x -> isnotnull(x))
                            )
                ))
                FROM Nation N
                WHERE N.n_regionkey = R.r_regionkey
              ),
              filter(array(cast(null AS struct<n_nationkey:int,n_name:string,n_regionkey:int,n_comment:string,ncusts:array<struct<c_custkey:int,c_name:string,c_address:string,c_nationkey:int,c_phone:string,c_acctbal:double,c_mktsegment:string,c_comment:string,corders:array<struct<o_orderkey:int,o_custkey:int,o_orderstatus:string,o_totalprice:double,o_orderdate:string,o_orderpriority:string,o_clerk:string,o_shippriority:int,o_comment:string,oparts:array<struct<l_orderkey:int,l_partkey:int,l_suppkey:int,l_linenumber:int,l_quantity:double,l_extendedprice:double,l_discount:double,l_tax:double,l_returnflag:string,l_linestatus:string,l_shipdate:string,l_commitdate:string,l_receiptdate:string,l_shipinstruct:string,l_shipmode:string,l_comment:string>>>>>>>)), x -> isnotnull(x))
            ) AS rnations
    FROM Region R
  """)
tpchFlatNestedDepth4Wide.cache
spark.time(tpchFlatNestedDepth4Wide.show)
println("tpchFlatNestedDepth4Wide done")
tpchFlatNestedDepth4Wide.createOrReplaceTempView("tpchFlatNestedDepth4Wide")

val tpchNestedNestedDepth4 = 
  spark.sql("""
    SELECT  t5.rname, 
            filter(
              collect_list(named_struct(
                "nname", t5.nname,
                "ncusts", t5.ncusts 
              )),
              x -> isnotnull(x.nname)
            ) AS rnations
    FROM (
      SELECT  t4.rnameid, t4.rname, t4.nname, 
              filter(
                  collect_list(named_struct(
                    "cname", t4.cname,
                    "corders", t4.corders 
                  )),
                  x -> isnotnull(x.cname)
              ) AS ncusts
      FROM (
        SELECT  t3.rnameid, t3.rname, t3.nnameid, t3.nname, t3.cname, 
                filter(
                  collect_list(named_struct(
                    "odate", t3.odate,
                    "oparts", t3.oparts 
                  )),
                  x -> isnotnull(x.odate)
                ) AS corders
        FROM (
          SELECT t2.rnameid, t2.rname, t2.nnameid, t2.nname, t2.cnameid, t2.cname, t2.odate,
                 filter(
                   collect_list(named_struct(
                     "pname", t2.pname,
                     "total", t2.total
                   )),
                   x -> isnotnull(x.pname)
                 ) AS oparts
          FROM (
            SELECT t1.rnameid, t1.rname, t1.nnameid, t1.nname, t1.cnameid, t1.cname, t1.odateid, t1.odate, P.p_name AS pname, SUM(t1.qty * P.p_retailprice) AS total
            FROM (
              SELECT RNCOL.rnameid, RNCOL.rname, nnameid, NCOL.nname, cnameid, COL.cname, odateid, OL.odate, L.pid, L.qty
              FROM (
                SELECT monotonically_increasing_id() AS rnameid, * 
                FROM tpchFlatNestedDepth4
              ) AS RNCOL 
              LATERAL VIEW OUTER posexplode(RNCOL.rnations) AS nnameid, NCOL
              LATERAL VIEW OUTER posexplode(NCOL.ncusts) AS cnameid, COL
              LATERAL VIEW OUTER posexplode(COL.corders) AS odateid, OL
              LATERAL VIEW OUTER explode(OL.oparts) AS L
            ) t1 LEFT OUTER JOIN Part P ON t1.pid = P.p_partkey
            GROUP BY t1.rnameid, t1.rname, t1.nnameid, t1.nname, t1.cnameid, t1.cname, t1.odateid, t1.odate, P.p_name
          ) t2
          GROUP BY t2.rnameid, t2.rname, t2.nnameid, t2.nname, t2.cnameid, t2.cname, t2.odateid, t2.odate
        ) t3
        GROUP BY t3.rnameid, t3.rname, t3.nnameid, t3.nname, t3.cnameid, t3.cname
      ) t4
      GROUP BY t4.rnameid, t4.rname, t4.nnameid, t4.nname
    ) t5
    GROUP BY t5.rnameid, t5.rname
  """)
//tpchNestedNestedDepth4.cache
spark.time(tpchNestedNestedDepth4.show)
println("tpchNestedNestedDepth4 done")
//tpchNestedNestedDepth4.createOrReplaceTempView("tpchNestedNestedDepth4")
