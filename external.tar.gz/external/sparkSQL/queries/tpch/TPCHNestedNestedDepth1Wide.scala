import org.apache.spark.sql.SparkSession
import org.apache.spark.SparkConf

// For implicit conversions like converting RDDs to DataFrames
import spark.implicits._

import sparkutils.loader._
import sparkutils._

val sf = Config.datapath.split("/").last
val conf = new SparkConf().setMaster(Config.master)
  .setAppName("tpchNestedNestedDepth1Wide" + sf)
  .set("spark.sql.shuffle.partitions", Config.minPartitions.toString)
val spark = SparkSession.builder().config(conf).getOrCreate()

val tpch = TPCHLoader(spark)

val lineitem = tpch.loadLineitemDF()
lineitem.cache
lineitem.count
lineitem.createOrReplaceTempView("lineitem")

val orders = tpch.loadOrderDF()
orders.cache
orders.count
orders.createOrReplaceTempView("orders")

val part = tpch.loadPartDF()
part.cache
part.count
part.createOrReplaceTempView("part")

val tpchFlatNestedDepth1Wide = 
  spark.sql("""
    SELECT  O.o_orderkey,
            O.o_custkey,
            O.o_orderstatus,
            O.o_totalprice,
            O.o_orderdate,
            O.o_orderpriority,
            O.o_clerk,
            O.o_shippriority,
            O.o_comment,
            coalesce(
              ( SELECT collect_list(named_struct(
                  "l_orderkey", L.l_orderkey, 
                  "l_partkey", L.l_partkey, 
                  "l_suppkey", L.l_suppkey, 
                  "l_linenumber", L.l_linenumber, 
                  "l_quantity", L.l_quantity, 
                  "l_extendedprice", L.l_extendedprice, 
                  "l_discount", L.l_discount, 
                  "l_tax", L.l_tax, 
                  "l_returnflag", L.l_returnflag, 
                  "l_linestatus", L.l_linestatus, 
                  "l_shipdate", L.l_shipdate, 
                  "l_commitdate", L.l_commitdate, 
                  "l_receiptdate", L.l_receiptdate, 
                  "l_shipinstruct", L.l_shipinstruct, 
                  "l_shipmode", L.l_shipmode, 
                  "l_comment", L.l_comment 
                )) 
                FROM Lineitem L
                WHERE L.l_orderkey = O.o_orderkey ),
              filter(array(cast(null AS struct<l_orderkey:int,l_partkey:int,l_suppkey:int,l_linenumber:int,l_quantity:double,l_extendedprice:double,l_discount:double,l_tax:double,l_returnflag:string,l_linestatus:string,l_shipdate:string,l_commitdate:string,l_receiptdate:string,l_shipinstruct:string,l_shipmode:string,l_comment:string>)), x -> isnotnull(x))
            ) AS oparts
    FROM Orders O
  """)
tpchFlatNestedDepth1Wide.cache
spark.time(tpchFlatNestedDepth1Wide.show)
println("tpchFlatNestedDepth1Wide done")
tpchFlatNestedDepth1Wide.createOrReplaceTempView("tpchFlatNestedDepth1Wide")

val tpchNestedNestedDepth1Wide = 
  spark.sql("""
    SELECT  t2.o_orderkey, 
            t2.o_custkey, 
            t2.o_orderstatus, 
            t2.o_totalprice, 
            t2.o_orderdate, 
            t2.o_orderpriority, 
            t2.o_clerk, 
            t2.o_shippriority, 
            t2.o_comment, 
            filter(
              collect_list(named_struct(
                 "pname", t2.pname,
                 "total", t2.total
              )),
              x -> isnotnull(x.pname)
            ) AS oparts
    FROM (
      SELECT  t1.odateid,
              t1.o_orderkey,
              t1.o_custkey,
              t1.o_orderstatus,
              t1.o_totalprice,
              t1.o_orderdate,
              t1.o_orderpriority,
              t1.o_clerk,
              t1.o_shippriority,
              t1.o_comment,
              P.p_name AS pname,
              SUM(t1.l_quantity * P.p_retailprice) AS total
      FROM (
        SELECT OL.odateid, OL.*, L.l_partkey, L.l_quantity
        FROM (
          SELECT monotonically_increasing_id() AS odateid, * 
          FROM tpchFlatNestedDepth1Wide
        ) AS OL 
        LATERAL VIEW OUTER explode(OL.oparts) AS L
      ) t1 LEFT OUTER JOIN Part P ON t1.l_partkey = P.p_partkey
      GROUP BY t1.odateid, t1.o_orderkey, t1.o_custkey, t1.o_orderstatus, t1.o_totalprice, t1.o_orderdate, t1.o_orderpriority, t1.o_clerk, t1.o_shippriority, t1.o_comment, P.p_name
    ) t2
    GROUP BY t2.odateid, t2.o_orderkey, t2.o_custkey, t2.o_orderstatus, t2.o_totalprice, t2.o_orderdate, t2.o_orderpriority, t2.o_clerk, t2.o_shippriority, t2.o_comment
  """)
//tpchNestedNestedDepth1Wide.cache
spark.time(tpchNestedNestedDepth1Wide.show)
println("tpchNestedNestedDepth1Wide done")
//tpchNestedNestedDepth1Wide.createOrReplaceTempView("tpchNestedNestedDepth1Wide")
