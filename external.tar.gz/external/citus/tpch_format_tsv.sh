#!/bin/bash

for i in `ls *.tbl`; do 
    sed 's/|$//' $i | sed 's/|/\t/g' > ${i/tbl/tsv}; 
    echo $i; 
done;
