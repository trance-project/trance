\timing on

DROP TYPE IF EXISTS TPCH_Nested_Nested_Depth1_oparts_t CASCADE;

CREATE TYPE TPCH_Nested_Nested_Depth1_oparts_t AS (
    pname VARCHAR(55), 
    total DECIMAL
);

DROP TABLE IF EXISTS TPCH_Nested_Nested_Depth1_tmp_flatten;
CREATE TABLE TPCH_Nested_Nested_Depth1_tmp_flatten(orderkey BIGINT, odate DATE, pid BIGINT, qty DECIMAL(15,2));
SELECT create_distributed_table('TPCH_Nested_Nested_Depth1_tmp_flatten', 'pid');

DROP TABLE IF EXISTS TPCH_Nested_Nested_Depth1_tmp1;
CREATE TABLE TPCH_Nested_Nested_Depth1_tmp1(orderkey BIGINT, odate DATE, pname VARCHAR(55), total DECIMAL);
SELECT create_distributed_table('TPCH_Nested_Nested_Depth1_tmp1', 'orderkey');

DROP TABLE IF EXISTS TPCH_Nested_Nested_Depth1_Result;
CREATE TABLE TPCH_Nested_Nested_Depth1_Result(orderkey BIGINT, odate DATE, oparts TPCH_Nested_Nested_Depth1_oparts_t[]);
SELECT create_distributed_table('TPCH_Nested_Nested_Depth1_Result', 'orderkey');

\echo 'Prewarm relations...'
CREATE EXTENSION pg_prewarm;
SELECT * FROM pg_prewarm('TPCH_Flat_Nested_Depth1_Result');
SELECT * FROM pg_prewarm('Part');

\echo 'Unnest input + projection + repartition on partkey...'
INSERT INTO TPCH_Nested_Nested_Depth1_tmp_flatten
SELECT OL.orderkey, OL.odate, COALESCE(L.pid, -1), L.qty
FROM TPCH_Flat_Nested_Depth1_Result OL 
LEFT JOIN LATERAL unnest(OL.oparts) L(pid, qty) ON true;

\echo 'Join flattened input and Part + aggregation + repartition on orderkey...'
INSERT INTO TPCH_Nested_Nested_Depth1_tmp1
SELECT t1.orderkey, t1.odate, P.p_name AS pname, SUM(t1.qty * P.p_retailprice) AS total
FROM TPCH_Nested_Nested_Depth1_tmp_flatten t1 LEFT OUTER JOIN Part P ON t1.pid = P.p_partkey
GROUP BY t1.orderkey, t1.odate, P.p_partkey, P.p_name;

\echo 'Nest output (no repartitioning)...'
INSERT INTO TPCH_Nested_Nested_Depth1_Result
SELECT t1.orderkey, t1.odate, 
       COALESCE(ARRAY_AGG(ROW(t1.pname, t1.total)::TPCH_Nested_Nested_Depth1_oparts_t) FILTER (WHERE t1.pname IS NOT NULL), '{}') AS oparts
FROM TPCH_Nested_Nested_Depth1_tmp1 t1
GROUP BY t1.orderkey, t1.odate;

DROP TABLE TPCH_Nested_Nested_Depth1_tmp_flatten;
DROP TABLE TPCH_Nested_Nested_Depth1_tmp1;
-- DROP TABLE TPCH_Nested_Nested_Depth1_Result;



-- No subqueries: 
-- DETAIL:  Citus restricts the size of intermediate results of complex subqueries and CTEs to avoid accidentally pulling large result sets into once place.

-- INSERT INTO TPCH_Nested_Nested_Depth1_Result
-- SELECT t2.orderkey, t2.odate, ARRAY_AGG(ROW(t2.pname, t2.total)::TPCH_Nested_Nested_Depth1_oparts_t) FILTER (WHERE t2.pname IS NOT NULL) AS oparts
-- FROM (
--     SELECT t1.orderkey AS orderkey, t1.odate AS odate, P.p_name AS pname, SUM(t1.qty * P.p_retailprice) AS total
--     FROM TPCH_Nested_Nested_Depth1_tmp_flatten t1 LEFT OUTER JOIN Part P ON t1.pid = P.p_partkey
--     GROUP BY t1.orderkey, t1.odate, P.p_name
-- ) t2
-- GROUP BY t2.orderkey, t2.odate;
