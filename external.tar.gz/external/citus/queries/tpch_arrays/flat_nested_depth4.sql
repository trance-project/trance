\timing on

DROP TYPE IF EXISTS TPCH_Flat_Nested_Depth4_rnations_t CASCADE;
DROP TYPE IF EXISTS TPCH_Flat_Nested_Depth4_ncusts_t CASCADE;
DROP TYPE IF EXISTS TPCH_Flat_Nested_Depth4_corders_t CASCADE;
DROP TYPE IF EXISTS TPCH_Flat_Nested_Depth4_oparts_t CASCADE;

CREATE TYPE TPCH_Flat_Nested_Depth4_oparts_t AS (
    pid BIGINT, 
    qty DECIMAL(15,2)
);

CREATE TYPE TPCH_Flat_Nested_Depth4_corders_t AS (
    odate DATE,
    oparts TPCH_Flat_Nested_Depth4_oparts_t[]
);

CREATE TYPE TPCH_Flat_Nested_Depth4_ncusts_t AS (
    cname VARCHAR(25),
    corders TPCH_Flat_Nested_Depth4_corders_t[]
);

CREATE TYPE TPCH_Flat_Nested_Depth4_rnations_t AS (
    nname CHAR(25),
    ncusts TPCH_Flat_Nested_Depth4_ncusts_t[]
);

DROP TABLE IF EXISTS TPCH_Flat_Nested_Depth4_tmp1;
CREATE TABLE TPCH_Flat_Nested_Depth4_tmp1(custkey BIGINT, odate DATE, oparts TPCH_Flat_Nested_Depth4_oparts_t[]);
SELECT create_distributed_table('TPCH_Flat_Nested_Depth4_tmp1', 'custkey');

DROP TABLE IF EXISTS TPCH_Flat_Nested_Depth4_tmp2;
CREATE TABLE TPCH_Flat_Nested_Depth4_tmp2(nationkey BIGINT, cname VARCHAR(25), corders TPCH_Flat_Nested_Depth4_corders_t[]);
SELECT create_distributed_table('TPCH_Flat_Nested_Depth4_tmp2', 'nationkey');

DROP TABLE IF EXISTS TPCH_Flat_Nested_Depth4_tmp3;
CREATE TABLE TPCH_Flat_Nested_Depth4_tmp3(regionkey BIGINT, nname CHAR(25), ncusts TPCH_Flat_Nested_Depth4_ncusts_t[]);
SELECT create_distributed_table('TPCH_Flat_Nested_Depth4_tmp3', 'regionkey');

DROP TABLE IF EXISTS TPCH_Flat_Nested_Depth4_Result;
CREATE TABLE TPCH_Flat_Nested_Depth4_Result(regionkey BIGINT, rname CHAR(25), rnations TPCH_Flat_Nested_Depth4_rnations_t[]);
SELECT create_distributed_table('TPCH_Flat_Nested_Depth4_Result', 'regionkey');

\echo 'Prewarm relations...'
CREATE EXTENSION pg_prewarm;
SELECT * FROM pg_prewarm('Customer');
SELECT * FROM pg_prewarm('Orders');
SELECT * FROM pg_prewarm('Lineitem');
SELECT * FROM pg_prewarm('Nation');
SELECT * FROM pg_prewarm('Region');

\echo 'Nest lineitems of orders...'
INSERT INTO TPCH_Flat_Nested_Depth4_tmp1 
SELECT O.o_custkey AS custkey, O.o_orderdate AS odate, 
       COALESCE(ARRAY_AGG(ROW(L.l_partkey, L.l_quantity)::TPCH_Flat_Nested_Depth4_oparts_t) FILTER (WHERE L.l_partkey IS NOT NULL), '{}') AS oparts
FROM Orders O LEFT OUTER JOIN Lineitem L ON O.o_orderkey = L.l_orderkey
GROUP BY O.o_custkey, O.o_orderkey, O.o_orderdate;

\echo 'Nest orders of customers...'
INSERT INTO TPCH_Flat_Nested_Depth4_tmp2
SELECT C.c_nationkey AS nationkey, C.c_name AS cname, 
       COALESCE(ARRAY_AGG(ROW(t1.odate, t1.oparts)::TPCH_Flat_Nested_Depth4_corders_t) FILTER (WHERE t1.odate IS NOT NULL), '{}') AS corders
FROM Customer C LEFT OUTER JOIN TPCH_Flat_Nested_Depth4_tmp1 t1 ON C.c_custkey = t1.custkey
GROUP BY C.c_nationkey, C.c_custkey, C.c_name;

\echo 'Nest customers of nations...'
INSERT INTO TPCH_Flat_Nested_Depth4_tmp3
SELECT N.n_regionkey AS regionkey, N.n_name AS nname, 
       COALESCE(ARRAY_AGG(ROW(t1.cname, t1.corders)::TPCH_Flat_Nested_Depth4_ncusts_t) FILTER (WHERE t1.cname IS NOT NULL), '{}') AS ncusts 
FROM Nation N LEFT OUTER JOIN TPCH_Flat_Nested_Depth4_tmp2 t1 ON N.n_nationkey = t1.nationkey
GROUP BY N.n_regionkey, N.n_nationkey, N.n_name;

\echo 'Nest nations of regions...'
INSERT INTO TPCH_Flat_Nested_Depth4_Result
SELECT R.r_regionkey AS regionkey, R.r_name AS rname, 
       COALESCE(ARRAY_AGG(ROW(t1.nname, t1.ncusts)::TPCH_Flat_Nested_Depth4_rnations_t) FILTER (WHERE t1.nname IS NOT NULL), '{}') AS rnations
FROM Region R LEFT OUTER JOIN TPCH_Flat_Nested_Depth4_tmp3 t1 ON R.r_regionkey = t1.regionkey
GROUP BY R.r_regionkey, R.r_name;

DROP TABLE TPCH_Flat_Nested_Depth4_tmp1;
DROP TABLE TPCH_Flat_Nested_Depth4_tmp2;
DROP TABLE TPCH_Flat_Nested_Depth4_tmp3;
