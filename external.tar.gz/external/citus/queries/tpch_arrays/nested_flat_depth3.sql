\timing on

DROP TABLE IF EXISTS TPCH_Nested_Flat_Depth3_tmp_flatten;
CREATE TABLE TPCH_Nested_Flat_Depth3_tmp_flatten(nname CHAR(25), pid BIGINT, qty DECIMAL(15,2));
SELECT create_distributed_table('TPCH_Nested_Flat_Depth3_tmp_flatten', 'pid');

DROP TABLE IF EXISTS TPCH_Nested_Flat_Depth3_Result;
-- CREATE TABLE TPCH_Nested_Flat_Depth3_Result(nname CHAR(25), total DECIMAL);
-- SELECT create_distributed_table('TPCH_Nested_Flat_Depth3_Result', 'nname');

\echo 'Prewarm relations...'
CREATE EXTENSION pg_prewarm;
SELECT * FROM pg_prewarm('TPCH_Flat_Nested_Depth3_Result');
SELECT * FROM pg_prewarm('Part');

\echo 'Unnest input + projection + repartition on partkey...'
INSERT INTO TPCH_Nested_Flat_Depth3_tmp_flatten
SELECT NCOL.nname, COALESCE(L.pid, -1), L.qty
FROM TPCH_Flat_Nested_Depth3_Result NCOL
LEFT JOIN LATERAL unnest(NCOL.ncusts) COL(cname, corders) ON true 
LEFT JOIN LATERAL unnest(COL.corders) OL(odate, oparts) ON true
LEFT JOIN LATERAL unnest(OL.oparts) L(pid, qty) ON true;

\echo 'Join flattened input and Part + aggregation + collect on master...'
CREATE TEMP TABLE TPCH_Nested_Flat_Depth3_Result AS (
    SELECT t1.nname, SUM(t1.qty * P.p_retailprice) AS total
    FROM TPCH_Nested_Flat_Depth3_tmp_flatten t1 LEFT OUTER JOIN Part P ON t1.pid = P.p_partkey
    GROUP BY t1.nname
);

DROP TABLE TPCH_Nested_Flat_Depth3_tmp_flatten;
-- DROP TABLE TPCH_Nested_Flat_Depth3_Result;
