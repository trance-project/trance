\timing on

DROP TYPE IF EXISTS TPCH_Nested_Nested_Depth2_corders_t CASCADE;
DROP TYPE IF EXISTS TPCH_Nested_Nested_Depth2_oparts_t CASCADE;

CREATE TYPE TPCH_Nested_Nested_Depth2_oparts_t AS (
    pname VARCHAR(55), 
    total DECIMAL
);

CREATE TYPE TPCH_Nested_Nested_Depth2_corders_t AS (
    odate DATE,
    oparts jsonb
);

DROP TABLE IF EXISTS TPCH_Nested_Nested_Depth2_tmp_flatten;
CREATE TABLE TPCH_Nested_Nested_Depth2_tmp_flatten(custkey BIGINT, cname VARCHAR(25), orderkey BIGINT, odate DATE, pid BIGINT, qty DECIMAL(15,2));
SELECT create_distributed_table('TPCH_Nested_Nested_Depth2_tmp_flatten', 'pid');

DROP TABLE IF EXISTS TPCH_Nested_Nested_Depth2_tmp1;
CREATE TABLE TPCH_Nested_Nested_Depth2_tmp1(custkey BIGINT, cname VARCHAR(25), orderkey BIGINT, odate DATE, pname VARCHAR(55), total DECIMAL);
SELECT create_distributed_table('TPCH_Nested_Nested_Depth2_tmp1', 'custkey');

DROP TABLE IF EXISTS TPCH_Nested_Nested_Depth2_Result;
CREATE TABLE TPCH_Nested_Nested_Depth2_Result(custkey BIGINT, cname VARCHAR(25), corders jsonb);
SELECT create_distributed_table('TPCH_Nested_Nested_Depth2_Result', 'custkey');

\echo 'Prewarm relations...'
CREATE EXTENSION pg_prewarm;
SELECT * FROM pg_prewarm('TPCH_Flat_Nested_Depth2_Result');
SELECT * FROM pg_prewarm('Part');

\echo 'Unnest input + repartition on partkey...'
INSERT INTO TPCH_Nested_Nested_Depth2_tmp_flatten
SELECT COL.custkey, COL.cname, OL.orderkey, (OL.ordervalue->>'odate')::DATE AS odate, COALESCE((L->>'pid')::BIGINT, -1) AS pid, (L->>'qty')::DECIMAL(15,2) AS qty
FROM TPCH_Flat_Nested_Depth2_Result COL
LEFT JOIN LATERAL jsonb_array_elements(COL.corders) WITH ORDINALITY AS OL(ordervalue, orderkey) ON true
LEFT JOIN LATERAL jsonb_array_elements(ordervalue->'oparts') L ON true;

\echo 'Join flattened input and Part + aggregation + repartition on custkey...'
INSERT INTO TPCH_Nested_Nested_Depth2_tmp1
SELECT t1.custkey, t1.cname, t1.orderkey, t1.odate, P.p_name, SUM(t1.qty * P.p_retailprice) AS total
FROM TPCH_Nested_Nested_Depth2_tmp_flatten t1 LEFT OUTER JOIN Part P ON t1.pid = P.p_partkey
GROUP BY t1.custkey, t1.cname, t1.orderkey, t1.odate, P.p_name;

\echo 'Nest output (no repartitioning)...'
INSERT INTO TPCH_Nested_Nested_Depth2_Result
SELECT t2.custkey, t2.cname, 
       COALESCE(JSONB_AGG(ROW(t2.odate, t2.oparts)::TPCH_Nested_Nested_Depth2_corders_t) FILTER (WHERE t2.odate IS NOT NULL), '[]'::jsonb) AS corders
FROM (
    SELECT t1.custkey, t1.cname, t1.odate,
           COALESCE(JSONB_AGG(ROW(t1.pname, t1.total)::TPCH_Nested_Nested_Depth2_oparts_t) FILTER (WHERE t1.pname IS NOT NULL), '[]'::jsonb) AS oparts
    FROM TPCH_Nested_Nested_Depth2_tmp1 t1
    GROUP BY t1.custkey, t1.cname, t1.orderkey, t1.odate
) t2
GROUP BY t2.custkey, t2.cname;

DROP TABLE TPCH_Nested_Nested_Depth2_tmp_flatten;
DROP TABLE TPCH_Nested_Nested_Depth2_tmp1;
-- DROP TABLE TPCH_Nested_Nested_Depth2_Result;
