\timing on

DROP TYPE IF EXISTS TPCH_Nested_Nested_Depth3_ncusts_t CASCADE;
DROP TYPE IF EXISTS TPCH_Nested_Nested_Depth3_corders_t CASCADE;
DROP TYPE IF EXISTS TPCH_Nested_Nested_Depth3_oparts_t CASCADE;

CREATE TYPE TPCH_Nested_Nested_Depth3_oparts_t AS (
    pname VARCHAR(55), 
    total DECIMAL
);

CREATE TYPE TPCH_Nested_Nested_Depth3_corders_t AS (
    odate DATE,
    oparts jsonb
);

CREATE TYPE TPCH_Nested_Nested_Depth3_ncusts_t AS (
    cname VARCHAR(25),
    corders jsonb
);

DROP TABLE IF EXISTS TPCH_Nested_Nested_Depth3_tmp_flatten;
CREATE TABLE TPCH_Nested_Nested_Depth3_tmp_flatten(nationkey BIGINT, nname CHAR(25), custkey BIGINT, cname VARCHAR(25), orderkey BIGINT, odate DATE, pid BIGINT, qty DECIMAL(15,2));
SELECT create_distributed_table('TPCH_Nested_Nested_Depth3_tmp_flatten', 'pid');

DROP TABLE IF EXISTS TPCH_Nested_Nested_Depth3_tmp1;
CREATE TABLE TPCH_Nested_Nested_Depth3_tmp1(nationkey BIGINT, nname CHAR(25), custkey BIGINT, cname VARCHAR(25), orderkey BIGINT, odate DATE, pname VARCHAR(55), total DECIMAL);
SELECT create_distributed_table('TPCH_Nested_Nested_Depth3_tmp1', 'nationkey');

DROP TABLE IF EXISTS TPCH_Nested_Nested_Depth3_Result;
CREATE TABLE TPCH_Nested_Nested_Depth3_Result(nationkey BIGINT, nname CHAR(25), ncusts jsonb);
SELECT create_distributed_table('TPCH_Nested_Nested_Depth3_Result', 'nationkey');

\echo 'Prewarm relations...'
CREATE EXTENSION pg_prewarm;
SELECT * FROM pg_prewarm('TPCH_Flat_Nested_Depth3_Result');
SELECT * FROM pg_prewarm('Part');

\echo 'Unnest input + repartition on partkey...'
INSERT INTO TPCH_Nested_Nested_Depth3_tmp_flatten
SELECT NCOL.nationkey, NCOL.nname, 
       COL.custkey, (COL.custvalue->'cname')::VARCHAR(25) AS cname, 
       OL.orderkey, (OL.ordervalue->>'odate')::DATE AS odate, 
       COALESCE((L->>'pid')::BIGINT, -1) AS pid, (L->>'qty')::DECIMAL(15,2) AS qty
FROM TPCH_Flat_Nested_Depth3_Result NCOL
LEFT JOIN LATERAL jsonb_array_elements(NCOL.ncusts) WITH ORDINALITY AS COL(custvalue, custkey) ON true
LEFT JOIN LATERAL jsonb_array_elements(custvalue->'corders') WITH ORDINALITY AS OL(ordervalue, orderkey) ON true
LEFT JOIN LATERAL jsonb_array_elements(ordervalue->'oparts') L ON true;

\echo 'Join flattened input and Part + aggregation + repartition on nationkey...'
INSERT INTO TPCH_Nested_Nested_Depth3_tmp1
SELECT t1.nationkey, t1.nname, t1.custkey, t1.cname, t1.orderkey, t1.odate, P.p_name, SUM(t1.qty * P.p_retailprice) AS total
FROM TPCH_Nested_Nested_Depth3_tmp_flatten t1 LEFT OUTER JOIN Part P ON t1.pid = P.p_partkey
GROUP BY t1.nationkey, t1.nname, t1.custkey, t1.cname, t1.orderkey, t1.odate, P.p_name;

\echo 'Nest output (no repartitioning)...'
INSERT INTO TPCH_Nested_Nested_Depth3_Result
SELECT t3.nationkey, t3.nname, 
       COALESCE(JSONB_AGG(ROW(t3.cname, t3.corders)::TPCH_Nested_Nested_Depth3_ncusts_t) FILTER (WHERE t3.cname IS NOT NULL), '[]'::jsonb) AS ncusts
FROM (
    SELECT t2.nationkey, t2.nname, t2.cname,
           COALESCE(JSONB_AGG(ROW(t2.odate, t2.oparts)::TPCH_Nested_Nested_Depth3_corders_t) FILTER (WHERE t2.odate IS NOT NULL), '[]'::jsonb) AS corders
    FROM (
        SELECT t1.nationkey, t1.nname, t1.custkey, t1.cname, t1.odate,
               COALESCE(JSONB_AGG(ROW(t1.pname, t1.total)::TPCH_Nested_Nested_Depth3_oparts_t) FILTER (WHERE t1.pname IS NOT NULL), '[]'::jsonb) AS oparts
        FROM TPCH_Nested_Nested_Depth3_tmp1 t1
        GROUP BY t1.nationkey, t1.nname, t1.custkey, t1.cname, t1.orderkey, t1.odate
    ) t2
    GROUP BY t2.nationkey, t2.nname, t2.custkey, t2.cname
) t3
GROUP BY t3.nationkey, t3.nname;

DROP TABLE TPCH_Nested_Nested_Depth3_tmp_flatten;
DROP TABLE TPCH_Nested_Nested_Depth3_tmp1;
-- DROP TABLE TPCH_Nested_Nested_Depth3_Result;
