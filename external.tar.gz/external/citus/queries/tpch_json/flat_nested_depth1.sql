\timing on

DROP TYPE IF EXISTS TPCH_Flat_Nested_Depth1_oparts_t CASCADE;

CREATE TYPE TPCH_Flat_Nested_Depth1_oparts_t AS (
    pid BIGINT, 
    qty DECIMAL(15,2)
);

DROP TABLE IF EXISTS TPCH_Flat_Nested_Depth1_Result;
CREATE TABLE TPCH_Flat_Nested_Depth1_Result(orderkey BIGINT, odate DATE, oparts jsonb);
SELECT create_distributed_table('TPCH_Flat_Nested_Depth1_Result', 'orderkey');

\echo 'Prewarm relations...'
CREATE EXTENSION pg_prewarm;
SELECT * FROM pg_prewarm('Orders');
SELECT * FROM pg_prewarm('Lineitem');

\echo 'Nest lineitems of orders...'
INSERT INTO TPCH_Flat_Nested_Depth1_Result 
SELECT O.o_orderkey AS orderkey, O.o_orderdate AS odate, 
       COALESCE(JSONB_AGG(ROW(L.l_partkey, L.l_quantity)::TPCH_Flat_Nested_Depth1_oparts_t) FILTER (WHERE L.l_partkey IS NOT NULL), '[]'::jsonb) AS oparts
FROM Orders O LEFT OUTER JOIN Lineitem L ON O.o_orderkey = L.l_orderkey
GROUP BY O.o_orderkey, O.o_orderdate;
