\timing on

DROP TABLE IF EXISTS TPCH_Nested_Nested_Depth0_Result;
CREATE TABLE TPCH_Nested_Nested_Depth0_Result(pname VARCHAR(55), total INTEGER);
SELECT create_distributed_table('TPCH_Nested_Nested_Depth0_Result', 'pname');

\echo 'Prewarm relations...'
CREATE EXTENSION pg_prewarm;
SELECT * FROM pg_prewarm('TPCH_Flat_Nested_Depth0_Result');
SELECT * FROM pg_prewarm('Part');

\echo 'Join input and Part + aggregation + repartition on orderkey...'
INSERT INTO TPCH_Nested_Nested_Depth0_Result
SELECT P.p_name, SUM(t1.quantity * P.p_retailprice)
FROM TPCH_Flat_Nested_Depth0_Result t1 LEFT OUTER JOIN Part P ON t1.partkey = P.p_partkey
GROUP BY P.p_name;

-- DROP TABLE TPCH_Nested_Nested_Depth0_Result;
