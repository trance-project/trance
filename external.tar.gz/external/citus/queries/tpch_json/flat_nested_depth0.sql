\timing on

DROP TABLE IF EXISTS TPCH_Flat_Nested_Depth0_Result;
CREATE TABLE TPCH_Flat_Nested_Depth0_Result(partkey BIGINT, quantity DECIMAL);
SELECT create_distributed_table('TPCH_Flat_Nested_Depth0_Result', 'partkey');

\echo 'Prewarm relations...'
CREATE EXTENSION pg_prewarm;
SELECT * FROM pg_prewarm('Lineitem');

\echo 'Processing lineitem...'
INSERT INTO TPCH_Flat_Nested_Depth0_Result
SELECT L.l_partkey AS partkey, L.l_quantity AS quantity
FROM Lineitem L;
