\timing on

DROP TABLE IF EXISTS TPCH_Nested_Flat_Depth2_tmp_flatten;
CREATE TABLE TPCH_Nested_Flat_Depth2_tmp_flatten(cname VARCHAR(25), pid BIGINT, qty DECIMAL(15,2));
SELECT create_distributed_table('TPCH_Nested_Flat_Depth2_tmp_flatten', 'pid');

DROP TABLE IF EXISTS TPCH_Nested_Flat_Depth2_Result;
CREATE TABLE TPCH_Nested_Flat_Depth2_Result(cname VARCHAR(25), total DECIMAL);
SELECT create_distributed_table('TPCH_Nested_Flat_Depth2_Result', 'cname');

\echo 'Prewarm relations...'
CREATE EXTENSION pg_prewarm;
SELECT * FROM pg_prewarm('TPCH_Flat_Nested_Depth2_Result');
SELECT * FROM pg_prewarm('Part');

\echo 'Unnest input + projection + repartition on partkey...'
INSERT INTO TPCH_Nested_Flat_Depth2_tmp_flatten
SELECT COL.cname, COALESCE((L->>'pid')::BIGINT, -1) AS pid, (L->>'qty')::DECIMAL(15,2) AS qty
FROM TPCH_Flat_Nested_Depth2_Result COL
LEFT JOIN LATERAL jsonb_array_elements(COL.corders) WITH ORDINALITY AS OL(ordervalue, orderkey) ON true
LEFT JOIN LATERAL jsonb_array_elements(ordervalue->'oparts') L ON true;

\echo 'Join flattened input and Part + aggregation + repartition on cname...'
INSERT INTO TPCH_Nested_Flat_Depth2_Result
SELECT t1.cname, SUM(t1.qty * P.p_retailprice) AS total
FROM TPCH_Nested_Flat_Depth2_tmp_flatten t1 LEFT OUTER JOIN Part P ON t1.pid = P.p_partkey
GROUP BY t1.cname;

DROP TABLE TPCH_Nested_Flat_Depth2_tmp_flatten;
-- DROP TABLE TPCH_Nested_Flat_Depth2_Result;
