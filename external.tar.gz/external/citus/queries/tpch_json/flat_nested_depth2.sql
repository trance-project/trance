\timing on

DROP TYPE IF EXISTS TPCH_Flat_Nested_Depth2_corders_t CASCADE;
DROP TYPE IF EXISTS TPCH_Flat_Nested_Depth2_oparts_t CASCADE;

CREATE TYPE TPCH_Flat_Nested_Depth2_oparts_t AS (
    pid BIGINT, 
    qty DECIMAL(15,2)
);

CREATE TYPE TPCH_Flat_Nested_Depth2_corders_t AS (
    odate DATE,
    oparts jsonb
);

DROP TABLE IF EXISTS TPCH_Flat_Nested_Depth2_tmp1;
CREATE TABLE TPCH_Flat_Nested_Depth2_tmp1(custkey BIGINT, odate DATE, oparts jsonb);
SELECT create_distributed_table('TPCH_Flat_Nested_Depth2_tmp1', 'custkey');

DROP TABLE IF EXISTS TPCH_Flat_Nested_Depth2_Result;
CREATE TABLE TPCH_Flat_Nested_Depth2_Result(custkey BIGINT, cname VARCHAR(25), corders jsonb);
SELECT create_distributed_table('TPCH_Flat_Nested_Depth2_Result', 'custkey');

\echo 'Prewarm relations...'
CREATE EXTENSION pg_prewarm;
SELECT * FROM pg_prewarm('Customer');
SELECT * FROM pg_prewarm('Orders');
SELECT * FROM pg_prewarm('Lineitem');

\echo 'Nest lineitems of orders...'
INSERT INTO TPCH_Flat_Nested_Depth2_tmp1 
SELECT O.o_custkey AS custkey, O.o_orderdate AS odate, 
       COALESCE(JSONB_AGG(ROW(L.l_partkey, L.l_quantity)::TPCH_Flat_Nested_Depth2_oparts_t) FILTER (WHERE L.l_partkey IS NOT NULL), '[]'::jsonb) AS oparts
FROM Orders O LEFT OUTER JOIN Lineitem L ON O.o_orderkey = L.l_orderkey
GROUP BY O.o_custkey, O.o_orderkey, O.o_orderdate;

\echo 'Nest orders of customers...'
INSERT INTO TPCH_Flat_Nested_Depth2_Result
SELECT C.c_custkey AS custkey, C.c_name AS cname, 
       COALESCE(JSONB_AGG(ROW(t1.odate, t1.oparts)::TPCH_Flat_Nested_Depth2_corders_t) FILTER (WHERE t1.odate IS NOT NULL), '[]'::jsonb) AS corders
FROM Customer C LEFT OUTER JOIN TPCH_Flat_Nested_Depth2_tmp1 t1 ON C.c_custkey = t1.custkey
GROUP BY C.c_custkey, C.c_name;

DROP TABLE TPCH_Flat_Nested_Depth2_tmp1;
