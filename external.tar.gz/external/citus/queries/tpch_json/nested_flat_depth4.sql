\timing on

DROP TABLE IF EXISTS TPCH_Nested_Flat_Depth4_tmp_flatten;
CREATE TABLE TPCH_Nested_Flat_Depth4_tmp_flatten(rname CHAR(25), pid BIGINT, qty DECIMAL(15,2));
SELECT create_distributed_table('TPCH_Nested_Flat_Depth4_tmp_flatten', 'pid');

DROP TABLE IF EXISTS TPCH_Nested_Flat_Depth4_Result;
-- CREATE TABLE TPCH_Nested_Flat_Depth4_Result(rname CHAR(25), total DECIMAL);
-- SELECT create_distributed_table('TPCH_Nested_Flat_Depth4_Result', 'rname');

\echo 'Prewarm relations...'
CREATE EXTENSION pg_prewarm;
SELECT * FROM pg_prewarm('TPCH_Flat_Nested_Depth4_Result');
SELECT * FROM pg_prewarm('Part');

\echo 'Unnest input + projection + repartition on partkey...'
INSERT INTO TPCH_Nested_Flat_Depth4_tmp_flatten
SELECT RNCOL.rname, COALESCE((L->>'pid')::BIGINT, -1) AS pid, (L->>'qty')::DECIMAL(15,2) AS qty
FROM TPCH_Flat_Nested_Depth4_Result RNCOL
LEFT JOIN LATERAL jsonb_array_elements(RNCOL.rnations) NCOL ON true
LEFT JOIN LATERAL jsonb_array_elements(NCOL->'ncusts') COL ON true
LEFT JOIN LATERAL jsonb_array_elements(COL->'corders') OL ON true
LEFT JOIN LATERAL jsonb_array_elements(OL->'oparts') L ON true;

\echo 'Join flattened input and Part + aggregation + collect on master...'
CREATE TEMP TABLE TPCH_Nested_Flat_Depth4_Result AS (
    SELECT t1.rname, SUM(t1.qty * P.p_retailprice) AS total
    FROM TPCH_Nested_Flat_Depth4_tmp_flatten t1 LEFT OUTER JOIN Part P ON t1.pid = P.p_partkey
    GROUP BY t1.rname
);

DROP TABLE IF EXISTS TPCH_Nested_Flat_Depth4_tmp_flatten;
-- DROP TABLE IF EXISTS TPCH_Nested_Flat_Depth4_Result;
