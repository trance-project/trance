\timing on

DROP TABLE IF EXISTS TPCH_Nested_Flat_Depth1_tmp_flatten;
CREATE TABLE TPCH_Nested_Flat_Depth1_tmp_flatten(odate DATE, pid BIGINT, qty DECIMAL(15,2));
SELECT create_distributed_table('TPCH_Nested_Flat_Depth1_tmp_flatten', 'pid');

DROP TABLE IF EXISTS TPCH_Nested_Flat_Depth1_Result;
CREATE TABLE TPCH_Nested_Flat_Depth1_Result(odate DATE, total DECIMAL);
SELECT create_distributed_table('TPCH_Nested_Flat_Depth1_Result', 'odate');

\echo 'Prewarm relations...'
CREATE EXTENSION pg_prewarm;
SELECT * FROM pg_prewarm('TPCH_Flat_Nested_Depth1_Result');
SELECT * FROM pg_prewarm('Part');

\echo 'Unnest input + repartition on partkey...'
INSERT INTO TPCH_Nested_Flat_Depth1_tmp_flatten
SELECT OL.odate, COALESCE((L->>'pid')::BIGINT, -1) AS pid, (L->>'qty')::DECIMAL(15,2) AS qty
FROM TPCH_Flat_Nested_Depth1_Result OL 
LEFT JOIN LATERAL jsonb_array_elements(OL.oparts) L ON true;

\echo 'Join Lineitem and Part + aggregation + repartition on odate...'
INSERT INTO TPCH_Nested_Flat_Depth1_Result
SELECT t1.odate, SUM(t1.qty * P.p_retailprice) AS total
FROM TPCH_Nested_Flat_Depth1_tmp_flatten t1 LEFT OUTER JOIN Part P ON t1.pid = P.p_partkey
GROUP BY t1.odate;

DROP TABLE TPCH_Nested_Flat_Depth1_tmp_flatten;
-- DROP TABLE TPCH_Nested_Flat_Depth1_Result;
