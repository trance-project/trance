
-- Query 1 (from the paper)

DROP MATERIALIZED VIEW IF EXISTS Query1;
DROP TYPE IF EXISTS q1_corders_t;
DROP TYPE IF EXISTS q1_oparts_t;

CREATE TYPE q1_oparts_t AS (
    pid INTEGER, 
    qty DECIMAL(15,2)
);

CREATE TYPE q1_corders_t AS (
    odate DATE,
    oparts q1_oparts_t[]
);

CREATE MATERIALIZED VIEW Query1 AS (
    SELECT C.c_name AS cname, 
           ARRAY(SELECT ROW(O.o_orderdate, 
                            ARRAY(SELECT ROW(L.l_partkey, L.l_quantity)::q1_oparts_t
                                  FROM Lineitem L
                                  WHERE L.l_orderkey = O.o_orderkey)
                        )::q1_corders_t AS oparts FROM Orders O 
                 WHERE O.o_custkey = C.c_custkey) as corders
    FROM Customer C
);


-- Query 4

DROP MATERIALIZED VIEW IF EXISTS Query4;
DROP TYPE IF EXISTS q4_corders_t;
DROP TYPE IF EXISTS q4_oparts_t;

CREATE TYPE q4_oparts_t AS (
    pname VARCHAR(55),
    total DECIMAL
);

CREATE TYPE q4_corders_t AS (
    odate DATE,
    oparts q4_oparts_t[]
);

CREATE MATERIALIZED VIEW Query4 AS (
    SELECT COP.cname AS cname,
           ARRAY(SELECT ROW(CO.odate, 
                            ARRAY(
                                SELECT ROW(P.p_name, SUM(OP.qty * P.p_retailprice))::q4_oparts_t
                                  FROM unnest(CO.oparts) AS OP, Part P
                                 WHERE OP.pid = P.p_partkey
                                 GROUP BY P.p_name ))::q4_corders_t
                   FROM unnest(COP.corders) AS CO) AS corders
      FROM Query1 AS COP
);
