SELECT create_distributed_table('part', 'p_partkey');
SELECT create_distributed_table('lineitem', 'l_orderkey');
SELECT create_distributed_table('orders', 'o_orderkey');
SELECT create_distributed_table('customer', 'c_custkey');
-- SELECT create_reference_table('customer');

TRUNCATE NATION;
COPY NATION FROM '/dataset/nation.csv' CSV DELIMITER '|';
TRUNCATE REGION;
COPY REGION FROM '/dataset/region.csv' CSV DELIMITER '|';
TRUNCATE PART;
COPY PART FROM '/dataset/part.csv' CSV DELIMITER '|';
TRUNCATE SUPPLIER;
COPY SUPPLIER FROM '/dataset/supplier.csv' CSV DELIMITER '|';
TRUNCATE PARTSUPP;
COPY PARTSUPP FROM '/dataset/partsupp.csv' CSV DELIMITER '|';
TRUNCATE CUSTOMER;
COPY CUSTOMER FROM '/dataset/customer.csv' CSV DELIMITER '|';
TRUNCATE ORDERS;
COPY ORDERS FROM '/dataset/orders.csv' CSV DELIMITER '|';
TRUNCATE LINEITEM;
COPY LINEITEM FROM '/dataset/lineitem.csv' CSV DELIMITER '|';


-- Not supported: subquery in target list
CREATE MATERIALIZED VIEW Query1 AS (
    SELECT C.c_name AS cname,
           ARRAY(SELECT ROW(O.o_orderdate, 
                            ARRAY(SELECT ROW(L.l_partkey, L.l_quantity)::q1_oparts_t
                                  FROM Lineitem L
                                  WHERE L.l_orderkey = O.o_orderkey)
                        )::q1_corders_t AS oparts FROM Orders O 
                 WHERE O.o_custkey = C.c_custkey) as corders
    FROM Customer C
);


SET citus.enable_repartition_joins = 'true';

-- Supported but no outer joins (not supported), requires repartition joins
-- Problem: second GB creates an intermediate result at master
CREATE MATERIALIZED VIEW Query1_inner AS (
    SELECT t1.cname, ARRAY_AGG(ROW(t1.odate, t1.oparts)::q1_corders_t) AS corders
    FROM (
        SELECT C.c_custkey, C.c_name AS cname, O.o_orderdate AS odate, ARRAY_AGG(ROW(L.l_partkey, L.l_quantity)::q1_oparts_t) AS oparts
          FROM Customer C 
           JOIN Orders O ON C.c_custkey = O.o_custkey 
           JOIN Lineitem L ON O.o_orderkey = L.l_orderkey
        GROUP BY C.c_custkey, O.o_orderkey, cname, odate
    ) AS t1
    GROUP BY t1.c_custkey, t1.cname
);

-- Not supported
-- CREATE MATERIALIZED VIEW Query1_outer AS (
--     SELECT t1.cname, ARRAY_AGG(ROW(t1.odate, t1.oparts)::q1_corders_t) AS corders
--     FROM (
--         SELECT C.c_custkey, C.c_name AS cname, O.o_orderdate AS odate, ARRAY_AGG(ROW(L.l_partkey, L.l_quantity)::q1_oparts_t) AS oparts
--           FROM Customer C 
--            LEFT OUTER JOIN Orders O ON C.c_custkey = O.o_custkey 
--            LEFT OUTER JOIN Lineitem L ON O.o_orderkey = L.l_orderkey
--         GROUP BY C.c_custkey, O.o_orderkey, cname, odate
--     ) AS t1
--     GROUP BY t1.c_custkey, t1.cname
-- );

DROP MATERIALIZED VIEW IF EXISTS Query1;

-- Problem: the subquery would be pulled to the coordinator and then pushed back
CREATE MATERIALIZED VIEW Query1 AS (
    SELECT C.c_name AS cname, 
           ARRAY_AGG(ROW(t1.odate, t1.oparts)::q1_corders_t) AS corders
    FROM Customer C LEFT OUTER JOIN 
    ( 
        SELECT O.o_custkey, O.o_orderdate AS odate, 
               ARRAY_AGG(ROW(L.l_partkey, L.l_quantity)::q1_oparts_t) AS oparts
        FROM Orders O LEFT OUTER JOIN Lineitem L ON O.o_orderkey = L.l_orderkey
        GROUP BY O.o_custkey, O.o_orderkey, odate
    ) AS t1
    ON C.c_custkey = t1.o_custkey
    GROUP BY C.c_custkey, C.c_name
);


------------------------
------------------------
-- Working solution
------------------------
DROP TYPE IF EXISTS q1_corders_t CASCADE;
DROP TYPE IF EXISTS q1_oparts_t CASCADE;

CREATE TYPE q1_oparts_t AS (
    pid BIGINT, 
    qty DECIMAL(15,2)
);

CREATE TYPE q1_corders_t AS (
    orderkey BIGINT,
    odate DATE,
    oparts q1_oparts_t[]
);

-- Query 1: 
DROP TABLE IF EXISTS OrdLine;
CREATE TABLE OrdLine(custkey BIGINT, orderkey BIGINT, odate DATE, oparts q1_oparts_t[]);
SELECT create_distributed_table('OrdLine', 'custkey');

DROP TABLE IF EXISTS Q1_result;
CREATE TABLE Q1_result(custkey BIGINT, cname VARCHAR(25), corders q1_corders_t[]);
SELECT create_distributed_table('Q1_result', 'custkey');

INSERT INTO OrdLine 
SELECT O.o_custkey AS custkey, O.o_orderkey AS orderkey, O.o_orderdate AS odate, 
       ARRAY_AGG(ROW(L.l_partkey, L.l_quantity)::q1_oparts_t) AS oparts
FROM Orders O LEFT OUTER JOIN Lineitem L ON O.o_orderkey = L.l_orderkey
GROUP BY O.o_custkey, O.o_orderkey, O.o_orderdate;

INSERT INTO Q1_result
SELECT C.c_custkey AS custkey, C.c_name AS cname, 
       ARRAY_AGG(ROW(t1.orderkey, t1.odate, t1.oparts)::q1_corders_t) AS corders
FROM Customer C LEFT OUTER JOIN OrdLine t1 ON C.c_custkey = t1.custkey
GROUP BY C.c_custkey, C.c_name;


-- Query 4:

DROP TABLE IF EXISTS Q4_flatten_tmp;
CREATE TABLE Q4_flatten_tmp(custkey BIGINT, cname VARCHAR(25), orderkey BIGINT, odate DATE, pid BIGINT, qty DECIMAL(15,2));
SELECT create_distributed_table('Q4_flatten_tmp', 'pid');

-- Need to COALESCE null values in pid
-- ERROR: the partition column value cannot be NULL

DROP TYPE IF EXISTS q4_corders_t CASCADE;
DROP TYPE IF EXISTS q4_oparts_t CASCADE;

CREATE TYPE q4_oparts_t AS (
    pname VARCHAR(55),
    total DECIMAL
);

CREATE TYPE q4_corders_t AS (
    orderkey BIGINT,
    odate DATE,
    oparts q4_oparts_t[]
);

DROP TABLE IF EXISTS Q4_grouped_tmp;
CREATE TABLE Q4_grouped_tmp(custkey BIGINT, cname VARCHAR(25), orderkey BIGINT, odate DATE, pname VARCHAR(55), total DECIMAL);
SELECT create_distributed_table('Q4_grouped_tmp', 'custkey');

DROP TABLE IF EXISTS Q4_result;
CREATE TABLE Q4_result(custkey BIGINT, cname VARCHAR(25), corders q4_corders_t[]);
SELECT create_distributed_table('Q4_result', 'custkey');

INSERT INTO Q4_flatten_tmp
SELECT COP.custkey, COP.cname, CO.orderkey, CO.odate, COALESCE(OP.pid, -1), OP.qty
FROM Q1_result COP 
LEFT JOIN LATERAL unnest(COP.corders) CO(orderkey, odate, oparts) ON true
LEFT JOIN unnest(CO.oparts) OP(pid, qty) ON true;

INSERT INTO Q4_grouped_tmp
SELECT t1.custkey, t1.cname, t1.orderkey, t1.odate, P.p_name, SUM(t1.qty * P.p_retailprice) AS total
FROM Q4_flatten_tmp t1 LEFT JOIN Part P ON t1.pid = P.p_partkey
GROUP BY t1.custkey, t1.cname, t1.orderkey, t1.odate, P.p_name;

INSERT INTO Q4_result
SELECT t2.custkey, t2.cname, ARRAY_AGG(ROW(t2.orderkey, t2.odate, t2.oparts)::q4_corders_t) FILTER (WHERE t2.orderkey IS NOT NULL) AS corders
FROM (
    SELECT t1.custkey, t1.cname, t1.orderkey, t1.odate, ARRAY_AGG(ROW(t1.pname, t1.total)::q4_oparts_t) FILTER (WHERE t1.pname IS NOT NULL) AS oparts
    FROM Q4_grouped_tmp t1
    GROUP BY t1.custkey, t1.cname, t1.orderkey, t1.odate
) t2
GROUP BY t2.custkey, t2.cname;

SELECT * FROM Q4_result
WHERE cname = 'Customer#000000060';


---
--- Scratchpad
---

-- Outer join issue: https://github.com/citusdata/citus/issues/2321

SELECT * from pg_dist_partition;
SELECT * from pg_dist_shard_placement;
SELECT * from pg_dist_node;

SET citus.max_intermediate_result_size = '512kB';                                

SELECT COP.cname, CO.odate, OP.pid, OP.qty
FROM Query1_result COP 
LEFT JOIN LATERAL unnest(COP.corders) CO(odate, oparts) ON true
LEFT JOIN LATERAL unnest(CO.oparts) OP(pid, qty) ON true;

-- Cockroachdb
---
-- https://github.com/cockroachdb/cockroach/issues/35710
-- https://github.com/cockroachdb/cockroach/pull/12186