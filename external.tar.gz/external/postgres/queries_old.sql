-- Query 1
SELECT C.c_name AS c_name, 
       ARRAY(SELECT ROW(O.o_orderdate, 
                        ARRAY(SELECT ROW(P.p_name, L.l_quantity) 
                              FROM Lineitem L, Part P
                              WHERE L.l_orderkey = O.o_orderkey 
                                AND L.l_partkey = P.p_partkey)
                    ) FROM Orders O 
             WHERE O.o_custkey = C.c_custkey) as c_orders
FROM Customer C
;
-- LIMIT 1;

-- Query 1 - using CTE
WITH lineitem_part AS (
    SELECT L.l_orderkey AS l_orderkey, 
           P.p_name AS p_name,
           L.l_quantity AS l_qty
      FROM Lineitem L, Part P
     WHERE L.l_partkey = P.p_partkey
)
SELECT C.c_name AS c_name, 
       ARRAY(SELECT ROW(O.o_orderdate, 
                        ARRAY(SELECT ROW(LP.p_name, LP.l_qty) 
                              FROM lineitem_part LP
                              WHERE LP.l_orderkey = O.o_orderkey)
                    ) FROM Orders O 
             WHERE O.o_custkey = C.c_custkey) as c_orders
FROM Customer C;


-- Query 1 - using materialized indexed view

DROP MATERIALIZED VIEW IF EXISTS Query1;
DROP MATERIALIZED VIEW IF EXISTS lineitem_part;
DROP TYPE IF EXISTS q1_corders_t;
DROP TYPE IF EXISTS q1_oparts_t;

CREATE TYPE q1_oparts_t AS (
    p_name VARCHAR(25), 
    l_qty DECIMAL(15,2)
);

CREATE TYPE q1_corders_t AS (
    o_orderdate DATE,
    o_parts q1_oparts_t[]
);

CREATE MATERIALIZED VIEW lineitem_part AS (
    SELECT L.l_orderkey AS l_orderkey, 
           P.p_name AS p_name,
           L.l_quantity AS l_qty
      FROM Lineitem L, Part P
     WHERE L.l_partkey = P.p_partkey
);

CREATE INDEX lp_index ON lineitem_part (l_orderkey); 

CREATE MATERIALIZED VIEW Query1 AS (
    SELECT C.c_name AS c_name, 
           ARRAY(SELECT ROW(O.o_orderdate, 
                            ARRAY(SELECT ROW(LP.p_name, LP.l_qty)::q1_oparts_t
                                  FROM lineitem_part LP
                                  WHERE LP.l_orderkey = O.o_orderkey)
                        )::q1_corders_t AS o_parts FROM Orders O 
                 WHERE O.o_custkey = C.c_custkey) as c_orders
    FROM Customer C
);


-------------------